# AM-DiMNet — Implementation Contract (single source of truth)

This file is the authoritative interface + specification for the reference implementation of
**AM-DiMNet** (HRV-Anchored Autonomic–Morphological Structured Factorization for Interpretable
Multimodal Cardiovascular Risk Prediction). Every module MUST conform to the signatures, tensor
shapes, dict keys, and constants below so the package integrates and passes `am_dimnet/smoke_test.py`.

Python 3.10+, PyTorch 2.x, NumPy, scikit-learn, PyYAML, pandas, scipy. No GPU required for the smoke test.

---

## 0. Global constants (define once in `am_dimnet/constants.py`)

```python
MODALITIES   = ["ecg", "ppg", "pcg", "proxy", "hrv", "clinical"]   # ordered candidate set M
WAVEFORM_MODS = ["ecg", "ppg"]           # 1D waveforms always present in primary cohort
OPTIONAL_MODS = ["pcg"]                   # PCG is an optional, design-compatible branch
FACTORS      = ["auto", "morph", "act", "base", "noise"]           # structured latent factors P
RISK_FACTORS = ["auto", "morph", "base"]  # only these enter the risk head (Eq. 17)
HRV_FEATURES = ["MeanNN","SDNN","RMSSD","pNN50","LF","HF","LFHF","SD1","SD2","SampEn"]  # 10-dim (Eq. 5)
PROXY_COMPONENTS = ["bed_motion","ecg_env_instab","ppg_env_instab","ppg_reject_ratio"]  # 4-dim (Eq. 7)
N_ACTIVITY_CLASSES = 3   # low / moderate / high activity-motion-proxy tertiles
ECE_BINS = 15            # Eq. 35
PROXY_TERTILES = (0.34, 0.61)   # low<0.34, high>0.61 (training-set thresholds, Table 9)
VLQ_PERCENTILE = 10      # very-low-quality subgroup = below 10th pct of q_min (tau_VLQ approx 0.41)
```

## 1. Config schema (`am_dimnet/config.py`, dataclass `Config`, loadable from YAML)

`Config` holds nested dataclasses. Key fields (defaults MUST match Table 4 / Eq. loss_weights):

```
data:
  window_min: 5.0          # observation window (min)
  step_s: 60               # sliding step (s)
  gap_h: 1.5               # prediction gap Delta_g
  horizon_h: 24            # prediction horizon Delta_p
  ecg_len: 512             # samples per encoder input (resampled)
  ppg_len: 512
  pcg_mels: 64
  pcg_frames: 128
  clinical_dim: 16
  morph_dim: 24            # morphological descriptor target dim
model:
  embed_dim: 128           # shared embedding
  latent_dim: 32           # per-factor
  gate_eps: 1.0e-6
  dropout: 0.27
train:
  batch_size: 96
  lr: 7.5e-4
  weight_decay: 1.2e-4
  max_epochs: 120
  patience: 16
  modality_dropout: 0.18
  seeds: [11, 23, 42, 71, 97]     # 5 independent runs
  pos_weight: null                # auto from prevalence if null
loss:
  lambda_hrv: 0.35
  lambda_morph: 0.28
  lambda_act: 0.20
  lambda_adv: 0.15
  lambda_orth: 0.06
  lambda_cal: 0.08
```

`Config.load(path)` / `Config.default()` classmethods. YAML in `configs/default.yaml` mirrors this.

## 2. Batch dict contract (produced by datasets, consumed by model + losses)

A batch is a plain `dict[str, ...]`; all tensors are `torch.float32` unless noted, first dim = B.

```
batch = {
  "ecg":      [B, 1, ecg_len]          # waveform; present if mask["ecg"]==1
  "ppg":      [B, 1, ppg_len],
  "pcg":      [B, 1, pcg_mels, pcg_frames],   # log-Mel spectrogram (optional branch)
  "proxy":    [B, 4],                   # PROXY_COMPONENTS
  "hrv":      [B, 10],                  # HRV_FEATURES
  "clinical": [B, clinical_dim],
  "sqi":      [B, 6],                   # q_r per modality, order = MODALITIES, in [0,1]  (Eq. 10)
  "mask":     [B, 6],                   # m_r per modality, order = MODALITIES, in {0,1} (Eq. 11)
  "y":        [B],  float 0/1
  "activity": [B],  long in {0,1,2}     # proxy tertile class (anchoring + adversarial target)
  "morph_target": [B, morph_dim],       # morphological descriptor target for L_morph
  "patient_id":   [B],  long,
}
```
Missing waveform tensors may be zero-filled with the corresponding `mask` column = 0.
Helper `sqi_index(mod)` / `mask_index(mod)` return the column for a modality (order = MODALITIES).

## 3. Model API (`am_dimnet/models/`)

### encoders.py
- `ECGEncoder(embed_dim, dropout)` forward `[B,1,L] -> [B, embed_dim]` (1-D CNN, several conv blocks + global pool).
- `PPGEncoder(...)` same shape as ECG.
- `PCGEncoder(embed_dim, dropout)` forward `[B,1,M,T] -> [B, embed_dim]` (2-D CNN).
- `VectorEncoder(in_dim, embed_dim, dropout)` MLP forward `[B, in_dim] -> [B, embed_dim]`; used for proxy(4), hrv(10), clinical(clinical_dim).
- All produce the projected representation v_r directly at `embed_dim` (encoder + linear projection folded in, Eq. 12–13).

### fusion.py
- `QualityAwareGatedFusion(embed_dim)`:
  - `forward(v: dict[str,[B,embed_dim]], sqi:[B,6], mask:[B,6]) -> (h:[B,embed_dim], alpha:dict[str,[B]])`
  - implements Eq. 14–15: `alpha_r = mask_r*exp(w_g^T[v_r;q_r;m_r]) / (sum_s mask_s*exp(...) + eps)`, `h=sum alpha_r v_r`.
  - `w_g` is a shared `Linear(embed_dim+2, 1)` scorer applied per modality.

### factorization.py
- `StructuredFactorization(embed_dim, latent_dim)`:
  - five heads `G_p` (MLP) for FACTORS; `forward(h:[B,embed_dim]) -> dict z {p:[B,latent_dim]}` (Eq. 16).

### heads.py
- `RiskHead(latent_dim, dropout)`: `forward(z_auto,z_morph,z_base) -> logit:[B]` over concat `[B,3*latent_dim]` (Eq. 17).
- `HRVReconstructor(latent_dim, n_hrv=10)`: `[B,latent_dim]->[B,10]` (Eq. 18).
- `MorphReconstructor(latent_dim, morph_dim)`: `[B,latent_dim]->[B,morph_dim]` (Eq. 20).
- `ActivityHead(latent_dim, n_classes=3)`: `[B,latent_dim]->[B,3]` (Eq. 22 anchoring on z_act).
- `AdversaryHead(latent_dim, n_classes=3)`: `[B,latent_dim]->[B,3]` activity logits used with gradient reversal on z_auto and z_morph (Eq. 23).
- `GradientReversal` autograd Function + `grad_reverse(x, lambda_)` helper.

### am_dimnet.py
- `AMDiMNet(config)`: builds encoders (one per modality), fusion, factorization, all heads.
  - `forward(batch) -> out: dict` with keys:
    `logit:[B], prob:[B], fused:[B,embed], alpha:dict, z:dict{p:[B,latent]},
     recon_hrv:[B,10], recon_morph:[B,morph_dim], act_logits:[B,3],
     adv_auto_logits:[B,3], adv_morph_logits:[B,3]` (adv heads receive grad_reverse(z, adv_lambda)).
  - waveform encoders receive the batch tensor; vector encoders receive proxy/hrv/clinical; PCG optional (skip if mask all-zero, contribute v=0).
  - `adv_lambda` read from an attribute settable by the trainer (GRL strength schedule; default 1.0).

## 4. Losses (`am_dimnet/models/losses.py`)

`AMDiMNetLoss(config)` `.forward(out, batch) -> (total, parts:dict)` implementing:
- `L_risk`: class-weighted BCE with logits (Eq. 26), `pos_weight = omega1/omega0`.
- `L_hrv = MSE(recon_hrv, batch["hrv"])` masked by hrv availability (Eq. 19).
- `L_morph = MSE(recon_morph, batch["morph_target"])` (Eq. 21).
- `L_act = CE(act_logits, batch["activity"])` (Eq. 22).
- `L_adv = CE(adv_auto_logits, activity) + CE(adv_morph_logits, activity)` (Eq. 23); GRL already applied in model, so minimizing this trains discriminators while pushing factors to be activity-invariant.
- `L_orth`: stack z for 5 FACTORS -> for each p center over batch `H_B = I - 11^T/B` then RowNorm (unit L2 per row), `L_orth = mean_{p!=q} || Zt_p^T Zt_q / B ||_F^2` (Eq. 24–25).
- `L_cal = MSE(prob, y)` Brier (Eq. 27).
- `total = L_risk + 0.35 L_hrv + 0.28 L_morph + 0.20 L_act + 0.15 L_adv + 0.06 L_orth + 0.08 L_cal` (Eq. 28, weights from config.loss).

## 5. Data (`am_dimnet/data/`)

### synthetic.py  (REQUIRED — powers the smoke test, no external data)
- `SyntheticCohort(config, n_patients=64, windows_per_patient=(20,60), prevalence=0.219, seed=0)`
  returns a `torch.utils.data.Dataset` of window samples following the batch contract, with
  realistic irregular structure: risk correlates with an injected latent autonomic+morphological
  signal; ~18% of windows randomly drop a non-ECG/PPG modality (mask=0); activity tertiles from proxy score.
- `make_loaders(config, ...)` -> patient-disjoint train/val/test `DataLoader`s (uses splits.patient_split).

### features.py
- `hrv_features(rr_intervals) -> np.ndarray[10]` (MeanNN,SDNN,RMSSD,pNN50,LF,HF,LFHF,SD1,SD2,SampEn) (Eq. 5). Implement standard formulas; Lomb–Scargle or Welch for LF/HF; SampEn via a documented routine.
- `sma(acc_xyz) -> float` signal-magnitude area (Eq. 6) — ONLY for datasets with direct triaxial ACC.
- `activity_proxy_components(bed_motion, ecg_env, ppg_env, ppg_reject) -> np.ndarray[4]` (Eq. 7).
- `envelope_instability(envelope) -> float` = MAD(env)/median(env) (Eq. 8).
- `activity_proxy_score(components_minmax) -> float` mean of 4 min-max-normalised components (Eq. 9).
- `sqi(descriptors, weights) -> float` clip(sum eta_j s_j, 0, 1) (Eq. 10).
- `activity_tertile(score, tertiles=PROXY_TERTILES) -> int` 0/1/2.

### preprocessing.py
- `bandpass(x, fs, lo, hi)` Butterworth; per-modality bands from Table 4.
- `segment_windows(signal, fs, window_min, step_s)` -> list of windows.
- `resample(x, src_fs, tgt_len)`; `log_mel_spectrogram(x, fs, n_mels, n_frames)` for PCG.
- `build_window_record(...)` assembling a batch-contract sample dict from raw signals + features + masks.

### splits.py
- `patient_split(patient_ids, ratios=(0.7,0.15,0.15), seed) -> dict{train,val,test: set(pid)}` — PATIENT-disjoint.
- `split_summary(records, splits) -> pandas.DataFrame` with rows: patients, positive patients, windows, positive windows, first-qualifying endpoints per split (matches Tables 10–11).

### cohort.py  (MIMIC-IV extraction; not exercised by smoke test)
- `extract_cohort(db, config) -> pandas.DataFrame` of candidate ICU stays with waveform linkage.
- Applies the cohort-flow exclusions (Table 12): waveform availability, ECG/PPG availability, minimum
  duration, RR-quality, temporal alignment, pre-existing-endpoint, gap-window endpoint. Returns a flow log.
- Reads SQL from `sql/cohort_extraction.sql`. Uses a DB connection object (psycopg2/sqlalchemy);
  document PhysioNet credentialing — do NOT embed data.

### endpoints.py  (label construction; not exercised by smoke test)
- `ENDPOINT_COMPONENTS`: dict encoding Table 1 exactly:
  - cardiac_arrest_cpr: tables [procedureevents, chartevents], itemids [225466,225468,224385]
  - death: tables [admissions,icustays,patients], fields [deathtime, dod]
  - vasoactive_escalation: table [inputevents], itemids [221906,221289,221662,221653,222315]  # norepi, epi, dopamine, dobutamine, vasopressin
  - acute_hf: tables [inputevents,prescriptions], itemids [221794,225152,228340]  # IV furosemide + inotropes
  - malignant_arrhythmia: tables [chartevents,procedureevents], itemids [224168,225448,225468]
  - urgent_cv_intervention: table [procedureevents], itemids [225752,225459,225802]
- `label_window(stay, window_end, gap_h, horizon_h, events) -> int` : 1 if >=1 component occurs in
  `[window_end+gap_h, window_end+gap_h+horizon_h]` (Eq. 2–3). Also expose `first_qualifying_endpoint`.
- Reads SQL from `sql/endpoint_labeling.sql`.

## 6. Metrics + calibration (`am_dimnet/metrics.py`, `am_dimnet/calibrate.py`)

### metrics.py
- `auroc, auprc, macro_f1, mcc, brier` (wrap sklearn; threshold-free ones on probabilities).
- `expected_calibration_error(prob, y, n_bins=15)` = Eq. 35 (event frequency vs mean predicted risk).
- `reliability_curve(prob, y, n_bins=15)`.
- `operating_point_stats(prob, y, threshold, windows_per_patient=None, monitoring_hours=None)` ->
  dict sens, spec, ppv, npv, fpr, false_alarms_per_day, median_lead_time_h (document alarm
  consolidation + refractory interval).
- `decision_curve(prob, y, thresholds)` -> net benefit vs treat-all/treat-none.
- `patient_top_decile(prob, patient_id) -> (Y_hat, pid)` aggregation (Eq. 30); `patient_max` (Eq. 31).
- `bootstrap_ci(metric_fn, prob, y, patient_id, n=1000, seed)` — PATIENT-CLUSTER bootstrap.

### calibrate.py
- `TemperatureScaler` fit on validation logits; `IsotonicScaler` alternative.
- `select_operating_threshold(prob_val, y_val, target="youden"|"f1"|sensitivity_floor)` -> float.

## 7. Training / evaluation (`am_dimnet/train.py`, `evaluate.py`)

- `train.py`: `train_one(config, loaders, seed) -> (model, history)`; AdamW, early stopping on val AUROC,
  modality-dropout augmentation (`train.modality_dropout`), GRL lambda warmup. CLI `python -m am_dimnet.train --config configs/default.yaml`.
- `evaluate.py`: loads a trained model, computes the full metric suite at patient level (+ window-level
  for quality/operating-point), calibration, subgroup, decision curve; writes JSON/CSV to `--out`.
  CLI `python -m am_dimnet.evaluate --config ... --ckpt ...`.

## 8. Baselines (`am_dimnet/baselines/`)

- `classical.py`: LogReg / RandomForest / XGBoost on HRV features (sklearn/xgboost; xgboost optional import).
- `cnn.py`: `ECGCNN`, `PPGCNN` single-modality classifiers reusing the encoders.
- `fusion_baselines.py`: `EarlyFusion`, `LateFusion`, `AttentionFusion`, `ModalityDropoutFusion`, `AdversarialDeconfounding` — all consuming the SAME batch contract (HRV, clinical, SQI, masks available).
- `foundation.py`: `MomentBaseline`, `NormWearBaseline` — wrappers with a `frozen` flag, channel-adaptation,
  and a downstream head that receives the same HRV/clinical/SQI/mask features; the pretrained encoder is a
  documented, swappable stub (loads real checkpoints if available, else a deterministic random-projection
  placeholder) so the code path is reproducible without the external weights.

## 9. smoke_test.py (REQUIRED — must run end-to-end on CPU in < ~60 s)

`python -m am_dimnet.smoke_test` MUST:
1. build `Config.default()`,
2. create a tiny `SyntheticCohort` + patient-disjoint loaders,
3. run `AMDiMNet` forward on one batch and assert all output shapes,
4. compute `AMDiMNetLoss` and run a couple of optimizer steps (loss finite, decreases),
5. run temperature calibration + the full metric suite (AUROC/AUPRC/ECE-15/operating point) on the tiny test set,
6. print "SMOKE TEST PASSED".
Everything deterministic via seeds. No file/network I/O required.

## 10. Repo-root files
`README.md` (overview, install, quickstart = smoke test, full MIMIC reproduction steps, data-use/PhysioNet
notes, mapping of code→paper equations/tables, citation), `requirements.txt`, `environment.yml`,
`LICENSE` (MIT), `CITATION.cff`, `.gitignore`, `configs/*.yaml`, `scripts/*.sh` (extract/preprocess/train/evaluate),
`sql/cohort_extraction.sql`, `sql/endpoint_labeling.sql`, `docs/reproducibility.md`, `docs/data_access.md`.

Simulated numbers in the paper are placeholders the authors replace with real results; the code must be
faithful to the METHOD, and runnable on synthetic data. Repo URL: github.com/am-dimnet/cardio-deterioration,
archive DOI: 10.5281/zenodo.14508137 (placeholders — keep consistent with the manuscript).
