"""AM-DiMNet: HRV-Anchored Autonomic-Morphological Structured Factorization
for Interpretable Multimodal Cardiovascular Risk Prediction.

Reference implementation package. This top-level module deliberately avoids
heavy imports (torch, numpy, sklearn) so that ``import am_dimnet`` stays cheap;
sub-packages (``am_dimnet.models``, ``am_dimnet.data`` ...) are imported
explicitly where needed.

See ``SPEC.md`` for the authoritative interface contract.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
