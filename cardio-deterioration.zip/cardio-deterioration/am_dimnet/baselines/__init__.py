"""Comparison baselines for AM-DiMNet (SPEC Section 8).

This sub-package collects the methods AM-DiMNet is benchmarked against in the
paper's comparison and ablation tables. They fall into four families, all
consuming the *same* batch-dict contract (SPEC Section 2) so they slot into the
identical train/evaluate loop:

``classical``
    Feature-based tabular classifiers on the explicit 10-dim HRV vector
    (Eq. 5): logistic regression, random forest, and (optional) XGBoost.

``cnn``
    Single-modality deep classifiers (``ECGCNN``, ``PPGCNN``) that reuse the
    AM-DiMNet 1-D waveform encoders with a plain linear risk head.

``fusion_baselines``
    Generic multimodal-fusion strategies over the tabular
    HRV/clinical/proxy/SQI features -- early, late, attention, modality-dropout,
    and adversarial-deconfounding fusion -- lacking the HRV-anchored structured
    factorization of AM-DiMNet.

``foundation``
    Time-series foundation-model wrappers (``MomentBaseline``,
    ``NormWearBaseline``) with a frozen flag, channel adaptation, and a
    downstream head. The pretrained encoder is a documented, swappable stub:
    it loads real checkpoints if provided, otherwise falls back to a
    deterministic random-projection placeholder so the code path is
    reproducible without the external weights.

Every ``nn.Module`` baseline accepts the batch dict and returns risk logits of
shape ``[B]`` (pre-sigmoid), matching ``AMDiMNet(...)["logit"]``.
"""

from __future__ import annotations

from .classical import (
    HRV_FEATURE_ORDER,
    ClassicalBaseline,
    LogRegBaseline,
    RandomForestBaseline,
    XGBoostBaseline,
    XGBOOST_AVAILABLE,
    batch_hrv_matrix,
)
from .cnn import ECGCNN, PPGCNN, WaveformCNNBaseline
from .fusion_baselines import (
    AdversarialDeconfounding,
    AttentionFusion,
    EarlyFusion,
    LateFusion,
    ModalityDropoutFusion,
    tabular_feature_dims,
)
from .foundation import (
    FoundationBaseline,
    MomentBaseline,
    NormWearBaseline,
    RandomProjectionEncoder,
)

__all__ = [
    # classical (Section 8, HRV-feature tabular models)
    "ClassicalBaseline",
    "LogRegBaseline",
    "RandomForestBaseline",
    "XGBoostBaseline",
    "XGBOOST_AVAILABLE",
    "HRV_FEATURE_ORDER",
    "batch_hrv_matrix",
    # single-modality CNNs
    "ECGCNN",
    "PPGCNN",
    "WaveformCNNBaseline",
    # multimodal fusion baselines
    "EarlyFusion",
    "LateFusion",
    "AttentionFusion",
    "ModalityDropoutFusion",
    "AdversarialDeconfounding",
    "tabular_feature_dims",
    # foundation-model baselines
    "FoundationBaseline",
    "MomentBaseline",
    "NormWearBaseline",
    "RandomProjectionEncoder",
]
