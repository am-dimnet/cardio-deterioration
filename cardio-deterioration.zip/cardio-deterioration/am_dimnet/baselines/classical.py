"""Classical HRV-feature baselines (SPEC Section 8, ``classical.py``).

Feature-based tabular classifiers trained on the explicit 10-dimensional HRV
vector (Eq. 5, ``HRV_FEATURES``): logistic regression, random forest, and
(optionally) gradient-boosted trees (XGBoost). These represent the "clinical
HRV panel + shallow classifier" family that AM-DiMNet is compared against and
that the ablations reference.

Unlike the ``nn.Module`` baselines these wrap scikit-learn / xgboost estimators,
so they expose a ``fit`` / ``predict_proba`` / ``predict_logits`` API driven by
:class:`torch.utils.data.DataLoader` batches rather than a ``forward``. Each
consumes the SAME batch dict (SPEC Section 2): the HRV feature matrix is read
from ``batch["hrv"]`` (``[B, 10]``) and the label from ``batch["y"]``.

XGBoost is an *optional* dependency: the import is guarded and
:class:`XGBoostBaseline` raises a clear ``ImportError`` only if it is actually
instantiated without the package installed. ``XGBOOST_AVAILABLE`` lets callers
skip it gracefully (e.g. in the smoke test / benchmark harness).
"""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional

import numpy as np
import torch
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from ..constants import HRV_FEATURES

# --- optional XGBoost import (guarded) -------------------------------------
try:  # pragma: no cover - exercised only where xgboost is installed
    import xgboost as _xgb  # type: ignore

    XGBOOST_AVAILABLE = True
except Exception:  # noqa: BLE001 - any import failure means "unavailable"
    _xgb = None  # type: ignore
    XGBOOST_AVAILABLE = False


__all__ = [
    "HRV_FEATURE_ORDER",
    "ClassicalBaseline",
    "LogRegBaseline",
    "RandomForestBaseline",
    "XGBoostBaseline",
    "XGBOOST_AVAILABLE",
    "batch_hrv_matrix",
]

# The feature ordering is fixed by the SPEC (Eq. 5); exposed for reporting.
HRV_FEATURE_ORDER: List[str] = list(HRV_FEATURES)

_EPS = 1.0e-6


# --------------------------------------------------------------------------
# Batch -> feature-matrix helpers
# --------------------------------------------------------------------------
def batch_hrv_matrix(batch: Dict[str, torch.Tensor]) -> np.ndarray:
    """Extract the ``[B, 10]`` HRV feature matrix from a batch dict (Eq. 5).

    Reads ``batch["hrv"]`` (SPEC Section 2). Windows that dropped the HRV
    modality carry a zero row (mask column = 0); this matches how the classical
    panel would see a missing HRV computation and keeps the design faithful.
    """
    hrv = batch["hrv"]
    if hrv.dim() != 2 or hrv.shape[-1] != len(HRV_FEATURES):
        raise ValueError(
            f"expected batch['hrv'] of shape [B, {len(HRV_FEATURES)}], "
            f"got {tuple(hrv.shape)}"
        )
    return hrv.detach().cpu().float().numpy()


def _stack_loader(loader: Iterable[Dict[str, torch.Tensor]]):
    """Concatenate the HRV matrix and labels across all batches of a loader."""
    xs: List[np.ndarray] = []
    ys: List[np.ndarray] = []
    for batch in loader:
        xs.append(batch_hrv_matrix(batch))
        ys.append(batch["y"].detach().cpu().float().numpy().reshape(-1))
    if not xs:
        raise ValueError("loader yielded no batches; cannot fit classical baseline")
    return np.concatenate(xs, axis=0), np.concatenate(ys, axis=0)


def _probs_to_logits(prob: np.ndarray) -> np.ndarray:
    """Invert the sigmoid: ``logit = log(p / (1 - p))`` with clipping.

    Returned so the classical baselines can be scored with the same
    logit-consuming metric/calibration code as the neural models.
    """
    p = np.clip(prob.astype(np.float64), _EPS, 1.0 - _EPS)
    return np.log(p / (1.0 - p))


# --------------------------------------------------------------------------
# Shared base class
# --------------------------------------------------------------------------
class ClassicalBaseline:
    """Base wrapper around an sklearn-style estimator on HRV features (Eq. 5).

    Subclasses set ``self.model`` to a fitted-able estimator exposing
    ``fit`` / ``predict_proba``. The wrapper adds:

    * ``fit(loader)``          -- stack HRV features + labels and fit;
    * ``predict_proba(batch)`` -- P(deterioration) for a single batch;
    * ``predict_logits(batch)``-- the pre-sigmoid logit ``[B]`` (torch tensor),
      so downstream metric/calibration code is shared with the neural models.

    All estimators consume the SAME batch contract (``batch["hrv"]``).
    """

    name: str = "classical"

    def __init__(self, model) -> None:  # noqa: ANN001 - sklearn estimator
        self.model = model
        self._fitted = False

    # -- training -----------------------------------------------------------
    def fit(self, loader: Iterable[Dict[str, torch.Tensor]]) -> "ClassicalBaseline":
        """Fit on all batches of ``loader`` (HRV matrix vs. binary label)."""
        x, y = _stack_loader(loader)
        self.model.fit(x, y.astype(int))
        self._fitted = True
        return self

    def fit_arrays(self, x: np.ndarray, y: np.ndarray) -> "ClassicalBaseline":
        """Fit directly from a precomputed ``[N,10]`` matrix and label vector."""
        self.model.fit(np.asarray(x, dtype=np.float64), np.asarray(y).astype(int))
        self._fitted = True
        return self

    # -- inference ----------------------------------------------------------
    def _check_fitted(self) -> None:
        if not self._fitted:
            raise RuntimeError(f"{self.name} baseline must be fit() before inference")

    def predict_proba(self, batch: Dict[str, torch.Tensor]) -> np.ndarray:
        """Return P(y=1) for the batch as a ``[B]`` numpy array."""
        self._check_fitted()
        x = batch_hrv_matrix(batch)
        proba = self.model.predict_proba(x)
        # Binary classifier: take the positive-class column robustly.
        classes = list(getattr(self.model, "classes_", [0, 1]))
        pos_col = classes.index(1) if 1 in classes else proba.shape[1] - 1
        return proba[:, pos_col].astype(np.float64)

    def predict_logits(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Return the pre-sigmoid risk logit ``[B]`` as a float32 torch tensor.

        Mirrors the neural baselines' output so the same metric suite / operating
        point selection (SPEC Sections 6-7) applies unchanged.
        """
        prob = self.predict_proba(batch)
        return torch.from_numpy(_probs_to_logits(prob)).float()


# --------------------------------------------------------------------------
# Concrete classifiers
# --------------------------------------------------------------------------
class LogRegBaseline(ClassicalBaseline):
    """L2-regularised logistic regression on standardised HRV features (Eq. 5).

    A :class:`~sklearn.pipeline.Pipeline` of ``StandardScaler`` +
    ``LogisticRegression`` (balanced class weights to match the ~22% prevalence
    setting). This is the simplest linear HRV-panel comparator.
    """

    name = "logreg"

    def __init__(
        self,
        C: float = 1.0,
        max_iter: int = 1000,
        class_weight: Optional[str] = "balanced",
        random_state: int = 42,
    ) -> None:
        model = Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                (
                    "clf",
                    LogisticRegression(
                        C=C,
                        max_iter=max_iter,
                        class_weight=class_weight,
                        random_state=random_state,
                    ),
                ),
            ]
        )
        super().__init__(model)


class RandomForestBaseline(ClassicalBaseline):
    """Random-forest classifier on raw HRV features (Eq. 5).

    Tree ensembles are scale-invariant, so no standardisation is applied.
    ``class_weight="balanced_subsample"`` handles the class imbalance.
    """

    name = "random_forest"

    def __init__(
        self,
        n_estimators: int = 300,
        max_depth: Optional[int] = None,
        min_samples_leaf: int = 2,
        class_weight: Optional[str] = "balanced_subsample",
        random_state: int = 42,
        n_jobs: int = 1,
    ) -> None:
        model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_leaf=min_samples_leaf,
            class_weight=class_weight,
            random_state=random_state,
            n_jobs=n_jobs,
        )
        super().__init__(model)


class XGBoostBaseline(ClassicalBaseline):
    """Gradient-boosted-tree classifier on HRV features (Eq. 5); optional.

    Wraps ``xgboost.XGBClassifier``. XGBoost is an OPTIONAL dependency: the
    import is guarded at module load, and this constructor raises a clear
    ``ImportError`` if the package is missing. Check ``XGBOOST_AVAILABLE`` (or
    catch the error) to skip this comparator gracefully.

    ``scale_pos_weight`` is set from the training prevalence when ``fit`` is
    called on a loader, so the boosting objective is imbalance-aware without the
    caller pre-computing it.
    """

    name = "xgboost"

    def __init__(
        self,
        n_estimators: int = 300,
        max_depth: int = 4,
        learning_rate: float = 0.05,
        subsample: float = 0.8,
        colsample_bytree: float = 0.8,
        random_state: int = 42,
        n_jobs: int = 1,
        scale_pos_weight: Optional[float] = None,
    ) -> None:
        if not XGBOOST_AVAILABLE:  # pragma: no cover - depends on environment
            raise ImportError(
                "xgboost is not installed; XGBoostBaseline is an optional "
                "comparator. Install with `pip install xgboost`, or check "
                "am_dimnet.baselines.XGBOOST_AVAILABLE and skip it."
            )
        self._init_kwargs = dict(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            subsample=subsample,
            colsample_bytree=colsample_bytree,
            random_state=random_state,
            n_jobs=n_jobs,
            eval_metric="logloss",
        )
        self._scale_pos_weight = scale_pos_weight
        model = _xgb.XGBClassifier(  # type: ignore[union-attr]
            **self._init_kwargs,
            scale_pos_weight=scale_pos_weight if scale_pos_weight is not None else 1.0,
        )
        super().__init__(model)

    def fit(self, loader: Iterable[Dict[str, torch.Tensor]]) -> "XGBoostBaseline":
        """Fit with an auto-computed ``scale_pos_weight`` from the label balance."""
        x, y = _stack_loader(loader)
        return self.fit_arrays(x, y)

    def fit_arrays(self, x: np.ndarray, y: np.ndarray) -> "XGBoostBaseline":
        """Fit from arrays; derive ``scale_pos_weight`` = n_neg / n_pos if unset."""
        y_int = np.asarray(y).astype(int)
        if self._scale_pos_weight is None:
            n_pos = float((y_int == 1).sum())
            n_neg = float((y_int == 0).sum())
            spw = (n_neg / max(n_pos, 1.0)) if n_pos > 0 else 1.0
            self.model = _xgb.XGBClassifier(  # type: ignore[union-attr]
                **self._init_kwargs, scale_pos_weight=spw
            )
        self.model.fit(np.asarray(x, dtype=np.float32), y_int)
        self._fitted = True
        return self
