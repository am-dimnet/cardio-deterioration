"""Single-modality CNN baselines (SPEC Section 8, ``cnn.py``).

Deep single-modality classifiers that reuse the AM-DiMNet 1-D waveform encoders
(``ECGEncoder`` / ``PPGEncoder``, Eq. 12-13) followed by a plain linear risk
head. These isolate the contribution of a *single* waveform stream, with none of
the quality-aware fusion, structured factorization, or HRV/activity anchoring
that define AM-DiMNet -- the "unimodal deep net" comparators in the paper's
tables.

Both accept the SAME batch dict (SPEC Section 2) and return risk logits of shape
``[B]`` (pre-sigmoid), matching ``AMDiMNet(...)["logit"]`` so the identical
train / evaluate / calibration pipeline applies.
"""

from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn

from ..config import Config
from ..models.encoders import ECGEncoder, PPGEncoder

__all__ = ["WaveformCNNBaseline", "ECGCNN", "PPGCNN"]


class WaveformCNNBaseline(nn.Module):
    """Generic single-waveform CNN classifier reusing an AM-DiMNet encoder.

    Pipeline: ``X_r [B,1,L] -> encoder -> v_r [B,E] -> Linear head -> logit [B]``.
    A single linear layer keeps the head deliberately minimal so the comparison
    isolates the encoder backbone (Eq. 12-13); dropout matches the model config.

    Args:
        config: AM-DiMNet :class:`Config` (uses ``model.embed_dim`` /
            ``model.dropout``).
        modality: which waveform to read from the batch, ``"ecg"`` or ``"ppg"``.
    """

    def __init__(self, config: Config, modality: str) -> None:
        super().__init__()
        if modality not in ("ecg", "ppg"):
            raise ValueError(f"modality must be 'ecg' or 'ppg', got {modality!r}")
        self.modality = modality
        embed_dim = config.model.embed_dim
        dropout = config.model.dropout

        if modality == "ecg":
            self.encoder: nn.Module = ECGEncoder(embed_dim, dropout)
        else:
            self.encoder = PPGEncoder(embed_dim, dropout)

        # Minimal linear risk head (pre-sigmoid logit); dropout before it.
        self.head = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(embed_dim, 1),
        )

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Return the risk logit ``[B]`` (pre-sigmoid) for the batch.

        The chosen waveform is guaranteed present in the primary cohort
        (``WAVEFORM_MODS``), but the modality mask column is still applied so a
        zero-filled/absent waveform contributes a zero embedding rather than a
        spurious signal.
        """
        x = batch[self.modality]                     # [B, 1, L]
        v = self.encoder(x)                          # [B, E]

        # Respect the availability mask if the modality was dropped.
        from ..data.preprocessing import mask_index  # local import: avoids cycle

        m = batch["mask"][:, mask_index(self.modality)].to(v.dtype)  # [B]
        v = v * m.unsqueeze(-1)

        return self.head(v).squeeze(-1)              # [B]


class ECGCNN(WaveformCNNBaseline):
    """ECG-only CNN classifier (reuses :class:`ECGEncoder`, Eq. 12-13).

    forward: ``batch -> logit [B]`` using only ``batch["ecg"]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__(config, modality="ecg")


class PPGCNN(WaveformCNNBaseline):
    """PPG-only CNN classifier (reuses :class:`PPGEncoder`, Eq. 12-13).

    forward: ``batch -> logit [B]`` using only ``batch["ppg"]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__(config, modality="ppg")
