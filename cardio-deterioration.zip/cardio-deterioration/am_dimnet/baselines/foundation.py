"""Time-series foundation-model baselines (SPEC Section 8, ``foundation.py``).

Wrappers around pretrained time-series foundation encoders --
:class:`MomentBaseline` (MOMENT) and :class:`NormWearBaseline` (NormWear) -- with
a ``frozen`` flag, a learnable channel-adaptation front-end, and a downstream
risk head. They represent the "large pretrained encoder + linear probe / fine-tune"
family AM-DiMNet is compared against.

Because the real checkpoints (and their heavy dependencies) are external, the
pretrained encoder is a DOCUMENTED, SWAPPABLE STUB:

* If a ``checkpoint`` path is given AND a loader is registered/available, the
  real weights are loaded (hook: :meth:`_load_pretrained`).
* Otherwise the encoder falls back to :class:`RandomProjectionEncoder`, a
  deterministic (seeded) frozen random projection. This is NOT a trained model;
  it exists so the code path -- channel adaptation, freezing, pooling, downstream
  head -- is fully reproducible and CPU-runnable without the external weights.
  Swap in the real encoder by subclassing and overriding :meth:`_build_encoder`
  / :meth:`_load_pretrained`.

Both accept the SAME batch dict (SPEC Section 2). Following the SPEC, the
downstream head receives the same explicit HRV / clinical / proxy / SQI / mask
features every batch carries, concatenated with the foundation encoder's pooled
embedding of the ECG+PPG waveform channels. ``forward(batch) -> logit [B]``.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import Config
from ..constants import WAVEFORM_MODS

__all__ = [
    "RandomProjectionEncoder",
    "FoundationBaseline",
    "MomentBaseline",
    "NormWearBaseline",
]


# --------------------------------------------------------------------------
# Deterministic random-projection placeholder encoder
# --------------------------------------------------------------------------
class RandomProjectionEncoder(nn.Module):
    """Deterministic frozen random-projection stand-in for a foundation encoder.

    Maps a multi-channel window ``[B, C, L]`` to a fixed-width embedding
    ``[B, out_dim]`` via adaptive pooling + a *frozen*, seeded random linear
    projection followed by a nonlinearity. It is deterministic given ``seed`` so
    results are reproducible without the external checkpoint, and its parameters
    do not receive gradients (it emulates a frozen pretrained backbone).

    This is explicitly a PLACEHOLDER, not a trained model: it carries no learned
    time-series priors. Replace it with the real MOMENT / NormWear encoder by
    overriding :meth:`FoundationBaseline._build_encoder`.
    """

    def __init__(
        self,
        in_channels: int,
        out_dim: int,
        pool_len: int = 32,
        seed: int = 0,
    ) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.out_dim = out_dim
        self.pool_len = pool_len
        # Deterministic frozen projection weight/bias from a dedicated generator.
        gen = torch.Generator().manual_seed(int(seed))
        proj_in = in_channels * pool_len
        weight = torch.randn(out_dim, proj_in, generator=gen) / (proj_in ** 0.5)
        bias = torch.zeros(out_dim)
        # Register as non-trainable buffers so they persist but never update.
        self.register_buffer("proj_weight", weight)
        self.register_buffer("proj_bias", bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """``[B, C, L] -> [B, out_dim]`` (deterministic, no gradient to weights)."""
        if x.dim() != 3:
            raise ValueError(f"expected [B, C, L] input, got shape {tuple(x.shape)}")
        pooled = F.adaptive_avg_pool1d(x, self.pool_len)   # [B, C, pool_len]
        flat = pooled.flatten(1)                           # [B, C*pool_len]
        emb = F.linear(flat, self.proj_weight, self.proj_bias)
        return torch.tanh(emb)                             # [B, out_dim]

    @property
    def embedding_dim(self) -> int:
        return self.out_dim


# --------------------------------------------------------------------------
# Foundation-model baseline base class
# --------------------------------------------------------------------------
class FoundationBaseline(nn.Module):
    """Base wrapper: channel-adapted foundation encoder + downstream risk head.

    Architecture:

    1. **Channel adaptation** -- the ECG and PPG waveform channels are stacked
       into ``[B, n_wave, L]`` and passed through a learnable ``Conv1d(1x1)``
       that maps ``n_wave -> encoder_in_channels`` (the channel count the
       pretrained backbone expects). This is the standard adapter used to fit a
       fixed-channel foundation model to a new sensor set.
    2. **Foundation encoder** -- produces a pooled embedding ``[B, feat_dim]``.
       Optionally ``frozen`` (no gradient; ``requires_grad_(False)`` + eval-mode
       forward under ``no_grad``), for the linear-probe protocol.
    3. **Downstream head** -- an MLP over ``[foundation_embedding ;
       HRV ; clinical ; proxy ; SQI ; mask]``, exactly the explicit features the
       SPEC says the downstream head must also receive, returning a risk logit
       ``[B]``.

    Subclasses set ``model_name``, ``encoder_in_channels``, ``feat_dim``, and the
    random-projection ``seed``; they may override :meth:`_build_encoder` /
    :meth:`_load_pretrained` to plug in the real checkpoint.

    Args:
        config: AM-DiMNet :class:`Config`.
        frozen: if True the foundation encoder is frozen (linear-probe mode).
        checkpoint: optional path to real pretrained weights; if ``None`` (or the
            load fails) the deterministic random-projection placeholder is used.
    """

    model_name: str = "foundation"
    encoder_in_channels: int = 1
    feat_dim: int = 128
    encoder_seed: int = 0

    def __init__(
        self,
        config: Config,
        frozen: bool = True,
        checkpoint: Optional[str] = None,
    ) -> None:
        super().__init__()
        self.config = config
        self.frozen = bool(frozen)
        self.checkpoint = checkpoint
        self.embed_dim = config.model.embed_dim
        self.dropout = config.model.dropout
        self.wave_mods: List[str] = list(WAVEFORM_MODS)  # ["ecg", "ppg"]

        # (1) Channel adaptation: n_wave -> encoder_in_channels (1x1 conv).
        self.channel_adapter = nn.Conv1d(
            in_channels=len(self.wave_mods),
            out_channels=self.encoder_in_channels,
            kernel_size=1,
        )

        # (2) Pretrained (or placeholder) foundation encoder.
        self.encoder = self._build_encoder(checkpoint)
        self._using_placeholder = isinstance(self.encoder, RandomProjectionEncoder)
        if self.frozen:
            for p in self.encoder.parameters():
                p.requires_grad_(False)

        # (3) Downstream head over [foundation_emb ; explicit tabular features].
        tab_dim = 10 + config.data.clinical_dim + 4 + 6 + 6  # hrv+clin+proxy+sqi+mask
        head_in = self.feat_dim + tab_dim
        hidden = max(self.embed_dim, head_in // 2)
        self.head = nn.Sequential(
            nn.Linear(head_in, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(self.dropout),
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(self.dropout),
            nn.Linear(hidden // 2, 1),
        )

    # -- encoder construction (swappable) -----------------------------------
    def _build_encoder(self, checkpoint: Optional[str]) -> nn.Module:
        """Build the foundation encoder; load real weights if available.

        Default behaviour: try :meth:`_load_pretrained` when a ``checkpoint`` is
        given; on any failure (or no checkpoint) fall back to the deterministic
        :class:`RandomProjectionEncoder` placeholder. Override in a subclass to
        wire in the genuine MOMENT / NormWear module.
        """
        if checkpoint is not None:
            enc = self._load_pretrained(checkpoint)
            if enc is not None:
                return enc
        # Deterministic, reproducible placeholder (documented stub).
        return RandomProjectionEncoder(
            in_channels=self.encoder_in_channels,
            out_dim=self.feat_dim,
            seed=self.encoder_seed,
        )

    def _load_pretrained(self, checkpoint: str) -> Optional[nn.Module]:
        """Hook to load real pretrained weights. Returns ``None`` by default.

        The reference implementation does not vendor the external foundation
        checkpoints (heavyweight, separately licensed). Subclasses / users
        override this to return an ``nn.Module`` mapping ``[B, encoder_in_channels,
        L] -> [B, feat_dim]``. Returning ``None`` triggers the placeholder path.
        """
        return None

    # -- forward ------------------------------------------------------------
    def _waveform_stack(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Stack + mask the waveform channels into ``[B, n_wave, L]``.

        ECG and PPG are resampled to the same length in the batch contract
        (``ecg_len == ppg_len``); if they ever differ we resample PPG to the ECG
        length so the channels can be stacked. Each channel is multiplied by its
        availability mask.
        """
        from ..data.preprocessing import mask_index  # local import: avoid cycle

        ecg = batch["ecg"]                       # [B, 1, L]
        ppg = batch["ppg"]                       # [B, 1, L']
        if ppg.shape[-1] != ecg.shape[-1]:
            ppg = F.interpolate(ppg, size=ecg.shape[-1], mode="linear", align_corners=False)
        dtype = ecg.dtype
        m_ecg = batch["mask"][:, mask_index("ecg")].to(dtype).view(-1, 1, 1)
        m_ppg = batch["mask"][:, mask_index("ppg")].to(dtype).view(-1, 1, 1)
        chans = torch.cat([ecg * m_ecg, ppg * m_ppg], dim=1)  # [B, 2, L]
        return chans

    def _tabular(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Concatenate the explicit tabular features (SPEC downstream-head input)."""
        dtype = batch["hrv"].dtype
        return torch.cat(
            [
                batch["hrv"].to(dtype),        # [B, 10]
                batch["clinical"].to(dtype),   # [B, clinical_dim]
                batch["proxy"].to(dtype),      # [B, 4]
                batch["sqi"].to(dtype),        # [B, 6]
                batch["mask"].to(dtype),       # [B, 6]
            ],
            dim=-1,
        )

    def _encode(self, chans: torch.Tensor) -> torch.Tensor:
        """Channel-adapt + run the (optionally frozen) foundation encoder.

        When ``frozen`` (linear-probe protocol), the encoder's *own* parameters
        are already ``requires_grad_(False)`` from ``__init__``, so they never
        update. We deliberately do NOT wrap the encoder in ``no_grad`` / detach
        its output: gradients must still flow *through* the frozen backbone back
        to the trainable channel adapter upstream (autograd simply produces no
        parameter gradients for the frozen weights). The encoder is put in eval
        mode so its BatchNorm / dropout (in a real checkpoint) stay in inference
        statistics.
        """
        adapted = self.channel_adapter(chans)       # [B, enc_in, L]
        if self.frozen:
            was_training = self.encoder.training
            self.encoder.eval()
            emb = self.encoder(adapted)             # [B, feat_dim]; grad flows to adapter
            if was_training:
                self.encoder.train()
        else:
            emb = self.encoder(adapted)             # [B, feat_dim]
        return emb

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Return the risk logit ``[B]`` (pre-sigmoid)."""
        chans = self._waveform_stack(batch)          # [B, 2, L]
        emb = self._encode(chans)                    # [B, feat_dim]
        feats = torch.cat([emb, self._tabular(batch)], dim=-1)
        return self.head(feats).squeeze(-1)          # [B]

    # -- introspection ------------------------------------------------------
    @property
    def using_placeholder(self) -> bool:
        """True if the deterministic placeholder encoder is in use (no weights)."""
        return self._using_placeholder


# --------------------------------------------------------------------------
# Concrete foundation baselines
# --------------------------------------------------------------------------
class MomentBaseline(FoundationBaseline):
    """MOMENT foundation-model baseline (Goswami et al., 2024).

    MOMENT is a channel-independent transformer pretrained on broad time-series
    corpora. Here it is wrapped with channel adaptation to the ECG/PPG sensor set
    and a downstream head over the pretrained embedding plus the explicit tabular
    features. The pretrained encoder is a swappable stub (see module docstring);
    supply ``checkpoint`` and override :meth:`_load_pretrained` to use real
    MOMENT weights.
    """

    model_name = "moment"
    encoder_in_channels = 1   # MOMENT is channel-independent (single channel).
    feat_dim = 128
    encoder_seed = 20240

    def __init__(
        self, config: Config, frozen: bool = True, checkpoint: Optional[str] = None
    ) -> None:
        super().__init__(config, frozen=frozen, checkpoint=checkpoint)


class NormWearBaseline(FoundationBaseline):
    """NormWear foundation-model baseline (wearable-sensor foundation encoder).

    NormWear targets multi-channel wearable physiological signals, so the channel
    adapter maps the ECG/PPG pair into its expected multi-channel input. As with
    MOMENT, the pretrained encoder is a documented swappable stub; provide
    ``checkpoint`` and override :meth:`_load_pretrained` for real weights.
    """

    model_name = "normwear"
    encoder_in_channels = 2   # multi-channel wearable encoder.
    feat_dim = 128
    encoder_seed = 77712

    def __init__(
        self, config: Config, frozen: bool = True, checkpoint: Optional[str] = None
    ) -> None:
        super().__init__(config, frozen=frozen, checkpoint=checkpoint)
