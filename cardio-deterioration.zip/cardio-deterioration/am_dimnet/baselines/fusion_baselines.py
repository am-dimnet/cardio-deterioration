"""Multimodal-fusion baselines (SPEC Section 8, ``fusion_baselines.py``).

Generic multimodal-fusion strategies over the explicit *tabular* feature
modalities available in every batch -- HRV (Eq. 5), clinical metadata, and the
4-dim activity/motion proxy (Eq. 7) -- together with their SQI (Eq. 10) and
availability mask (Eq. 11). These stand in for the "standard fusion" literature
that AM-DiMNet is compared against: they mix modalities but LACK the HRV-anchored
autonomic-morphological structured factorization, so they cannot separate
autonomic vs. morphological vs. activity-driven risk.

Implemented comparators:

* :class:`EarlyFusion`            -- concatenate features, one MLP.
* :class:`LateFusion`             -- per-modality MLPs, average of logits.
* :class:`AttentionFusion`        -- learned attention over per-modality
                                     embeddings (no quality/mask conditioning).
* :class:`ModalityDropoutFusion`  -- early fusion trained with random
                                     modality dropout for robustness.
* :class:`AdversarialDeconfounding` -- early fusion + an activity discriminator
                                     on the shared representation through a
                                     gradient-reversal layer (Eq. 23-style), but
                                     WITHOUT structured factors.

All accept the SAME batch dict (SPEC Section 2) and return risk logits ``[B]``
(pre-sigmoid), matching ``AMDiMNet(...)["logit"]``. Modalities are masked with
``batch["mask"]`` so a dropped modality contributes a zero embedding, and SQI is
appended to the input features where the design conditions on quality.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import torch
import torch.nn as nn

from ..config import Config
from ..constants import N_ACTIVITY_CLASSES
from ..models.heads import grad_reverse

__all__ = [
    "EarlyFusion",
    "LateFusion",
    "AttentionFusion",
    "ModalityDropoutFusion",
    "AdversarialDeconfounding",
    "tabular_feature_dims",
    "TABULAR_MODS",
]

# Tabular feature modalities used by the fusion baselines. ECG/PPG/PCG waveforms
# are handled by the CNN / foundation baselines; the fusion comparators operate
# on the explicit feature vectors that every batch carries, per the SPEC note
# that "HRV, clinical, SQI, masks available".
TABULAR_MODS: List[str] = ["hrv", "clinical", "proxy"]


def tabular_feature_dims(config: Config) -> Dict[str, int]:
    """Return the input dimension of each tabular modality (SPEC Section 2).

    ``hrv`` = 10 (Eq. 5), ``proxy`` = 4 (Eq. 7), ``clinical`` = ``clinical_dim``.
    """
    return {
        "hrv": 10,
        "clinical": config.data.clinical_dim,
        "proxy": 4,
    }


def _mod_sqi_mask(
    batch: Dict[str, torch.Tensor], mod: str, dtype: torch.dtype
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Return the ``[B,1]`` SQI and mask columns for ``mod`` (Eq. 10-11)."""
    from ..data.preprocessing import mask_index, sqi_index  # local: avoid cycle

    q = batch["sqi"][:, sqi_index(mod)].to(dtype).unsqueeze(-1)   # [B,1]
    m = batch["mask"][:, mask_index(mod)].to(dtype).unsqueeze(-1)  # [B,1]
    return q, m


class _ModalityEncoders(nn.Module):
    """Shared per-modality tabular encoders producing ``[B, embed_dim]`` each.

    Each modality is encoded by a small MLP; the resulting embedding is
    multiplied by the availability mask so absent modalities contribute zero.
    ``condition_on_sqi`` appends the modality SQI to the raw features so
    quality-aware variants can down-weight noisy inputs (still far weaker than
    the AM-DiMNet quality-aware gate of Eq. 14).
    """

    def __init__(
        self, config: Config, condition_on_sqi: bool = False
    ) -> None:
        super().__init__()
        self.embed_dim = config.model.embed_dim
        self.dropout = config.model.dropout
        self.condition_on_sqi = condition_on_sqi
        self.mods = list(TABULAR_MODS)
        dims = tabular_feature_dims(config)

        self.encoders = nn.ModuleDict()
        for mod in self.mods:
            in_dim = dims[mod] + (1 if condition_on_sqi else 0)
            hidden = max(self.embed_dim, 2 * in_dim)
            self.encoders[mod] = nn.Sequential(
                nn.Linear(in_dim, hidden),
                nn.LayerNorm(hidden),
                nn.GELU(),
                nn.Dropout(self.dropout),
                nn.Linear(hidden, self.embed_dim),
            )

    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Return a dict mapping each tabular modality to ``[B, embed_dim]``."""
        ref = batch["hrv"]
        dtype = ref.dtype
        out: Dict[str, torch.Tensor] = {}
        for mod in self.mods:
            x = batch[mod].to(dtype)                       # [B, d_mod]
            q, m = _mod_sqi_mask(batch, mod, dtype)        # [B,1], [B,1]
            if self.condition_on_sqi:
                x = torch.cat([x, q], dim=-1)              # [B, d_mod+1]
            v = self.encoders[mod](x)                      # [B, E]
            out[mod] = v * m                               # mask absent modality
        return out


# --------------------------------------------------------------------------
# Early fusion
# --------------------------------------------------------------------------
class EarlyFusion(nn.Module):
    """Feature-level (early) fusion baseline.

    Concatenates the masked per-modality features (HRV, clinical, proxy) plus
    the full SQI/mask vectors and feeds them to a single MLP risk head. This is
    the canonical "concatenate everything" fusion comparator; it has no
    mechanism to disentangle autonomic vs. morphological vs. activity effects.

    forward: ``batch -> logit [B]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        self.mods = list(TABULAR_MODS)
        dims = tabular_feature_dims(config)
        # concat(masked features) + sqi[6] + mask[6]
        in_dim = sum(dims[m] for m in self.mods) + 6 + 6
        hidden = max(config.model.embed_dim, in_dim)
        dropout = config.model.dropout
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def _features(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        dtype = batch["hrv"].dtype
        parts: List[torch.Tensor] = []
        for mod in self.mods:
            _, m = _mod_sqi_mask(batch, mod, dtype)
            parts.append(batch[mod].to(dtype) * m)     # mask absent modality
        parts.append(batch["sqi"].to(dtype))
        parts.append(batch["mask"].to(dtype))
        return torch.cat(parts, dim=-1)

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        return self.net(self._features(batch)).squeeze(-1)   # [B]


# --------------------------------------------------------------------------
# Late fusion
# --------------------------------------------------------------------------
class LateFusion(nn.Module):
    """Decision-level (late) fusion baseline.

    A separate MLP head produces a per-modality logit; the final logit is the
    mask-weighted mean of the available modalities' logits. Fuses *decisions*
    rather than representations, so cross-modal interactions are lost.

    forward: ``batch -> logit [B]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        self.mods = list(TABULAR_MODS)
        dims = tabular_feature_dims(config)
        dropout = config.model.dropout
        embed_dim = config.model.embed_dim
        self.heads = nn.ModuleDict()
        for mod in self.mods:
            in_dim = dims[mod] + 1  # + SQI so quality informs each expert
            hidden = max(embed_dim, 2 * in_dim)
            self.heads[mod] = nn.Sequential(
                nn.Linear(in_dim, hidden),
                nn.LayerNorm(hidden),
                nn.GELU(),
                nn.Dropout(dropout),
                nn.Linear(hidden, 1),
            )

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        dtype = batch["hrv"].dtype
        logits: List[torch.Tensor] = []
        masks: List[torch.Tensor] = []
        for mod in self.mods:
            q, m = _mod_sqi_mask(batch, mod, dtype)             # [B,1] each
            x = torch.cat([batch[mod].to(dtype), q], dim=-1)    # [B, d+1]
            logits.append(self.heads[mod](x))                   # [B,1]
            masks.append(m)                                     # [B,1]
        logit_mat = torch.cat(logits, dim=-1)                   # [B, M]
        mask_mat = torch.cat(masks, dim=-1)                     # [B, M]
        # Mask-weighted mean over available modalities (avoid div-by-zero).
        denom = mask_mat.sum(dim=-1, keepdim=True).clamp_min(1.0)  # [B,1]
        fused = (logit_mat * mask_mat).sum(dim=-1, keepdim=True) / denom
        return fused.squeeze(-1)                                 # [B]


# --------------------------------------------------------------------------
# Attention fusion
# --------------------------------------------------------------------------
class AttentionFusion(nn.Module):
    """Attention-weighted representation fusion baseline.

    Per-modality embeddings are combined via a learned additive-attention
    scorer over the embedding alone (no explicit quality/mask term in the score,
    unlike AM-DiMNet's quality-aware gate of Eq. 14). Masked modalities receive
    ``-inf`` attention logits so they are excluded from the softmax.

    forward: ``batch -> logit [B]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        embed_dim = config.model.embed_dim
        dropout = config.model.dropout
        self.mods = list(TABULAR_MODS)
        self.encoders = _ModalityEncoders(config, condition_on_sqi=True)
        # Additive attention scorer over the embedding (shared across modalities).
        self.attn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.Tanh(),
            nn.Linear(embed_dim // 2, 1),
        )
        self.head = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim // 2, 1),
        )

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        v = self.encoders(batch)                                  # dict[mod]->[B,E]
        dtype = batch["hrv"].dtype
        embs = torch.stack([v[m] for m in self.mods], dim=1)      # [B, M, E]
        scores = self.attn(embs).squeeze(-1)                      # [B, M]

        # Availability mask for each modality (order = self.mods).
        from ..data.preprocessing import mask_index  # local import: avoid cycle

        mask_cols = torch.stack(
            [batch["mask"][:, mask_index(m)].to(dtype) for m in self.mods], dim=1
        )                                                          # [B, M]
        # Exclude absent modalities from the softmax.
        neg_inf = torch.finfo(scores.dtype).min
        scores = scores.masked_fill(mask_cols < 0.5, neg_inf)
        alpha = torch.softmax(scores, dim=1).unsqueeze(-1)         # [B, M, 1]
        fused = (alpha * embs).sum(dim=1)                          # [B, E]
        return self.head(fused).squeeze(-1)                       # [B]


# --------------------------------------------------------------------------
# Modality-dropout fusion
# --------------------------------------------------------------------------
class ModalityDropoutFusion(nn.Module):
    """Early fusion trained with random modality dropout for robustness.

    Identical inference to :class:`EarlyFusion`, but during training each present
    modality is independently zeroed with probability ``train.modality_dropout``
    (SPEC / Table 4). This is the "train-time modality dropout" robustness
    comparator; it improves missing-modality robustness but still lacks
    structured factorization.

    forward: ``batch -> logit [B]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        self.mods = list(TABULAR_MODS)
        self.p_drop = float(config.train.modality_dropout)
        self.core = EarlyFusion(config)

    def _apply_dropout(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Return a shallow-copied batch with random modality masks zeroed."""
        from ..data.preprocessing import mask_index  # local import: avoid cycle

        mask = batch["mask"].clone()
        b = mask.shape[0]
        for mod in self.mods:
            col = mask_index(mod)
            present = mask[:, col] > 0.5
            drop = (torch.rand(b, device=mask.device) < self.p_drop) & present
            mask[drop, col] = 0.0
        new_batch = dict(batch)
        new_batch["mask"] = mask
        return new_batch

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        if self.training and self.p_drop > 0.0:
            batch = self._apply_dropout(batch)
        return self.core(batch)                                   # [B]


# --------------------------------------------------------------------------
# Adversarial deconfounding fusion
# --------------------------------------------------------------------------
class AdversarialDeconfounding(nn.Module):
    """Early fusion with an activity adversary through gradient reversal.

    A shared representation is learned from the tabular modalities; the risk head
    predicts deterioration while an *adversarial* activity classifier -- fed the
    representation through a gradient-reversal layer (:func:`grad_reverse`,
    Eq. 23-style) -- pushes the shared representation to be activity-invariant.

    This is the closest non-factorized comparator to AM-DiMNet's deconfounding:
    it removes activity confounding from a SINGLE entangled representation,
    whereas AM-DiMNet applies the adversary to structured ``z_auto`` / ``z_morph``
    factors only, preserving legitimate morphology.

    ``forward(batch)`` returns the risk logit ``[B]`` (matching the common
    contract). The adversarial activity logits are exposed via
    :meth:`forward_with_adv` so a trainer can add the activity CE term; the GRL
    strength is read from the ``adv_lambda`` attribute (settable by the trainer,
    default 1.0), mirroring ``AMDiMNet.adv_lambda``.

    forward: ``batch -> logit [B]``.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        self.mods = list(TABULAR_MODS)
        embed_dim = config.model.embed_dim
        dropout = config.model.dropout
        dims = tabular_feature_dims(config)
        in_dim = sum(dims[m] for m in self.mods) + 6 + 6  # + sqi[6] + mask[6]

        # Shared representation trunk.
        self.trunk = nn.Sequential(
            nn.Linear(in_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout),
        )
        # Risk head over the shared representation.
        self.risk_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim // 2, 1),
        )
        # Adversarial activity discriminator (fed through grad_reverse).
        self.adv_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.GELU(),
            nn.Linear(embed_dim // 2, N_ACTIVITY_CLASSES),
        )
        # GRL strength; trainer may schedule/warm this up (mirrors AMDiMNet).
        self.adv_lambda: float = 1.0

    def _features(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        dtype = batch["hrv"].dtype
        parts: List[torch.Tensor] = []
        for mod in self.mods:
            _, m = _mod_sqi_mask(batch, mod, dtype)
            parts.append(batch[mod].to(dtype) * m)
        parts.append(batch["sqi"].to(dtype))
        parts.append(batch["mask"].to(dtype))
        return torch.cat(parts, dim=-1)

    def represent(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Return the shared representation ``[B, embed_dim]``."""
        return self.trunk(self._features(batch))

    def forward_with_adv(
        self, batch: Dict[str, torch.Tensor]
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return ``(logit [B], adv_activity_logits [B, N_ACTIVITY_CLASSES])``.

        The adversary consumes ``grad_reverse(rep, adv_lambda)`` so minimizing the
        activity cross-entropy trains the discriminator while making the shared
        representation activity-invariant (Eq. 23).
        """
        rep = self.represent(batch)                               # [B, E]
        logit = self.risk_head(rep).squeeze(-1)                   # [B]
        adv_logits = self.adv_head(grad_reverse(rep, self.adv_lambda))
        return logit, adv_logits

    def forward(self, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        logit, _ = self.forward_with_adv(batch)
        return logit                                              # [B]
