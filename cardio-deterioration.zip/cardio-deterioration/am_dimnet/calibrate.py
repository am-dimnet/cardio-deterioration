"""Post-hoc probability calibration and operating-threshold selection.

Two calibration maps are provided, both *fit on the validation split* and then
applied frozen to the test split (SPEC section 6):

* :class:`TemperatureScaler` — single-parameter temperature scaling (Guo et al.,
  2017).  A scalar temperature :math:`T > 0` rescales the logits,
  :math:`\\hat{p} = \\sigma(z / T)`, and is fit by minimising validation NLL with
  L-BFGS (torch).  It is monotone, preserves AUROC/ranking, and only recalibrates
  confidence.
* :class:`IsotonicScaler` — non-parametric isotonic regression on probabilities
  (a flexible monotone map; can change the score distribution more aggressively).

:func:`select_operating_threshold` picks a decision threshold on the validation
split under one of three targets: Youden's J, F1, or a sensitivity floor.

All fitted objects expose ``transform``/``__call__`` returning plain numpy arrays
of calibrated probabilities.
"""

from __future__ import annotations

from typing import Iterable, Union

import numpy as np
import torch
from sklearn.isotonic import IsotonicRegression


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _as_1d_float_np(a: Iterable) -> np.ndarray:
    return np.asarray(a, dtype=np.float64).reshape(-1)


def _sigmoid_np(z: np.ndarray) -> np.ndarray:
    """Numerically stable logistic sigmoid on a numpy array."""
    out = np.empty_like(z, dtype=np.float64)
    pos = z >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-z[pos]))
    ez = np.exp(z[~pos])
    out[~pos] = ez / (1.0 + ez)
    return out


# ---------------------------------------------------------------------------
# Temperature scaling
# ---------------------------------------------------------------------------
class TemperatureScaler:
    """Single-parameter temperature scaling of logits (Guo et al., 2017).

    Calibrated probability for logit :math:`z` is
    :math:`\\hat{p} = \\sigma(z / T)` with a single learned temperature
    :math:`T > 0`.  ``T`` is parameterised as ``T = softplus(raw) + eps`` to keep
    it strictly positive during unconstrained L-BFGS optimisation, and is fit by
    minimising binary cross-entropy (negative log-likelihood) on the validation
    logits.

    Because the map is a strictly increasing function of the logit, it leaves the
    ranking (hence AUROC/AUPRC) unchanged and only adjusts calibration.

    Attributes
    ----------
    temperature : float
        The fitted temperature (``1.0`` before fitting).
    """

    def __init__(self, eps: float = 1e-6) -> None:
        self.eps = float(eps)
        self.temperature: float = 1.0
        self._fitted: bool = False

    def fit(
        self,
        logits: Iterable,
        y: Iterable,
        max_iter: int = 100,
        lr: float = 0.05,
    ) -> "TemperatureScaler":
        """Fit the temperature on validation ``logits``/labels via L-BFGS.

        Parameters
        ----------
        logits : array
            Pre-sigmoid model outputs on the validation set, shape ``[N]``.
        y : array
            Binary validation labels ``{0, 1}``, shape ``[N]``.
        max_iter : int
            Maximum L-BFGS iterations.
        lr : float
            L-BFGS learning rate.
        """
        z = torch.as_tensor(_as_1d_float_np(logits), dtype=torch.float64)
        t = torch.as_tensor(_as_1d_float_np(y), dtype=torch.float64)
        if z.numel() == 0:
            raise ValueError("empty logits")
        if z.shape != t.shape:
            raise ValueError("logits and y must have equal length")

        # Unconstrained parameter -> T = softplus(raw) + eps  (>0, starts ~1.0).
        # softplus(0.5413) ~= 1.0, so raw0 gives an initial temperature of ~1.
        raw = torch.nn.Parameter(torch.tensor(0.5413, dtype=torch.float64))
        eps = torch.tensor(self.eps, dtype=torch.float64)
        bce = torch.nn.BCEWithLogitsLoss()
        optimizer = torch.optim.LBFGS(
            [raw], lr=lr, max_iter=int(max_iter), line_search_fn="strong_wolfe"
        )

        def _closure() -> torch.Tensor:
            optimizer.zero_grad()
            temp = torch.nn.functional.softplus(raw) + eps
            loss = bce(z / temp, t)
            loss.backward()
            return loss

        optimizer.step(_closure)

        with torch.no_grad():
            temp = torch.nn.functional.softplus(raw) + eps
            self.temperature = float(temp.item())
        self._fitted = True
        return self

    def transform(self, logits: Iterable) -> np.ndarray:
        """Map validation/test ``logits`` to calibrated probabilities."""
        z = _as_1d_float_np(logits)
        return _sigmoid_np(z / self.temperature)

    def transform_logits(self, logits: Iterable) -> np.ndarray:
        """Return the temperature-scaled logits ``z / T`` (for downstream use)."""
        z = _as_1d_float_np(logits)
        return z / self.temperature

    def __call__(self, logits: Iterable) -> np.ndarray:
        return self.transform(logits)


# ---------------------------------------------------------------------------
# Isotonic regression calibration
# ---------------------------------------------------------------------------
class IsotonicScaler:
    """Non-parametric isotonic-regression calibration on probabilities.

    Fits a monotone non-decreasing map from *predicted probability* to
    *calibrated probability* by pool-adjacent-violators on the validation split.
    Unlike temperature scaling it can reshape the score distribution and is not
    restricted to a single parameter, at the cost of higher variance on small
    validation sets.  Out-of-range inputs are clipped to the fitted domain
    (``out_of_bounds='clip'``).
    """

    def __init__(self) -> None:
        self._iso = IsotonicRegression(
            y_min=0.0, y_max=1.0, out_of_bounds="clip", increasing=True
        )
        self._fitted: bool = False

    def fit(self, prob: Iterable, y: Iterable) -> "IsotonicScaler":
        """Fit the isotonic map on validation probabilities/labels."""
        p = _as_1d_float_np(prob)
        t = _as_1d_float_np(y)
        if p.shape != t.shape:
            raise ValueError("prob and y must have equal length")
        if p.size == 0:
            raise ValueError("empty prob")
        self._iso.fit(p, t)
        self._fitted = True
        return self

    def transform(self, prob: Iterable) -> np.ndarray:
        """Map probabilities to calibrated probabilities."""
        if not self._fitted:
            raise RuntimeError("IsotonicScaler must be fit before transform")
        p = _as_1d_float_np(prob)
        return np.asarray(self._iso.predict(p), dtype=np.float64)

    def __call__(self, prob: Iterable) -> np.ndarray:
        return self.transform(prob)


# ---------------------------------------------------------------------------
# operating-threshold selection
# ---------------------------------------------------------------------------
def select_operating_threshold(
    prob_val: Iterable,
    y_val: Iterable,
    target: Union[str, float] = "youden",
) -> float:
    """Select a decision threshold on the validation split.

    Candidate thresholds are the distinct predicted probabilities (plus the
    trivial ``0`` boundary), evaluated exhaustively.

    Targets
    -------
    ``"youden"``
        Maximise Youden's J = sensitivity + specificity - 1.
    ``"f1"``
        Maximise the F1 score of the positive class.
    ``float`` in ``(0, 1]`` (or the string form of a float)
        Interpreted as a **sensitivity floor**: choose the *highest* threshold
        whose sensitivity is at least this value (maximising specificity /
        minimising alarm rate subject to the recall constraint).  If no
        threshold meets the floor, return the threshold with the highest
        achievable sensitivity.

    Returns
    -------
    float
        The selected probability threshold; a positive prediction is
        ``prob >= threshold``.
    """
    p = _as_1d_float_np(prob_val)
    t = _as_1d_float_np(y_val).astype(np.int64)
    if p.shape[0] != t.shape[0]:
        raise ValueError("prob_val and y_val must have equal length")
    if p.size == 0:
        raise ValueError("empty prob_val")

    # Candidate thresholds: sorted unique probs, plus 0.0 so "flag everything"
    # is reachable.  Using >= for the decision means each unique prob is a
    # meaningful cut point.
    cand = np.unique(np.concatenate([[0.0], p]))
    pos = int(t.sum())
    neg = int((t == 0).sum())

    def _confusion(thr: float):
        yhat = (p >= thr).astype(np.int64)
        tp = int(np.sum((yhat == 1) & (t == 1)))
        fp = int(np.sum((yhat == 1) & (t == 0)))
        tn = int(np.sum((yhat == 0) & (t == 0)))
        fn = int(np.sum((yhat == 0) & (t == 1)))
        return tp, fp, tn, fn

    # Parse the target: string keyword vs numeric sensitivity floor.
    mode = None
    floor = None
    if isinstance(target, str):
        key = target.strip().lower()
        if key in ("youden", "f1"):
            mode = key
        else:
            try:
                floor = float(key)
                mode = "sensitivity_floor"
            except ValueError as exc:  # pragma: no cover - defensive
                raise ValueError(
                    f"unknown target {target!r}; expected 'youden', 'f1', "
                    "or a sensitivity floor in (0, 1]"
                ) from exc
    else:
        floor = float(target)
        mode = "sensitivity_floor"

    if mode == "youden":
        best_thr = float(cand[0])
        best_j = -np.inf
        for thr in cand:
            tp, fp, tn, fn = _confusion(thr)
            sens = tp / pos if pos > 0 else 0.0
            spec = tn / neg if neg > 0 else 0.0
            j = sens + spec - 1.0
            if j > best_j:
                best_j = j
                best_thr = float(thr)
        return best_thr

    if mode == "f1":
        best_thr = float(cand[0])
        best_f1 = -np.inf
        for thr in cand:
            tp, fp, tn, fn = _confusion(thr)
            denom = 2 * tp + fp + fn
            f1 = (2.0 * tp / denom) if denom > 0 else 0.0
            if f1 > best_f1:
                best_f1 = f1
                best_thr = float(thr)
        return best_thr

    # sensitivity_floor
    if floor is None or not (0.0 < floor <= 1.0):
        raise ValueError("sensitivity floor must be in (0, 1]")
    best_meeting_thr = None
    best_meeting_spec = -np.inf
    # Fallback: track the threshold with maximal sensitivity if the floor is
    # unattainable.
    fallback_thr = float(cand[0])
    fallback_sens = -np.inf
    for thr in cand:
        tp, fp, tn, fn = _confusion(thr)
        sens = tp / pos if pos > 0 else 0.0
        spec = tn / neg if neg > 0 else 0.0
        if sens > fallback_sens:
            fallback_sens = sens
            fallback_thr = float(thr)
        if sens >= floor:
            # Among thresholds meeting the floor, prefer the one with the best
            # specificity; ties broken toward the higher threshold (lower alarm
            # rate) via >= and ascending iteration.
            if spec >= best_meeting_spec:
                best_meeting_spec = spec
                best_meeting_thr = float(thr)
    if best_meeting_thr is not None:
        return best_meeting_thr
    return fallback_thr


__all__ = [
    "TemperatureScaler",
    "IsotonicScaler",
    "select_operating_threshold",
]
