"""Configuration schema for AM-DiMNet (SPEC Section 1).

Defines the nested dataclasses ``DataCfg``, ``ModelCfg``, ``TrainCfg``,
``LossCfg`` and the top-level ``Config`` aggregate. Default values match the
implementation settings table (Table 4) and the default loss weights
(Eq. loss_weights, Section IV):

    lambda_hrv=0.35, lambda_morph=0.28, lambda_act=0.20,
    lambda_adv=0.15, lambda_orth=0.06, lambda_cal=0.08.

``Config.default()`` builds the reference configuration; ``Config.load(path)``
reads a YAML file that mirrors this schema (see ``configs/default.yaml``);
``Config.to_dict()`` serialises back to a plain nested dict.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# --------------------------------------------------------------------------
# Nested configuration groups
# --------------------------------------------------------------------------
@dataclass
class DataCfg:
    """Windowing, sampling, and per-modality input dimensions (Table 4).

    Fields mirror the leakage-safe temporal structure (Eq. 1-3): a 5-min
    observation window, 60-s sliding step, 1.5-h gap, and 24-h horizon.
    """

    window_min: float = 5.0      # observation window length (minutes)
    step_s: int = 60             # sliding step (seconds)
    gap_h: float = 1.5           # leakage-prevention gap Delta_g (hours)
    horizon_h: float = 24.0      # prediction horizon Delta_p (hours)
    ecg_len: int = 512           # resampled ECG samples per encoder input
    ppg_len: int = 512           # resampled PPG samples per encoder input
    pcg_mels: int = 64           # PCG log-Mel bins
    pcg_frames: int = 128        # PCG spectrogram frames
    clinical_dim: int = 16       # clinical metadata feature dimension
    morph_dim: int = 24          # morphological descriptor target dimension (Eq. 20)


@dataclass
class ModelCfg:
    """Architecture hyper-parameters (Table 4).

    ``embed_dim`` is the shared embedding dimension into which every modality
    is projected (Eq. 13); ``latent_dim`` is the per-factor latent size (Eq. 16);
    ``gate_eps`` is the numerical-stability constant in the fusion gate (Eq. 14).
    """

    embed_dim: int = 128         # shared embedding dimension
    latent_dim: int = 32         # per-factor latent dimension
    gate_eps: float = 1.0e-6     # epsilon in the quality-aware gate (Eq. 14)
    dropout: float = 0.27        # dropout rate


@dataclass
class TrainCfg:
    """Optimisation and training-protocol settings (Table 4)."""

    batch_size: int = 96
    lr: float = 7.5e-4
    weight_decay: float = 1.2e-4
    max_epochs: int = 120
    patience: int = 16                       # early-stopping patience (epochs)
    modality_dropout: float = 0.18           # modality-dropout augmentation rate
    seeds: List[int] = field(default_factory=lambda: [11, 23, 42, 71, 97])
    pos_weight: Optional[float] = None       # auto from prevalence if None (Eq. 26)


@dataclass
class LossCfg:
    """Multi-task loss weights (Eq. loss_weights / Eq. 28).

    total = L_risk + lambda_hrv L_hrv + lambda_morph L_morph
            + lambda_act L_act + lambda_adv L_adv
            + lambda_orth L_orth + lambda_cal L_cal.
    """

    lambda_hrv: float = 0.35     # autonomic (HRV) anchoring weight
    lambda_morph: float = 0.28   # morphology anchoring weight
    lambda_act: float = 0.20     # activity-classification weight
    lambda_adv: float = 0.15     # adversarial deconfounding weight
    lambda_orth: float = 0.06    # latent orthogonality weight
    lambda_cal: float = 0.08     # Brier calibration weight


# --------------------------------------------------------------------------
# Top-level aggregate
# --------------------------------------------------------------------------
@dataclass
class Config:
    """Top-level AM-DiMNet configuration aggregate (SPEC Section 1)."""

    data: DataCfg = field(default_factory=DataCfg)
    model: ModelCfg = field(default_factory=ModelCfg)
    train: TrainCfg = field(default_factory=TrainCfg)
    loss: LossCfg = field(default_factory=LossCfg)

    # -- Construction -------------------------------------------------------
    @classmethod
    def default(cls) -> "Config":
        """Return the reference configuration with all Table 4 defaults."""
        return cls()

    @classmethod
    def from_dict(cls, d: Optional[Dict[str, Any]]) -> "Config":
        """Build a :class:`Config` from a (possibly partial) nested dict.

        Unknown keys are ignored; omitted keys fall back to the dataclass
        defaults, so a partial YAML overrides only the fields it specifies.
        """
        d = dict(d or {})

        def _group(cls_, key):
            sub = d.get(key) or {}
            valid = {f.name for f in dataclasses.fields(cls_)}
            kwargs = {k: v for k, v in sub.items() if k in valid}
            return cls_(**kwargs)

        return cls(
            data=_group(DataCfg, "data"),
            model=_group(ModelCfg, "model"),
            train=_group(TrainCfg, "train"),
            loss=_group(LossCfg, "loss"),
        )

    @classmethod
    def load(cls, yaml_path: str) -> "Config":
        """Load a configuration from a YAML file mirroring this schema."""
        try:
            import yaml  # local import so the base package stays light
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise ImportError(
                "PyYAML is required for Config.load(); install with `pip install pyyaml`."
            ) from exc
        with open(yaml_path, "r", encoding="utf-8") as fh:
            raw = yaml.safe_load(fh)
        return cls.from_dict(raw)

    # -- Serialisation ------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        """Serialise to a plain nested dict (round-trips with ``from_dict``)."""
        return {
            "data": dataclasses.asdict(self.data),
            "model": dataclasses.asdict(self.model),
            "train": dataclasses.asdict(self.train),
            "loss": dataclasses.asdict(self.loss),
        }

    def save(self, yaml_path: str) -> None:
        """Write this configuration to a YAML file."""
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover - dependency guard
            raise ImportError(
                "PyYAML is required for Config.save(); install with `pip install pyyaml`."
            ) from exc
        with open(yaml_path, "w", encoding="utf-8") as fh:
            yaml.safe_dump(self.to_dict(), fh, sort_keys=False)


__all__ = ["Config", "DataCfg", "ModelCfg", "TrainCfg", "LossCfg"]
