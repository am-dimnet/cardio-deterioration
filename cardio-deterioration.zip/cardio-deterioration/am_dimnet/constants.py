"""Global constants for AM-DiMNet (SPEC Section 0).

These constants define the ordered candidate modality set, the structured
latent factors, the explicit feature vocabularies, and the fixed evaluation
thresholds. They are the single source of truth referenced by every other
module; do not redefine them elsewhere.

Paper cross-references are given inline (e.g. Eq. 5 = HRV feature vector,
Eq. 7 = activity-proxy components, Eq. 10 = signal-quality index).
"""

from __future__ import annotations

from typing import List, Tuple

# --- Modalities ------------------------------------------------------------
# Ordered candidate modality set M (fixed; the availability mask, not a
# sample-dependent index set, controls which modalities contribute -- Eq. 14).
MODALITIES: List[str] = ["ecg", "ppg", "pcg", "proxy", "hrv", "clinical"]

# 1-D waveforms always present in the primary cohort.
WAVEFORM_MODS: List[str] = ["ecg", "ppg"]

# PCG is an optional, design-compatible branch (evaluated only in
# component-level experiments; contributes v=0 when absent).
OPTIONAL_MODS: List[str] = ["pcg"]

# --- Structured latent factors P (Eq. 16) ---------------------------------
FACTORS: List[str] = ["auto", "morph", "act", "base", "noise"]

# Only these factors enter the risk head (Eq. 17). Activity/noise are used for
# deconfounding, uncertainty, and robustness -- never as direct risk evidence.
RISK_FACTORS: List[str] = ["auto", "morph", "base"]

# --- Explicit feature vocabularies ----------------------------------------
# 10-dim HRV feature vector (Eq. 5), anchoring target for z_auto (Eq. 18-19).
HRV_FEATURES: List[str] = [
    "MeanNN", "SDNN", "RMSSD", "pNN50", "LF", "HF", "LFHF", "SD1", "SD2", "SampEn",
]

# 4-dim activity/motion-proxy components (Eq. 7).
PROXY_COMPONENTS: List[str] = [
    "bed_motion", "ecg_env_instab", "ppg_env_instab", "ppg_reject_ratio",
]

# Number of activity-motion-proxy tertile classes (low/moderate/high).
N_ACTIVITY_CLASSES: int = 3

# --- Evaluation constants --------------------------------------------------
ECE_BINS: int = 15  # Expected Calibration Error bin count (Eq. 35).

# Training-set proxy-score tertile thresholds (Table 9): low<0.34, high>0.61.
PROXY_TERTILES: Tuple[float, float] = (0.34, 0.61)

# Very-low-quality subgroup = below the 10th percentile of q_min
# (tau_VLQ approx 0.41 on the training set).
VLQ_PERCENTILE: int = 10

# --- Column helpers (SPEC Section 2 — sqi/mask ordering == MODALITIES) ------
def sqi_index(mod: str) -> int:
    """Return the column index of ``mod`` in the ``sqi`` vector (Eq. 10).

    The per-modality signal-quality vector ``sqi`` and availability ``mask`` are
    ordered exactly as :data:`MODALITIES` (SPEC Section 2), so this is simply the
    position of ``mod`` in that ordered candidate set.
    """
    return MODALITIES.index(mod)


def mask_index(mod: str) -> int:
    """Return the column index of ``mod`` in the ``mask`` vector (Eq. 11).

    Same ordering as :func:`sqi_index` (SPEC Section 2, order == MODALITIES).
    """
    return MODALITIES.index(mod)


__all__ = [
    "MODALITIES",
    "WAVEFORM_MODS",
    "OPTIONAL_MODS",
    "FACTORS",
    "RISK_FACTORS",
    "HRV_FEATURES",
    "PROXY_COMPONENTS",
    "N_ACTIVITY_CLASSES",
    "ECE_BINS",
    "PROXY_TERTILES",
    "VLQ_PERCENTILE",
    "sqi_index",
    "mask_index",
]
