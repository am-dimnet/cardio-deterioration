"""AM-DiMNet data subpackage.

Bundles the data-core building blocks of the reference implementation:

* :mod:`~am_dimnet.data.features`  -- HRV / activity-proxy / SQI features
  (paper Eq. 5-10).
* :mod:`~am_dimnet.data.splits`    -- patient-disjoint splitting + split summary
  tables (Tables 10-11).
* :mod:`~am_dimnet.data.synthetic` -- self-contained :class:`SyntheticCohort` and
  patient-disjoint :func:`make_loaders` that power ``am_dimnet.smoke_test``.

The MIMIC-IV extraction / preprocessing / endpoint modules (``cohort``,
``preprocessing``, ``endpoints``) are separate and not exercised by the smoke
test; they are imported lazily by their consumers to avoid a hard dependency on
DB drivers here.
"""

from __future__ import annotations

from .features import (
    activity_proxy_components,
    activity_proxy_score,
    activity_tertile,
    envelope_instability,
    hrv_features,
    sma,
    sqi,
)
from .splits import patient_split, split_summary
from .synthetic import SyntheticCohort, collate_batch, make_loaders

__all__ = [
    # features (Eq. 5-10)
    "hrv_features",
    "sma",
    "activity_proxy_components",
    "envelope_instability",
    "activity_proxy_score",
    "sqi",
    "activity_tertile",
    # splits (Tables 10-11)
    "patient_split",
    "split_summary",
    # synthetic cohort
    "SyntheticCohort",
    "make_loaders",
    "collate_batch",
]
