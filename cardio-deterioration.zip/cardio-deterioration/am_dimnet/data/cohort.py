"""MIMIC-IV waveform-linked cohort extraction for AM-DiMNet.

Implements ``extract_cohort(db, config)`` which runs the parameterised
``sql/cohort_extraction.sql`` against a *credentialed* MIMIC-IV instance and
applies the Table 12 exclusion sequence, returning the surviving candidate ICU
stays plus a cohort-flow log (one row per exclusion step, matching the
consort-style flow diagram in Table 12).

This module is NOT exercised by the smoke test (it needs the real database).
It embeds **no** patient data and hard-codes no credentials.

Data access / credentialing
----------------------------
MIMIC-IV and MIMIC-IV-ECG / the MIMIC waveform matched subset are distributed
by PhysioNet under a credentialed-access DUA. To reproduce this cohort you must:

  1. Complete CITI "Data or Specimens Only Research" training.
  2. Sign the PhysioNet Credentialed Health Data Use Agreement.
  3. Obtain access to:
       - MIMIC-IV v2.2+            (hosp / icu modules)
       - MIMIC-IV-ECG             (12-lead diagnostic + waveform links)
       - MIMIC-IV Waveform / matched subset (ECG/PPG/PCG numerics + waveforms)
  4. Load the data into a PostgreSQL (or BigQuery) instance and pass a live
     connection object (psycopg2 / SQLAlchemy / BigQuery client) to
     ``extract_cohort``. **Never** commit extracted rows to this repository.

See ``docs/data_access.md`` for the full procedure. The ``db`` argument is a
caller-provided connection; this code only *reads* from it.

Paper references
----------------
* Table 12 — cohort-flow exclusion sequence (the CTE/step order below is 1:1).
* Eq. 1    — sliding-window observation protocol (informs min-duration step).
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

try:
    import pandas as pd
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "am_dimnet.data.cohort requires pandas to build the cohort DataFrame."
    ) from exc


__all__ = [
    "CohortFlowLog",
    "extract_cohort",
    "load_cohort_sql",
    "EXCLUSION_STEPS",
]


# ---------------------------------------------------------------------------
# Table 12 — ordered exclusion sequence.
#
# Each entry: (step_key, human-readable reason). The order MUST match the
# consort flow in Table 12; ``extract_cohort`` applies them in this order and
# logs the count removed at each step.
# ---------------------------------------------------------------------------
EXCLUSION_STEPS: List[tuple] = [
    ("waveform_availability", "No linked waveform record (matched-subset miss)"),
    ("ecg_ppg_availability", "Missing simultaneous ECG and PPG channels"),
    ("min_duration", "Recording shorter than minimum monitored duration"),
    ("rr_quality", "Insufficient RR-interval quality for HRV features"),
    ("temporal_alignment", "ECG/PPG not temporally aligned within tolerance"),
    ("pre_existing_endpoint", "Endpoint already present before/at window start"),
    ("gap_window_endpoint", "Endpoint occurs inside the prediction gap window"),
]


# ---------------------------------------------------------------------------
# Cohort-flow log
# ---------------------------------------------------------------------------
@dataclass
class CohortFlowLog:
    """Consort-style cohort flow accounting (Table 12).

    Records the running population size and the number of stays removed at each
    exclusion step, so the final DataFrame can be reconciled against the paper's
    flow diagram.
    """

    initial: int = 0
    steps: List[Dict[str, Any]] = field(default_factory=list)

    def start(self, n: int, description: str = "Candidate ICU stays") -> None:
        self.initial = int(n)
        self.steps.append(
            {
                "step": "initial",
                "reason": description,
                "removed": 0,
                "remaining": int(n),
            }
        )

    def record(self, step: str, reason: str, before: int, after: int) -> None:
        self.steps.append(
            {
                "step": step,
                "reason": reason,
                "removed": int(before - after),
                "remaining": int(after),
            }
        )

    def to_frame(self) -> "pd.DataFrame":
        """Return the flow log as a DataFrame (one row per step)."""
        return pd.DataFrame(self.steps, columns=["step", "reason", "removed", "remaining"])

    @property
    def final(self) -> int:
        return self.steps[-1]["remaining"] if self.steps else 0


# ---------------------------------------------------------------------------
# SQL loading
# ---------------------------------------------------------------------------
def _sql_dir() -> str:
    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.dirname(os.path.dirname(here))
    return os.path.join(repo, "sql")


def load_cohort_sql(path: Optional[str] = None) -> str:
    """Read the parameterised cohort-extraction SQL template.

    Parameters
    ----------
    path : str | None
        Override; defaults to ``<repo>/sql/cohort_extraction.sql``.

    Returns
    -------
    str
        SQL text. Parameters (schema names, min-duration seconds, RR-quality
        threshold, alignment tolerance, gap/horizon hours) are bound by the
        caller's DB driver — no data is embedded.
    """
    if path is None:
        path = os.path.join(_sql_dir(), "cohort_extraction.sql")
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


# ---------------------------------------------------------------------------
# Query execution helper (driver-agnostic)
# ---------------------------------------------------------------------------
def _read_sql(db: Any, sql: str, params: Optional[Dict[str, Any]]) -> "pd.DataFrame":
    """Execute ``sql`` against ``db`` and return a DataFrame.

    Supports the common connection flavours without importing any driver:
    * objects with a ``.cursor()`` (psycopg2 / DB-API) -> use pandas.read_sql,
    * SQLAlchemy engines/connections -> pandas.read_sql,
    * a plain callable ``db(sql, params) -> DataFrame`` for tests/mocks.
    """
    if callable(db) and not hasattr(db, "cursor") and not hasattr(db, "connect"):
        # Test / mock hook: db is a function returning a DataFrame.
        return db(sql, params)
    # pandas.read_sql handles DB-API connections and SQLAlchemy engines.
    return pd.read_sql(sql, db, params=params)


# ---------------------------------------------------------------------------
# extract_cohort
# ---------------------------------------------------------------------------
def extract_cohort(
    db: Any,
    config: Any,
    *,
    sql_path: Optional[str] = None,
    params: Optional[Dict[str, Any]] = None,
    return_flow: bool = True,
):
    """Extract the AM-DiMNet candidate cohort and apply Table 12 exclusions.

    The SQL in ``sql/cohort_extraction.sql`` already expresses each exclusion as
    a CTE and returns, per candidate ICU stay, boolean/quantitative flags for
    every Table 12 criterion (so the Python side is a transparent, auditable
    filter+log rather than hidden query logic). This function:

      1. loads + runs the SQL (parameters from ``config`` + ``params``),
      2. applies the seven Table 12 exclusions IN ORDER,
      3. logs the count removed at each step into a ``CohortFlowLog``,
      4. returns the surviving stays as a DataFrame.

    Expected columns from the SQL (one row per candidate stay):
        subject_id, hadm_id, stay_id, intime, outtime,
        has_waveform            (bool)   -- waveform_availability
        has_ecg, has_ppg        (bool)   -- ecg_ppg_availability
        monitored_seconds       (float)  -- min_duration
        rr_quality              (float)  -- rr_quality (fraction of usable RR)
        align_offset_s          (float)  -- temporal_alignment (|ECG-PPG| skew)
        endpoint_before_start   (bool)   -- pre_existing_endpoint
        endpoint_in_gap         (bool)   -- gap_window_endpoint

    Parameters
    ----------
    db : Any
        Live, credentialed DB connection / engine (psycopg2 / SQLAlchemy /
        BigQuery client), or a ``callable(sql, params)->DataFrame`` for tests.
    config : Config
        Provides thresholds via ``config.data`` (window_min, step_s, gap_h,
        horizon_h) plus optional extraction thresholds (see below).
    sql_path : str | None
        Override for the SQL template location.
    params : dict | None
        Extra bind parameters merged over the config-derived defaults.
    return_flow : bool
        If True (default) return ``(cohort_df, flow_log)``; else just the df.

    Returns
    -------
    pandas.DataFrame or (pandas.DataFrame, CohortFlowLog)
    """
    sql = load_cohort_sql(sql_path)
    bind = _default_params(config)
    if params:
        bind.update(params)

    raw = _read_sql(db, sql, bind)
    flow = CohortFlowLog()
    flow.start(len(raw), "Candidate ICU stays with an ICU stay >= 0 h")

    # thresholds (fall back to sensible defaults if not on config).
    min_seconds = float(bind.get("min_seconds", 0.0))
    rr_thresh = float(bind.get("rr_quality_min", 0.0))
    align_tol = float(bind.get("align_tol_s", float("inf")))

    df = raw.copy()

    # --- 1. Waveform availability -----------------------------------------
    before = len(df)
    df = df[_col_bool(df, "has_waveform", default=True)]
    flow.record("waveform_availability", EXCLUSION_STEPS[0][1], before, len(df))

    # --- 2. ECG + PPG availability ----------------------------------------
    before = len(df)
    df = df[_col_bool(df, "has_ecg", default=True) & _col_bool(df, "has_ppg", default=True)]
    flow.record("ecg_ppg_availability", EXCLUSION_STEPS[1][1], before, len(df))

    # --- 3. Minimum monitored duration ------------------------------------
    before = len(df)
    if "monitored_seconds" in df.columns:
        df = df[df["monitored_seconds"].astype(float) >= min_seconds]
    flow.record("min_duration", EXCLUSION_STEPS[2][1], before, len(df))

    # --- 4. RR-interval quality -------------------------------------------
    before = len(df)
    if "rr_quality" in df.columns:
        df = df[df["rr_quality"].astype(float) >= rr_thresh]
    flow.record("rr_quality", EXCLUSION_STEPS[3][1], before, len(df))

    # --- 5. Temporal alignment (ECG/PPG skew within tolerance) ------------
    before = len(df)
    if "align_offset_s" in df.columns:
        df = df[df["align_offset_s"].abs().astype(float) <= align_tol]
    flow.record("temporal_alignment", EXCLUSION_STEPS[4][1], before, len(df))

    # --- 6. Pre-existing endpoint (already deteriorated at/near window start)
    before = len(df)
    df = df[~_col_bool(df, "endpoint_before_start", default=False)]
    flow.record("pre_existing_endpoint", EXCLUSION_STEPS[5][1], before, len(df))

    # --- 7. Endpoint inside the prediction-gap window ---------------------
    before = len(df)
    df = df[~_col_bool(df, "endpoint_in_gap", default=False)]
    flow.record("gap_window_endpoint", EXCLUSION_STEPS[6][1], before, len(df))

    cohort = df.reset_index(drop=True)
    if return_flow:
        return cohort, flow
    return cohort


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _default_params(config: Any) -> Dict[str, Any]:
    """Build SQL bind parameters + Python-side thresholds from ``config``.

    The minimum monitored duration is derived from the observation protocol:
    at least one full observation window plus the prediction gap+horizon so a
    positive/negative label can be assigned (Eq. 1–3).
    """
    data = getattr(config, "data", None)
    window_min = float(getattr(data, "window_min", 5.0)) if data else 5.0
    step_s = float(getattr(data, "step_s", 60.0)) if data else 60.0
    gap_h = float(getattr(data, "gap_h", 1.5)) if data else 1.5
    horizon_h = float(getattr(data, "horizon_h", 24.0)) if data else 24.0

    # Need >= one window (window_min) so a single labelled sample can exist; the
    # gap/horizon are needed for the label lookahead.
    min_seconds = window_min * 60.0

    return {
        "window_min": window_min,
        "step_s": step_s,
        "gap_h": gap_h,
        "horizon_h": horizon_h,
        # Python-side exclusion thresholds (also passed to SQL for the CTEs).
        "min_seconds": min_seconds,
        "rr_quality_min": float(getattr(data, "rr_quality_min", 0.7)) if data else 0.7,
        "align_tol_s": float(getattr(data, "align_tol_s", 2.0)) if data else 2.0,
    }


def _col_bool(df: "pd.DataFrame", col: str, default: bool) -> "pd.Series":
    """Return ``df[col]`` coerced to bool, or an all-``default`` series if the
    column is absent (keeps the filter robust to SQL variants that omit a flag)."""
    if col in df.columns:
        return df[col].fillna(default).astype(bool)
    return pd.Series([default] * len(df), index=df.index, dtype=bool)
