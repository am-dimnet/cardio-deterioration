"""Endpoint definition and window labeling for AM-DiMNet.

Encodes the composite deterioration endpoint (Table 1) as a machine-readable
``ENDPOINT_COMPONENTS`` mapping and provides the window-labeling logic
(Eq. 2–3): a window is positive iff at least one endpoint-component event
occurs inside the prediction interval ``[window_end + gap, window_end + gap +
horizon]``.

The composite endpoint has six components (Table 1). Each component lists the
MIMIC-IV source table(s) and the exact ``itemid`` set (SPEC Section 5), which
is also emitted into ``sql/endpoint_labeling.sql`` for the SQL pipeline. This
module never embeds patient data; it operates on event records already
extracted from a credentialed MIMIC-IV instance.

Paper references
----------------
* Table 1 — composite endpoint components + item ids.
* Eq. 2   — component event indicator inside the prediction interval.
* Eq. 3   — window label = OR over components (>=1 component fires).
* SPEC Section 5 — exact itemids/tables per component.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# hours -> the label interval is expressed in absolute clock time; callers pass
# ``window_end`` and event times as comparable numeric hours (or datetimes).

__all__ = [
    "ENDPOINT_COMPONENTS",
    "ENDPOINT_ORDER",
    "EndpointEvent",
    "label_window",
    "first_qualifying_endpoint",
    "endpoint_components_in_interval",
    "load_endpoint_sql",
    "all_itemids",
]


# ---------------------------------------------------------------------------
# Table 1 — composite deterioration endpoint (EXACT encoding).
#
# ``tables``  : MIMIC-IV source tables the component is extracted from.
# ``itemids`` : d_items itemids that mark the component (chartevents /
#               procedureevents / inputevents).  Empty for components keyed by
#               timestamp fields rather than itemids (death).
# ``fields``  : timestamp columns used when the component is not itemid-based.
# ``note``    : human-readable description tying each id back to Table 1.
#
# Item ids are taken verbatim from SPEC Section 5:
#   norepinephrine 221906, epinephrine 221289, dopamine 221662,
#   dobutamine 221653, vasopressin 222315, IV furosemide 221794;
#   arrest/CPR 225466 / 225468 / 224385;
#   malignant arrhythmia 224168 / 225448 / 225468;
#   urgent CV intervention 225752 / 225459 / 225802;
#   acute HF 221794 / 225152 / 228340.
# ---------------------------------------------------------------------------
ENDPOINT_COMPONENTS: Dict[str, Dict[str, Any]] = {
    # -- 1. Cardiac arrest / CPR ----------------------------------------------
    "cardiac_arrest_cpr": {
        "tables": ["procedureevents", "chartevents"],
        "itemids": [225466, 225468, 224385],
        "fields": [],
        "note": (
            "Cardiac arrest / cardiopulmonary resuscitation. "
            "225466=Non-invasive/Manual CPR (procedureevents), "
            "225468=Unplanned CPR/defibrillation event, "
            "224385=Intubation/arrest-associated airway event (chartevents)."
        ),
    },
    # -- 2. In-ICU death ------------------------------------------------------
    "death": {
        "tables": ["admissions", "icustays", "patients"],
        "itemids": [],
        "fields": ["deathtime", "dod"],
        "note": (
            "All-cause death. admissions.deathtime (in-hospital) and "
            "patients.dod (date of death) give the event time; scoped to the "
            "ICU stay via icustays.intime/outtime."
        ),
    },
    # -- 3. Vasoactive / inotrope escalation ----------------------------------
    "vasoactive_escalation": {
        "tables": ["inputevents"],
        "itemids": [221906, 221289, 221662, 221653, 222315],
        "fields": [],
        "note": (
            "New/escalated vasoactive support (inputevents). "
            "221906=norepinephrine, 221289=epinephrine, 221662=dopamine, "
            "221653=dobutamine, 222315=vasopressin."
        ),
    },
    # -- 4. Acute heart failure treatment -------------------------------------
    "acute_hf": {
        "tables": ["inputevents", "prescriptions"],
        "itemids": [221794, 225152, 228340],
        "fields": [],
        "note": (
            "Acute heart-failure decompensation treatment. "
            "221794=IV furosemide (inputevents), 225152=inotrope/afterload "
            "agent, 228340=acute HF pharmacologic support; corroborated by "
            "IV diuretic orders in prescriptions."
        ),
    },
    # -- 5. Malignant arrhythmia ----------------------------------------------
    "malignant_arrhythmia": {
        "tables": ["chartevents", "procedureevents"],
        "itemids": [224168, 225448, 225468],
        "fields": [],
        "note": (
            "Malignant/haemodynamically-significant arrhythmia. "
            "224168=arrhythmia charted event (chartevents), "
            "225448=cardioversion (procedureevents), "
            "225468=defibrillation/CPR event."
        ),
    },
    # -- 6. Urgent cardiovascular intervention --------------------------------
    "urgent_cv_intervention": {
        "tables": ["procedureevents"],
        "itemids": [225752, 225459, 225802],
        "fields": [],
        "note": (
            "Urgent cardiovascular procedure (procedureevents). "
            "225752=arterial line / urgent invasive access, "
            "225459=chest tube / pericardial drainage, "
            "225802=dialysis / mechanical circulatory support initiation."
        ),
    },
}

# Deterministic component ordering (used by first_qualifying_endpoint tie-break
# and split summaries).
ENDPOINT_ORDER: List[str] = list(ENDPOINT_COMPONENTS.keys())


# ---------------------------------------------------------------------------
# Event record
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class EndpointEvent:
    """A single endpoint-component event for one ICU stay.

    Attributes
    ----------
    component : str
        Key into ``ENDPOINT_COMPONENTS`` (e.g. ``"cardiac_arrest_cpr"``).
    time_h : float
        Event time in hours on the SAME reference clock as ``window_end`` passed
        to ``label_window`` (typically hours since ICU admission).
    itemid : int | None
        Source itemid (None for timestamp-keyed components such as death).
    stay_id : int | None
        Owning ICU stay id (for bookkeeping; not required by the labeler).
    """

    component: str
    time_h: float
    itemid: Optional[int] = None
    stay_id: Optional[int] = None


# ---------------------------------------------------------------------------
# Window labeling (Eq. 2–3)
# ---------------------------------------------------------------------------
def _prediction_interval(
    window_end: float, gap_h: float, horizon_h: float
) -> Tuple[float, float]:
    """Return the closed prediction interval [end+gap, end+gap+horizon]."""
    lo = window_end + gap_h
    hi = window_end + gap_h + horizon_h
    return lo, hi


def endpoint_components_in_interval(
    window_end: float,
    gap_h: float,
    horizon_h: float,
    events: Iterable[EndpointEvent],
) -> List[str]:
    """Return the sorted set of components firing in the prediction interval.

    Implements the per-component indicator of Eq. 2: a component fires if any of
    its events falls in ``[window_end+gap, window_end+gap+horizon]`` (inclusive).

    Parameters
    ----------
    window_end : float
        End of the observation window (hours on the reference clock).
    gap_h : float
        Prediction gap Delta_g (config ``data.gap_h``, default 1.5 h).
    horizon_h : float
        Prediction horizon Delta_p (config ``data.horizon_h``, default 24 h).
    events : iterable[EndpointEvent]
        All endpoint events for this ICU stay.

    Returns
    -------
    list[str]
        Components (in ``ENDPOINT_ORDER``) with >=1 qualifying event.
    """
    lo, hi = _prediction_interval(window_end, gap_h, horizon_h)
    fired = set()
    for ev in events:
        if ev.component not in ENDPOINT_COMPONENTS:
            raise KeyError(
                f"unknown endpoint component '{ev.component}'; "
                f"expected one of {ENDPOINT_ORDER}"
            )
        if lo <= ev.time_h <= hi:
            fired.add(ev.component)
    return [c for c in ENDPOINT_ORDER if c in fired]


def label_window(
    stay: Any,
    window_end: float,
    gap_h: float,
    horizon_h: float,
    events: Iterable[EndpointEvent],
) -> int:
    """Binary window label (Eq. 2–3).

    Returns 1 iff at least one endpoint component (Table 1) occurs within the
    prediction interval ``[window_end + gap_h, window_end + gap_h + horizon_h]``,
    else 0.

    Parameters
    ----------
    stay : Any
        The ICU stay identifier / record. Accepted for API symmetry (and to
        allow subclasses to filter ``events`` to this stay); the events passed
        in are assumed to already belong to ``stay``.
    window_end : float
        End of the observation window (hours on the reference clock).
    gap_h, horizon_h : float
        Prediction gap / horizon (config ``data.gap_h`` / ``data.horizon_h``).
    events : iterable[EndpointEvent]
        Endpoint events for this stay.

    Returns
    -------
    int
        1 (positive) or 0 (negative).
    """
    events = list(events)
    if stay is not None:
        # If events carry stay_id, keep only those matching this stay.
        stay_id = _stay_id(stay)
        if stay_id is not None:
            events = [e for e in events if e.stay_id in (None, stay_id)]
    fired = endpoint_components_in_interval(window_end, gap_h, horizon_h, events)
    return 1 if fired else 0


def first_qualifying_endpoint(
    window_end: float,
    gap_h: float,
    horizon_h: float,
    events: Iterable[EndpointEvent],
) -> Optional[Tuple[str, float]]:
    """Earliest endpoint component inside the prediction interval.

    Used for the per-split "first qualifying endpoint" counts in the cohort/
    split summaries (Tables 10–11). Returns the (component, time_h) of the
    earliest qualifying event, or ``None`` if the window is negative. Ties in
    time are broken by ``ENDPOINT_ORDER``.

    Parameters
    ----------
    window_end, gap_h, horizon_h : float
        As in ``label_window``.
    events : iterable[EndpointEvent]
        Endpoint events for the stay.

    Returns
    -------
    tuple[str, float] | None
        (component_name, event_time_h) or None.
    """
    lo, hi = _prediction_interval(window_end, gap_h, horizon_h)
    qualifying = [ev for ev in events if lo <= ev.time_h <= hi]
    if not qualifying:
        return None
    qualifying.sort(key=lambda e: (e.time_h, ENDPOINT_ORDER.index(e.component)))
    first = qualifying[0]
    return first.component, first.time_h


# ---------------------------------------------------------------------------
# SQL loading + itemid helpers
# ---------------------------------------------------------------------------
def _sql_dir() -> str:
    """Absolute path to the repo-level ``sql/`` directory."""
    # this file: <repo>/am_dimnet/data/endpoints.py -> <repo>/sql
    here = os.path.dirname(os.path.abspath(__file__))
    repo = os.path.dirname(os.path.dirname(here))
    return os.path.join(repo, "sql")


def load_endpoint_sql(path: Optional[str] = None) -> str:
    """Read the parameterised endpoint-labeling SQL.

    Parameters
    ----------
    path : str | None
        Override path; defaults to ``<repo>/sql/endpoint_labeling.sql``.

    Returns
    -------
    str
        The SQL template. Callers bind parameters (schema, stay ids, gap/horizon)
        via their DB driver; the SQL itself embeds no patient data.
    """
    if path is None:
        path = os.path.join(_sql_dir(), "endpoint_labeling.sql")
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def all_itemids() -> Dict[str, List[int]]:
    """Return {component: [itemids]} for the itemid-based components (Table 1)."""
    return {
        comp: list(spec["itemids"])
        for comp, spec in ENDPOINT_COMPONENTS.items()
        if spec["itemids"]
    }


def _stay_id(stay: Any) -> Optional[int]:
    """Best-effort extraction of an integer stay id from ``stay``."""
    if stay is None:
        return None
    if isinstance(stay, (int,)):
        return stay
    for attr in ("stay_id", "icustay_id", "id"):
        if hasattr(stay, attr):
            try:
                return int(getattr(stay, attr))
            except (TypeError, ValueError):
                return None
    if isinstance(stay, dict):
        for key in ("stay_id", "icustay_id", "id"):
            if key in stay:
                try:
                    return int(stay[key])
                except (TypeError, ValueError):
                    return None
    return None
