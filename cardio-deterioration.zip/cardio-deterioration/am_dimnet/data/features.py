"""Feature extraction for AM-DiMNet (paper Eq. 5-10).

Standard, documented biomedical-signal features implemented with NumPy/SciPy only.
These routines power the HRV anchoring target (Eq. 5), the activity-motion proxy
(Eq. 6-9), and the per-modality Signal-Quality Index used by the quality-aware
gated fusion (Eq. 10). Nothing here depends on torch so it can be reused by the
MIMIC extraction pipeline and by the synthetic cohort generator alike.

Equation references follow the AM-DiMNet manuscript:
    Eq. 5  hrv_features                -> 10-D HRV descriptor (MeanNN..SampEn)
    Eq. 6  sma                         -> signal-magnitude area from tri-axial ACC
    Eq. 7  activity_proxy_components    -> 4-D motion proxy component vector
    Eq. 8  envelope_instability        -> MAD(env)/median(env)
    Eq. 9  activity_proxy_score         -> mean of min-max-normalised components
    Eq. 10 sqi                          -> clip(sum eta_j s_j, 0, 1)
    activity_tertile                    -> low/moderate/high proxy tertile class
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy.signal import welch

# numpy 2.0 renamed ``trapz`` -> ``trapezoid``; alias so band-power integration
# works on both numpy 1.x and 2.x without deprecation warnings.
_trapz = getattr(np, "trapezoid", None) or np.trapz

try:  # scipy>=1.7 exposes lombscargle in scipy.signal
    from scipy.signal import lombscargle as _lombscargle
except Exception:  # pragma: no cover - defensive; welch fallback still works
    _lombscargle = None

# Import the canonical constants so ordering/length always matches the contract.
from ..constants import HRV_FEATURES, PROXY_COMPONENTS, PROXY_TERTILES

__all__ = [
    "hrv_features",
    "sma",
    "activity_proxy_components",
    "envelope_instability",
    "activity_proxy_score",
    "sqi",
    "activity_tertile",
]

# Frequency-domain HRV bands (Task Force of ESC/NASPE, 1996), used in Eq. 5.
_LF_BAND = (0.04, 0.15)  # Hz
_HF_BAND = (0.15, 0.40)  # Hz
_EPS = 1e-8


# ---------------------------------------------------------------------------
# Eq. 5 -- Heart-rate-variability descriptor
# ---------------------------------------------------------------------------
def _sample_entropy(x: np.ndarray, m: int = 2, r: float | None = None) -> float:
    """Sample entropy (Richman & Moorman, 2000), used for the SampEn HRV feature.

    SampEn = -log(A/B) where B counts template matches of length ``m`` and A of
    length ``m+1`` within tolerance ``r`` (default 0.2 * std). Self-matches are
    excluded. Returns 0.0 for degenerate inputs so the 10-D vector stays finite.
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    n = x.size
    if n < m + 2:
        return 0.0
    if r is None:
        sd = float(np.std(x))
        r = 0.2 * sd
    if r <= 0.0:
        return 0.0

    def _phi(mm: int) -> int:
        # Number of matching template pairs of length ``mm`` (Chebyshev metric).
        templates = np.array([x[i : i + mm] for i in range(n - mm + 1)])
        count = 0
        for i in range(templates.shape[0] - 1):
            dist = np.max(np.abs(templates[i + 1 :] - templates[i]), axis=1)
            count += int(np.sum(dist <= r))
        return count

    b = _phi(m)
    a = _phi(m + 1)
    if b == 0 or a == 0:
        return 0.0
    return float(-np.log(a / b))


def _lf_hf_power(rr_ms: np.ndarray) -> tuple[float, float]:
    """LF/HF absolute powers (ms^2) from irregularly sampled RR via Lomb-Scargle.

    RR intervals are inherently unevenly sampled in time, so Eq. 5 uses a
    Lomb-Scargle periodogram of the detrended RR tachogram over the LF (0.04-0.15
    Hz) and HF (0.15-0.40 Hz) bands. Falls back to Welch on an interpolated,
    evenly resampled series if Lomb-Scargle is unavailable.
    """
    rr_s = rr_ms / 1000.0
    t = np.cumsum(rr_s)  # occurrence times of each beat (s)
    t = t - t[0]
    series = rr_ms - np.mean(rr_ms)
    duration = float(t[-1]) if t[-1] > 0 else 1.0

    freqs = np.linspace(_LF_BAND[0], _HF_BAND[1], 256)
    if _lombscargle is not None and t.size >= 4 and duration > 0:
        ang = 2.0 * np.pi * freqs
        # normalize=False -> power has units of (signal^2); scale to a PSD-like
        # density by the record duration for band-power integration.
        pxx = _lombscargle(t, series, ang, normalize=False) / duration
    else:  # pragma: no cover - fallback path
        fs = 4.0
        t_even = np.arange(0.0, duration, 1.0 / fs)
        if t_even.size < 4:
            return 0.0, 0.0
        interp = np.interp(t_even, t, series)
        f, pxx_full = welch(interp, fs=fs, nperseg=min(256, interp.size))
        freqs, pxx = f, pxx_full

    lf_mask = (freqs >= _LF_BAND[0]) & (freqs < _LF_BAND[1])
    hf_mask = (freqs >= _HF_BAND[0]) & (freqs < _HF_BAND[1])
    lf = float(_trapz(pxx[lf_mask], freqs[lf_mask])) if lf_mask.any() else 0.0
    hf = float(_trapz(pxx[hf_mask], freqs[hf_mask])) if hf_mask.any() else 0.0
    return max(lf, 0.0), max(hf, 0.0)


def hrv_features(rr_intervals: Sequence[float]) -> np.ndarray:
    """Compute the 10-D HRV descriptor of Eq. 5.

    Parameters
    ----------
    rr_intervals : sequence of float
        Successive RR (inter-beat) intervals in **milliseconds**.

    Returns
    -------
    np.ndarray, shape (10,)
        Ordered as :data:`HRV_FEATURES` =
        [MeanNN, SDNN, RMSSD, pNN50, LF, HF, LFHF, SD1, SD2, SampEn]:

        * MeanNN  -- mean NN interval (ms)
        * SDNN    -- standard deviation of NN intervals (ms)
        * RMSSD   -- root mean square of successive differences (ms)
        * pNN50   -- proportion of |NN diffs| > 50 ms (fraction in [0,1])
        * LF, HF  -- Lomb-Scargle band powers (ms^2)
        * LFHF    -- LF/HF ratio
        * SD1     -- Poincare short-term variability = RMSSD / sqrt(2)
        * SD2     -- Poincare long-term variability
        * SampEn  -- sample entropy (m=2, r=0.2*SD)

    Degenerate inputs (<3 intervals) yield a finite zero-padded vector so the
    downstream reconstruction target (Eq. 18-19) is always well defined.
    """
    rr = np.asarray(rr_intervals, dtype=np.float64).ravel()
    out = np.zeros(len(HRV_FEATURES), dtype=np.float64)
    if rr.size == 0:
        return out.astype(np.float32)

    mean_nn = float(np.mean(rr))
    sdnn = float(np.std(rr, ddof=1)) if rr.size > 1 else 0.0

    diff = np.diff(rr)
    rmssd = float(np.sqrt(np.mean(diff ** 2))) if diff.size > 0 else 0.0
    pnn50 = float(np.mean(np.abs(diff) > 50.0)) if diff.size > 0 else 0.0

    lf, hf = _lf_hf_power(rr) if rr.size >= 4 else (0.0, 0.0)
    lfhf = float(lf / (hf + _EPS))

    # Poincare descriptors (Brennan et al., 2001): SD1 from RMSSD, SD2 from SDNN.
    sd1 = float(rmssd / np.sqrt(2.0))
    sd2_sq = 2.0 * (sdnn ** 2) - 0.5 * (rmssd ** 2)
    sd2 = float(np.sqrt(sd2_sq)) if sd2_sq > 0 else 0.0

    sampen = _sample_entropy(rr, m=2)

    out[:] = [mean_nn, sdnn, rmssd, pnn50, lf, hf, lfhf, sd1, sd2, sampen]
    return out.astype(np.float32)


# ---------------------------------------------------------------------------
# Eq. 6 -- Signal-magnitude area (only for datasets with tri-axial ACC)
# ---------------------------------------------------------------------------
def sma(acc_xyz: np.ndarray) -> float:
    """Signal-magnitude area of a tri-axial accelerometer window (Eq. 6).

    SMA = (1/N) * sum_i (|a_x,i| + |a_y,i| + |a_z,i|).

    Parameters
    ----------
    acc_xyz : np.ndarray, shape (N, 3) or (3, N)
        Tri-axial acceleration samples (x, y, z).

    Returns
    -------
    float
        Mean summed absolute acceleration across the window. This is only used
        for cohorts that carry direct tri-axial ACC; the primary ICU cohort uses
        the surrogate activity-motion proxy of Eq. 7-9 instead.
    """
    a = np.asarray(acc_xyz, dtype=np.float64)
    if a.ndim != 2:
        raise ValueError("acc_xyz must be 2-D (N,3) or (3,N)")
    if a.shape[0] == 3 and a.shape[1] != 3:
        a = a.T  # normalise to (N, 3)
    if a.shape[1] != 3:
        raise ValueError("acc_xyz must have a length-3 axis (x,y,z)")
    if a.shape[0] == 0:
        return 0.0
    return float(np.mean(np.sum(np.abs(a), axis=1)))


# ---------------------------------------------------------------------------
# Eq. 8 -- Envelope instability
# ---------------------------------------------------------------------------
def envelope_instability(envelope: Sequence[float]) -> float:
    """Envelope instability = MAD(env) / median(env) (Eq. 8).

    A robust coefficient-of-variation-style score: the median absolute deviation
    of the amplitude envelope normalised by its median. High values flag motion
    contamination / unstable morphology. Returns 0.0 when the median is ~0.

    Parameters
    ----------
    envelope : sequence of float
        Amplitude-envelope samples (e.g. Hilbert envelope of ECG/PPG).
    """
    env = np.asarray(envelope, dtype=np.float64).ravel()
    if env.size == 0:
        return 0.0
    med = float(np.median(env))
    if abs(med) < _EPS:
        return 0.0
    mad = float(np.median(np.abs(env - med)))
    return float(mad / (abs(med) + _EPS))


# ---------------------------------------------------------------------------
# Eq. 7 -- Activity-motion proxy component vector
# ---------------------------------------------------------------------------
def activity_proxy_components(
    bed_motion: float,
    ecg_env: float,
    ppg_env: float,
    ppg_reject: float,
) -> np.ndarray:
    """Assemble the 4-D activity-motion proxy component vector (Eq. 7).

    Ordered as :data:`PROXY_COMPONENTS` =
    [bed_motion, ecg_env_instab, ppg_env_instab, ppg_reject_ratio].

    Parameters
    ----------
    bed_motion : float
        Bed / chest-wall motion index for the window.
    ecg_env : float
        ECG envelope-instability (Eq. 8) for the window.
    ppg_env : float
        PPG envelope-instability (Eq. 8) for the window.
    ppg_reject : float
        Fraction of PPG pulses rejected by beat-detection QC in [0,1].

    Returns
    -------
    np.ndarray, shape (4,)
        Raw (un-normalised) proxy components; feed through min-max normalisation
        before :func:`activity_proxy_score` (Eq. 9).
    """
    comps = np.array(
        [float(bed_motion), float(ecg_env), float(ppg_env), float(ppg_reject)],
        dtype=np.float32,
    )
    assert comps.shape[0] == len(PROXY_COMPONENTS)
    return comps


# ---------------------------------------------------------------------------
# Eq. 9 -- Activity-motion proxy score
# ---------------------------------------------------------------------------
def activity_proxy_score(components_minmax: Sequence[float]) -> float:
    """Activity-motion proxy score = mean of min-max-normalised components (Eq. 9).

    Parameters
    ----------
    components_minmax : sequence of float, length 4
        The 4 proxy components (Eq. 7) **after** per-component min-max scaling to
        [0,1] using training-set ranges. This function just averages them.

    Returns
    -------
    float
        Scalar activity-motion proxy score in [0,1] (assuming inputs in [0,1]).
    """
    c = np.asarray(components_minmax, dtype=np.float64).ravel()
    if c.size == 0:
        return 0.0
    return float(np.clip(np.mean(c), 0.0, 1.0))


# ---------------------------------------------------------------------------
# Eq. 10 -- Signal-Quality Index
# ---------------------------------------------------------------------------
def sqi(descriptors: Sequence[float], weights: Sequence[float]) -> float:
    """Weighted Signal-Quality Index q_r = clip(sum_j eta_j s_j, 0, 1) (Eq. 10).

    Parameters
    ----------
    descriptors : sequence of float
        Per-modality quality sub-scores s_j (e.g. flatline, saturation, SNR,
        template-matching correlation), each ideally in [0,1].
    weights : sequence of float
        Non-negative weights eta_j (typically summing to 1) of matching length.

    Returns
    -------
    float
        Signal-Quality Index in [0,1] used by the quality-aware gated fusion
        (Eq. 14-15) and stored in ``batch["sqi"]``.
    """
    s = np.asarray(descriptors, dtype=np.float64).ravel()
    eta = np.asarray(weights, dtype=np.float64).ravel()
    if s.shape != eta.shape:
        raise ValueError(
            f"descriptors and weights must match: {s.shape} vs {eta.shape}"
        )
    if s.size == 0:
        return 0.0
    return float(np.clip(np.sum(eta * s), 0.0, 1.0))


# ---------------------------------------------------------------------------
# Activity tertile classification (proxy-tertile anchoring / adversarial target)
# ---------------------------------------------------------------------------
def activity_tertile(score: float, tertiles: tuple[float, float] = PROXY_TERTILES) -> int:
    """Map an activity-motion proxy score to a low/moderate/high tertile class.

    Uses the training-set thresholds :data:`PROXY_TERTILES` (Table 9):
    low (0) if score < tertiles[0]; high (2) if score > tertiles[1]; else
    moderate (1). This is the ``activity`` label used for anchoring (Eq. 22) and
    adversarial invariance (Eq. 23).

    Parameters
    ----------
    score : float
        Activity-motion proxy score from :func:`activity_proxy_score` (Eq. 9).
    tertiles : (float, float)
        (low_threshold, high_threshold).

    Returns
    -------
    int
        0 (low), 1 (moderate), or 2 (high).
    """
    lo, hi = tertiles
    s = float(score)
    if s < lo:
        return 0
    if s > hi:
        return 2
    return 1
