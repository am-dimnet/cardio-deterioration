"""Signal preprocessing for AM-DiMNet.

Implements the per-modality Butterworth band-pass filtering (Table 4 bands),
fixed-length windowing (5-min observation window with 60-s sliding step,
SPEC Section 1 ``data`` block), polyphase resampling to the encoder input
length, log-Mel spectrogram computation for the optional PCG branch
(SPEC Section 3, ``pcg_mels=64`` / ``pcg_frames=128``), and assembly of a
single batch-contract sample dict (SPEC Section 2).

None of the functions here require external data; they operate on raw NumPy
signal arrays and produce the exact tensor shapes / dict keys the model and
losses consume. This module is *not* exercised by the smoke test (which uses
``synthetic.py``) but is the reference implementation the MIMIC-IV pipeline
(``cohort.py`` / ``endpoints.py``) feeds into.

Paper references
----------------
* Table 4 — per-modality processing bands + resampled encoder lengths.
* Eq. 5  — HRV features (computed in ``features.py``; consumed here).
* Eq. 7  — activity-motion proxy components.
* Eq. 10 — signal-quality index q_r per modality.
* Eq. 11 — availability masks m_r per modality.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

try:  # scipy is a hard dependency per SPEC Section 0 preamble.
    from scipy.signal import butter, sosfiltfilt, resample_poly, get_window
except Exception as exc:  # pragma: no cover - import guard for clearer errors
    raise ImportError(
        "am_dimnet.data.preprocessing requires scipy (butter/sosfiltfilt/"
        "resample_poly/get_window). Install scipy>=1.9."
    ) from exc

# The batch contract is produced as torch tensors; torch is a hard dependency.
try:
    import torch
except Exception as exc:  # pragma: no cover
    raise ImportError(
        "am_dimnet.data.preprocessing requires PyTorch 2.x to build "
        "batch-contract records."
    ) from exc

# MODALITIES ordering is the single source of truth for the sqi/mask columns.
# We import from constants so preprocessing stays consistent with the rest of
# the package; a local fallback keeps the module import-clean if constants.py
# is being authored in parallel.
try:
    from ..constants import MODALITIES  # type: ignore
except Exception:  # pragma: no cover - fallback mirrors SPEC Section 0.
    MODALITIES = ["ecg", "ppg", "pcg", "proxy", "hrv", "clinical"]


__all__ = [
    "PROCESSING_BANDS",
    "TARGET_FS",
    "bandpass",
    "segment_windows",
    "resample",
    "log_mel_spectrogram",
    "build_window_record",
    "sqi_index",
    "mask_index",
]


# ---------------------------------------------------------------------------
# Table 4 — per-modality band-pass processing bands (Hz) and native sampling.
#
# ECG   : 0.5–40 Hz  (baseline-wander + high-frequency EMG removal)
# PPG   : 0.5–8  Hz  (pulsatile band; drops respiratory drift and HF noise)
# PCG   : 20–400 Hz  (fundamental + murmur band for phonocardiography)
#
# ``lo`` / ``hi`` are the -3 dB corner frequencies of the zero-phase
# Butterworth filter; ``native_fs`` is the nominal MIMIC-IV waveform rate used
# when a caller does not pass an explicit fs.  Callers MUST pass the true fs.
# ---------------------------------------------------------------------------
PROCESSING_BANDS: Dict[str, Dict[str, float]] = {
    "ecg": {"lo": 0.5, "hi": 40.0, "order": 4, "native_fs": 500.0},
    "ppg": {"lo": 0.5, "hi": 8.0, "order": 4, "native_fs": 125.0},
    "pcg": {"lo": 20.0, "hi": 400.0, "order": 4, "native_fs": 1000.0},
}

# Encoder-input lengths per waveform modality (SPEC Section 1 ``data`` block):
# ecg_len = ppg_len = 512 samples after resampling the 5-min window.
TARGET_FS: Dict[str, float] = {
    # Effective sample rate implied by resampling a ``window_min`` window to the
    # encoder length; kept for documentation / round-trip checks.
    "ecg": 512.0 / 300.0,
    "ppg": 512.0 / 300.0,
}


# ---------------------------------------------------------------------------
# Column helpers (SPEC Section 2 — sqi/mask ordering == MODALITIES)
# ---------------------------------------------------------------------------
def sqi_index(mod: str) -> int:
    """Return the column index of ``mod`` in the ``sqi`` vector (Eq. 10).

    Ordering follows ``MODALITIES`` (SPEC Section 0).
    """
    return MODALITIES.index(mod)


def mask_index(mod: str) -> int:
    """Return the column index of ``mod`` in the ``mask`` vector (Eq. 11)."""
    return MODALITIES.index(mod)


# ---------------------------------------------------------------------------
# Band-pass filtering (Table 4)
# ---------------------------------------------------------------------------
def bandpass(
    x: np.ndarray,
    fs: float,
    lo: float,
    hi: float,
    order: int = 4,
) -> np.ndarray:
    """Zero-phase Butterworth band-pass filter (Table 4 bands).

    Parameters
    ----------
    x : np.ndarray
        1-D signal (float).  NaNs are linearly interpolated before filtering.
    fs : float
        Sampling frequency of ``x`` in Hz.
    lo, hi : float
        Lower / upper -3 dB corner frequencies in Hz.  ``hi`` is clipped to
        just below Nyquist (``0.99 * fs/2``) so the filter design is always
        valid.  If ``lo <= 0`` a low-pass is used; if ``hi >= Nyquist`` a
        high-pass is used.
    order : int
        Butterworth order (per section; default 4, giving a 4th-order
        zero-phase response after ``sosfiltfilt``'s forward/backward pass).

    Returns
    -------
    np.ndarray
        Filtered signal, same length and dtype (float64) as the (cleaned)
        input.

    Notes
    -----
    Uses second-order-sections (``sos``) for numerical stability and
    ``sosfiltfilt`` for zero phase distortion, which is required so that HRV
    fiducial timings (Eq. 5) are not shifted.
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    if x.size == 0:
        return x
    x = _interp_nan(x)

    nyq = 0.5 * float(fs)
    if nyq <= 0:
        raise ValueError(f"fs must be positive, got {fs}")

    lo_n = max(lo, 0.0) / nyq
    hi_n = min(hi, 0.99 * nyq) / nyq

    # Guard against too-short segments for filtfilt padding.
    padlen = 3 * order
    if x.size <= padlen:
        return x

    if lo_n <= 0 and hi_n >= 1:
        return x
    if lo_n <= 0:
        sos = butter(order, hi_n, btype="lowpass", output="sos")
    elif hi_n >= 1:
        sos = butter(order, lo_n, btype="highpass", output="sos")
    else:
        if lo_n >= hi_n:
            raise ValueError(
                f"invalid band: lo={lo} hi={hi} at fs={fs} "
                f"(normalised {lo_n:.3f} >= {hi_n:.3f})"
            )
        sos = butter(order, [lo_n, hi_n], btype="bandpass", output="sos")
    return sosfiltfilt(sos, x)


def bandpass_modality(x: np.ndarray, fs: float, modality: str) -> np.ndarray:
    """Convenience wrapper applying the Table 4 band for ``modality``."""
    if modality not in PROCESSING_BANDS:
        raise KeyError(
            f"no processing band defined for modality '{modality}'; "
            f"known: {sorted(PROCESSING_BANDS)}"
        )
    b = PROCESSING_BANDS[modality]
    return bandpass(x, fs, b["lo"], b["hi"], order=int(b["order"]))


def _interp_nan(x: np.ndarray) -> np.ndarray:
    """Linearly interpolate NaNs; edge NaNs are held at the nearest value."""
    x = x.copy()
    nan = np.isnan(x)
    if not nan.any():
        return x
    if nan.all():
        return np.zeros_like(x)
    idx = np.arange(x.size)
    x[nan] = np.interp(idx[nan], idx[~nan], x[~nan])
    return x


# ---------------------------------------------------------------------------
# Windowing (SPEC Section 1: window_min=5.0, step_s=60)
# ---------------------------------------------------------------------------
@dataclass
class Window:
    """One sliding window of a signal.

    Attributes
    ----------
    data : np.ndarray
        The windowed samples.
    start_s, end_s : float
        Window boundaries in seconds relative to the signal start.
    index : int
        Sequential window index within the signal.
    """

    data: np.ndarray
    start_s: float
    end_s: float
    index: int


def segment_windows(
    signal: np.ndarray,
    fs: float,
    window_min: float = 5.0,
    step_s: float = 60.0,
    drop_last: bool = True,
) -> List[Window]:
    """Slide a fixed-length observation window over ``signal`` (Eq. 1 windowing).

    A 5-min window (``window_min``) advances by a 60-s step (``step_s``),
    matching the AM-DiMNet observation protocol (SPEC Section 1 ``data``).

    Parameters
    ----------
    signal : np.ndarray
        1-D signal.
    fs : float
        Sampling frequency (Hz).
    window_min : float
        Window length in minutes (default 5.0).
    step_s : float
        Sliding step in seconds (default 60.0).
    drop_last : bool
        If True, only full-length windows are returned (partial trailing
        window discarded).

    Returns
    -------
    list[Window]
        Windows in temporal order.  Each window's ``start_s``/``end_s`` are the
        absolute offsets used later for temporal alignment and label lookup
        (see ``endpoints.label_window``).
    """
    signal = np.asarray(signal).ravel()
    win_len = int(round(window_min * 60.0 * fs))
    step_len = int(round(step_s * fs))
    if win_len <= 0 or step_len <= 0:
        raise ValueError("window/step must be positive")

    windows: List[Window] = []
    n = signal.size
    idx = 0
    start = 0
    while True:
        end = start + win_len
        if end > n:
            if drop_last or start >= n:
                break
            seg = signal[start:n]
        else:
            seg = signal[start:end]
        windows.append(
            Window(
                data=seg,
                start_s=start / fs,
                end_s=end / fs,
                index=idx,
            )
        )
        idx += 1
        start += step_len
        if start >= n:
            break
    return windows


# ---------------------------------------------------------------------------
# Resampling to encoder input length (Table 4 encoder lengths)
# ---------------------------------------------------------------------------
def resample(x: np.ndarray, src_fs: float, tgt_len: int) -> np.ndarray:
    """Resample ``x`` to exactly ``tgt_len`` samples.

    Uses polyphase resampling (``resample_poly``) to hit the *rate* implied by
    ``tgt_len / len(x)`` then trims/zero-pads to land on ``tgt_len`` exactly, so
    the output always matches the encoder input length (ecg_len/ppg_len = 512).

    Parameters
    ----------
    x : np.ndarray
        1-D signal.
    src_fs : float
        Source sampling frequency (kept for API symmetry / documentation; the
        polyphase ratio is derived purely from lengths so the window duration
        is preserved regardless of ``src_fs``).
    tgt_len : int
        Desired number of output samples.

    Returns
    -------
    np.ndarray
        Length-``tgt_len`` float64 array.
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    x = _interp_nan(x)
    if tgt_len <= 0:
        raise ValueError("tgt_len must be positive")
    n = x.size
    if n == 0:
        return np.zeros(tgt_len, dtype=np.float64)
    if n == tgt_len:
        return x

    # Rational approximation of the resampling factor tgt_len / n.
    from math import gcd

    up = int(tgt_len)
    down = int(n)
    g = gcd(up, down)
    up //= g
    down //= g
    y = resample_poly(x, up, down)

    # resample_poly may be off by a sample; fix length exactly.
    if y.size >= tgt_len:
        y = y[:tgt_len]
    else:
        y = np.pad(y, (0, tgt_len - y.size), mode="edge")
    return y.astype(np.float64)


def zscore(x: np.ndarray, eps: float = 1e-8) -> np.ndarray:
    """Per-signal z-score normalisation (mean 0, unit variance)."""
    x = np.asarray(x, dtype=np.float64)
    mu = float(np.mean(x))
    sd = float(np.std(x))
    return (x - mu) / (sd + eps)


# ---------------------------------------------------------------------------
# Log-Mel spectrogram for PCG (SPEC Section 3: pcg_mels=64, pcg_frames=128)
# ---------------------------------------------------------------------------
def _hz_to_mel(f: np.ndarray) -> np.ndarray:
    """HTK mel scale."""
    return 2595.0 * np.log10(1.0 + f / 700.0)


def _mel_to_hz(m: np.ndarray) -> np.ndarray:
    return 700.0 * (10.0 ** (m / 2595.0) - 1.0)


def _mel_filterbank(
    n_mels: int, n_fft: int, fs: float, fmin: float, fmax: float
) -> np.ndarray:
    """Triangular mel filterbank matrix, shape [n_mels, n_fft//2 + 1]."""
    n_bins = n_fft // 2 + 1
    fft_freqs = np.linspace(0.0, fs / 2.0, n_bins)

    mel_min = _hz_to_mel(np.array([fmin]))[0]
    mel_max = _hz_to_mel(np.array([fmax]))[0]
    mel_points = np.linspace(mel_min, mel_max, n_mels + 2)
    hz_points = _mel_to_hz(mel_points)

    fb = np.zeros((n_mels, n_bins), dtype=np.float64)
    for m in range(1, n_mels + 1):
        f_left, f_center, f_right = hz_points[m - 1], hz_points[m], hz_points[m + 1]
        left = (fft_freqs - f_left) / max(f_center - f_left, 1e-9)
        right = (f_right - fft_freqs) / max(f_right - f_center, 1e-9)
        tri = np.clip(np.minimum(left, right), 0.0, None)
        fb[m - 1] = tri
    return fb


def log_mel_spectrogram(
    x: np.ndarray,
    fs: float,
    n_mels: int = 64,
    n_frames: int = 128,
    fmin: float = 20.0,
    fmax: Optional[float] = 400.0,
    n_fft: int = 512,
) -> np.ndarray:
    """Log-Mel spectrogram of a PCG segment (SPEC Section 3 PCG branch).

    Produces an ``[n_mels, n_frames]`` array (64 x 128 by default) suitable for
    the 2-D ``PCGEncoder``.  The band ``[fmin, fmax]`` defaults to the Table 4
    PCG band (20–400 Hz).  The hop is chosen so the STFT yields exactly
    ``n_frames`` columns, then the result is trimmed/padded to ``n_frames``.

    Parameters
    ----------
    x : np.ndarray
        1-D PCG segment (ideally already band-passed to 20–400 Hz).
    fs : float
        Sampling frequency (Hz).
    n_mels : int
        Number of mel bands (default 64 = ``pcg_mels``).
    n_frames : int
        Number of time frames (default 128 = ``pcg_frames``).
    fmin, fmax : float
        Mel band edges (Hz).  ``fmax`` defaults to 400 Hz, capped at Nyquist.
    n_fft : int
        FFT size / window length in samples.

    Returns
    -------
    np.ndarray
        ``[n_mels, n_frames]`` log-power mel spectrogram (natural-log dB-like
        scale), float64.
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    x = _interp_nan(x)
    if fmax is None:
        fmax = fs / 2.0
    fmax = min(fmax, fs / 2.0)

    if x.size < n_fft:
        x = np.pad(x, (0, n_fft - x.size), mode="constant")

    # Hop so that we get ~n_frames frames: frames = 1 + (len - n_fft)//hop.
    if x.size <= n_fft:
        hop = max(1, n_fft // 4)
    else:
        hop = max(1, int(np.ceil((x.size - n_fft) / max(n_frames - 1, 1))))

    window = get_window("hann", n_fft, fftbins=True)

    # Frame the signal.
    frames: List[np.ndarray] = []
    start = 0
    while start + n_fft <= x.size and len(frames) < n_frames:
        frames.append(x[start : start + n_fft] * window)
        start += hop
    if not frames:
        frames.append(np.pad(x[:n_fft], (0, max(0, n_fft - x.size)), "constant") * window)

    frame_mat = np.stack(frames, axis=0)  # [T, n_fft]
    spec = np.abs(np.fft.rfft(frame_mat, n=n_fft, axis=1)) ** 2  # power [T, bins]
    # Power is non-negative; force contiguous float64 so the mel projection is
    # numerically clean (avoids stray matmul warnings on some BLAS builds).
    spec = np.ascontiguousarray(np.clip(spec, 0.0, None), dtype=np.float64)

    fb = np.ascontiguousarray(
        _mel_filterbank(n_mels, n_fft, fs, fmin, fmax), dtype=np.float64
    )  # [n_mels, bins]
    mel = np.dot(spec, fb.T)  # [T, n_mels]
    log_mel = np.log(np.clip(mel, 0.0, None) + 1e-8).T  # [n_mels, T]

    # Fix time dimension to exactly n_frames.
    if log_mel.shape[1] >= n_frames:
        log_mel = log_mel[:, :n_frames]
    else:
        pad = n_frames - log_mel.shape[1]
        log_mel = np.pad(log_mel, ((0, 0), (0, pad)), mode="edge")
    return log_mel.astype(np.float64)


# ---------------------------------------------------------------------------
# Batch-contract record assembly (SPEC Section 2)
# ---------------------------------------------------------------------------
def build_window_record(
    *,
    ecg: Optional[np.ndarray],
    ppg: Optional[np.ndarray],
    pcg: Optional[np.ndarray],
    hrv: np.ndarray,
    proxy: np.ndarray,
    clinical: np.ndarray,
    morph_target: np.ndarray,
    sqi: np.ndarray,
    mask: np.ndarray,
    y: int,
    activity: int,
    patient_id: int,
    config=None,
    fs: Optional[Dict[str, float]] = None,
    normalize: bool = True,
) -> Dict[str, "torch.Tensor"]:
    """Assemble one batch-contract sample dict from raw signals + features.

    Implements the per-sample side of SPEC Section 2 (the batch is later formed
    by the default ``DataLoader`` collation, which stacks these along dim 0).
    Waveforms are band-passed (Table 4), resampled to the encoder length, and
    z-scored; PCG is turned into a log-Mel spectrogram.  Missing waveforms are
    zero-filled and their ``mask`` column is expected to already be 0
    (SPEC Section 2: "Missing waveform tensors may be zero-filled ... mask
    column = 0").

    Parameters
    ----------
    ecg, ppg : np.ndarray | None
        Raw 1-D waveform windows (any length / sample rate); ``None`` => absent.
    pcg : np.ndarray | None
        Raw 1-D PCG window; ``None`` => absent (optional branch).
    hrv : np.ndarray
        10-dim HRV feature vector (Eq. 5, from ``features.hrv_features``).
    proxy : np.ndarray
        4-dim activity-motion proxy components (Eq. 7).
    clinical : np.ndarray
        ``clinical_dim`` clinical feature vector.
    morph_target : np.ndarray
        ``morph_dim`` morphological descriptor target for L_morph (Eq. 21).
    sqi : np.ndarray
        6-dim quality index q_r, order = MODALITIES (Eq. 10).
    mask : np.ndarray
        6-dim availability mask m_r, order = MODALITIES (Eq. 11), values {0,1}.
    y : int
        Binary window label (Eq. 2–3), from ``endpoints.label_window``.
    activity : int
        Activity tertile class in {0,1,2} (proxy anchoring / adversary target).
    patient_id : int
        Integer patient id (used for patient-disjoint splits).
    config : Config | None
        If given, its ``data`` block supplies the target lengths
        (``ecg_len``, ``ppg_len``, ``pcg_mels``, ``pcg_frames``,
        ``clinical_dim``, ``morph_dim``); otherwise SPEC defaults are used.
    fs : dict | None
        Optional per-modality sampling rates (keys "ecg"/"ppg"/"pcg"); defaults
        to the ``native_fs`` in ``PROCESSING_BANDS``.
    normalize : bool
        Z-score waveforms after resampling (recommended).

    Returns
    -------
    dict[str, torch.Tensor]
        Keys and shapes exactly per SPEC Section 2 (per-sample, no batch dim on
        the vectors; waveforms carry their channel dim):
        ``ecg``  [1, ecg_len], ``ppg`` [1, ppg_len],
        ``pcg``  [1, pcg_mels, pcg_frames], ``proxy`` [4], ``hrv`` [10],
        ``clinical`` [clinical_dim], ``sqi`` [6], ``mask`` [6], ``y`` scalar,
        ``activity`` scalar long, ``morph_target`` [morph_dim],
        ``patient_id`` scalar long.
    """
    # --- resolve target dims from config (or SPEC defaults) ----------------
    ecg_len = _cfg(config, "ecg_len", 512)
    ppg_len = _cfg(config, "ppg_len", 512)
    pcg_mels = _cfg(config, "pcg_mels", 64)
    pcg_frames = _cfg(config, "pcg_frames", 128)
    clinical_dim = _cfg(config, "clinical_dim", 16)
    morph_dim = _cfg(config, "morph_dim", 24)

    fs = fs or {}
    fs_ecg = float(fs.get("ecg", PROCESSING_BANDS["ecg"]["native_fs"]))
    fs_ppg = float(fs.get("ppg", PROCESSING_BANDS["ppg"]["native_fs"]))
    fs_pcg = float(fs.get("pcg", PROCESSING_BANDS["pcg"]["native_fs"]))

    # --- ECG ---------------------------------------------------------------
    if ecg is None:
        ecg_arr = np.zeros(ecg_len, dtype=np.float64)
    else:
        ecg_f = bandpass_modality(np.asarray(ecg, dtype=np.float64), fs_ecg, "ecg")
        ecg_arr = resample(ecg_f, fs_ecg, ecg_len)
        if normalize:
            ecg_arr = zscore(ecg_arr)

    # --- PPG ---------------------------------------------------------------
    if ppg is None:
        ppg_arr = np.zeros(ppg_len, dtype=np.float64)
    else:
        ppg_f = bandpass_modality(np.asarray(ppg, dtype=np.float64), fs_ppg, "ppg")
        ppg_arr = resample(ppg_f, fs_ppg, ppg_len)
        if normalize:
            ppg_arr = zscore(ppg_arr)

    # --- PCG (optional) ----------------------------------------------------
    if pcg is None:
        pcg_arr = np.zeros((pcg_mels, pcg_frames), dtype=np.float64)
    else:
        pcg_f = bandpass_modality(np.asarray(pcg, dtype=np.float64), fs_pcg, "pcg")
        pcg_arr = log_mel_spectrogram(
            pcg_f, fs_pcg, n_mels=pcg_mels, n_frames=pcg_frames
        )

    # --- vector features: enforce exact dims -------------------------------
    hrv_v = _fit_dim(np.asarray(hrv, dtype=np.float64).ravel(), 10, "hrv")
    proxy_v = _fit_dim(np.asarray(proxy, dtype=np.float64).ravel(), 4, "proxy")
    clinical_v = _fit_dim(
        np.asarray(clinical, dtype=np.float64).ravel(), clinical_dim, "clinical"
    )
    morph_v = _fit_dim(
        np.asarray(morph_target, dtype=np.float64).ravel(), morph_dim, "morph_target"
    )
    sqi_v = _fit_dim(np.asarray(sqi, dtype=np.float64).ravel(), len(MODALITIES), "sqi")
    mask_v = _fit_dim(np.asarray(mask, dtype=np.float64).ravel(), len(MODALITIES), "mask")
    sqi_v = np.clip(sqi_v, 0.0, 1.0)
    mask_v = (mask_v > 0.5).astype(np.float64)

    return {
        "ecg": torch.from_numpy(ecg_arr).float().unsqueeze(0),        # [1, L]
        "ppg": torch.from_numpy(ppg_arr).float().unsqueeze(0),        # [1, L]
        "pcg": torch.from_numpy(pcg_arr).float().unsqueeze(0),        # [1, M, T]
        "proxy": torch.from_numpy(proxy_v).float(),                   # [4]
        "hrv": torch.from_numpy(hrv_v).float(),                       # [10]
        "clinical": torch.from_numpy(clinical_v).float(),             # [clinical_dim]
        "sqi": torch.from_numpy(sqi_v).float(),                       # [6]
        "mask": torch.from_numpy(mask_v).float(),                     # [6]
        "y": torch.tensor(float(y), dtype=torch.float32),             # scalar
        "activity": torch.tensor(int(activity), dtype=torch.long),    # scalar
        "morph_target": torch.from_numpy(morph_v).float(),            # [morph_dim]
        "patient_id": torch.tensor(int(patient_id), dtype=torch.long),
    }


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _cfg(config, field: str, default):
    """Read ``config.data.<field>`` if present, else return ``default``."""
    if config is None:
        return default
    data = getattr(config, "data", None)
    if data is None:
        return default
    return getattr(data, field, default)


def _fit_dim(v: np.ndarray, dim: int, name: str) -> np.ndarray:
    """Truncate/zero-pad a 1-D vector to exactly ``dim`` (with a warning-free
    contract check that the caller is not wildly off)."""
    v = v.ravel()
    if v.size == dim:
        return v
    if v.size > dim:
        return v[:dim]
    return np.pad(v, (0, dim - v.size), mode="constant")


class FeatureStandardizer:
    """Training-set standardiser for the tabular feature vectors.

    Waveforms are z-scored per window (:func:`zscore`), but the tabular feature
    vectors (HRV, Eq. 5; clinical metadata; activity/motion proxy components,
    Eq. 7) live on heterogeneous physiological scales. The HRV vector in
    particular is also the reconstruction target of the HRV anchor head
    (Eq. 18-19); left on its raw scale it makes ``L_hrv`` dominate the
    multi-objective loss (Eq. 28). Fit this **only** on the training split (to
    avoid leakage), persist it, and apply it to validation, test, and deployment
    windows. The synthetic cohort applies the identical transform via
    :meth:`am_dimnet.data.synthetic.SyntheticCohort.set_hrv_standardizer`.
    """

    def __init__(self, keys: Sequence[str] = ("hrv", "clinical", "proxy")) -> None:
        self.keys = tuple(keys)
        self.mean_: Dict[str, np.ndarray] = {}
        self.std_: Dict[str, np.ndarray] = {}

    def fit(self, records: Sequence[dict], masks: Optional[Sequence[dict]] = None) -> "FeatureStandardizer":
        """Fit per-feature mean/std over training ``records`` (window dicts).

        If ``masks`` is supplied (per-record ``{key: 0/1}``), rows where a
        modality is unavailable are excluded so zero-filled placeholders do not
        bias the statistics.
        """
        for k in self.keys:
            rows = []
            for i, rec in enumerate(records):
                if k not in rec:
                    continue
                if masks is not None and float(masks[i].get(k, 1.0)) < 0.5:
                    continue
                rows.append(np.asarray(rec[k], dtype=np.float64).ravel())
            if not rows:
                continue
            x = np.stack(rows, axis=0)
            sd = x.std(axis=0)
            sd[sd < 1e-6] = 1e-6
            self.mean_[k] = x.mean(axis=0).astype(np.float32)
            self.std_[k] = sd.astype(np.float32)
        return self

    def transform_vector(self, key: str, vec: np.ndarray) -> np.ndarray:
        """Standardise a single feature vector; identity if ``key`` was not fit."""
        if key not in self.mean_:
            return np.asarray(vec, dtype=np.float32)
        return ((np.asarray(vec, dtype=np.float32) - self.mean_[key]) / self.std_[key]).astype(np.float32)

    def transform_record(self, record: dict) -> dict:
        """Return a copy of ``record`` with its tabular feature vectors standardised."""
        out = dict(record)
        for k in self.keys:
            if k in out:
                out[k] = self.transform_vector(k, out[k])
        return out

    def save(self, path: str) -> None:
        payload = {"keys": np.array(self.keys, dtype=object)}
        for k in self.mean_:
            payload[f"mean__{k}"] = self.mean_[k]
            payload[f"std__{k}"] = self.std_[k]
        np.savez(path, **payload)

    @classmethod
    def load(cls, path: str) -> "FeatureStandardizer":
        data = np.load(path, allow_pickle=True)
        obj = cls(keys=tuple(str(k) for k in data["keys"].tolist()))
        for k in obj.keys:
            if f"mean__{k}" in data.files:
                obj.mean_[k] = data[f"mean__{k}"].astype(np.float32)
                obj.std_[k] = data[f"std__{k}"].astype(np.float32)
        return obj
