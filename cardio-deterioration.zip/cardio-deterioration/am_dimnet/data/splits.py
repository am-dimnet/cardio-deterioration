"""Patient-disjoint dataset splitting and split reporting (paper Tables 10-11).

AM-DiMNet evaluates at the patient level, so *all* windows of a given patient
must live in exactly one of train/val/test to prevent identity leakage. This
module provides:

    patient_split   -- deterministic, patient-disjoint train/val/test partition.
    split_summary   -- per-split cohort table (Tables 10-11): #patients,
                       #positive patients, #windows, #positive windows, and
                       #first-qualifying endpoints.

Both are pure NumPy/pandas and carry no torch dependency.
"""

from __future__ import annotations

from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd

__all__ = ["patient_split", "split_summary"]


def patient_split(
    patient_ids: Iterable[int],
    ratios: tuple[float, float, float] = (0.7, 0.15, 0.15),
    seed: int = 0,
) -> dict[str, set]:
    """Partition *unique patients* into disjoint train/val/test sets.

    The split is on **patients**, never on windows, so no patient appears in more
    than one split (identity-leakage guard; see paper Sec. on evaluation).

    Parameters
    ----------
    patient_ids : iterable of int
        Patient identifiers, possibly with repeats (one per window). Uniqued
        internally.
    ratios : (float, float, float)
        (train, val, test) fractions; need not sum to exactly 1 (renormalised).
    seed : int
        RNG seed for the deterministic shuffle.

    Returns
    -------
    dict
        ``{"train": set(pid), "val": set(pid), "test": set(pid)}`` -- disjoint,
        with every unique patient assigned to exactly one split.
    """
    if len(ratios) != 3:
        raise ValueError("ratios must be a 3-tuple (train, val, test)")
    total = float(sum(ratios))
    if total <= 0:
        raise ValueError("ratios must sum to a positive number")
    r_train, r_val, _r_test = (r / total for r in ratios)

    unique = np.unique(np.asarray(list(patient_ids)))
    rng = np.random.default_rng(seed)
    perm = rng.permutation(unique.shape[0])
    ordered = unique[perm]

    n = ordered.shape[0]
    n_train = int(round(r_train * n))
    n_val = int(round(r_val * n))
    # Guard tiny cohorts so val/test are non-empty when at least 3 patients exist.
    if n >= 3:
        n_train = min(max(n_train, 1), n - 2)
        n_val = min(max(n_val, 1), n - n_train - 1)

    train_ids = ordered[:n_train]
    val_ids = ordered[n_train : n_train + n_val]
    test_ids = ordered[n_train + n_val :]

    # Cast to plain python ints so the sets compare cleanly against int labels.
    return {
        "train": set(int(p) for p in train_ids),
        "val": set(int(p) for p in val_ids),
        "test": set(int(p) for p in test_ids),
    }


def _record_field(rec: Mapping, *names: str, default=None):
    """Fetch the first present key among ``names`` from a record mapping."""
    for name in names:
        if name in rec:
            return rec[name]
    return default


def split_summary(
    records: Sequence[Mapping],
    splits: Mapping[str, set],
) -> pd.DataFrame:
    """Build the per-split cohort summary table (Tables 10-11).

    Parameters
    ----------
    records : sequence of mapping
        One record per window. Each must expose (missing keys tolerated):

        * ``patient_id`` (int)                     -- patient identifier
        * ``y`` (0/1)                              -- window deterioration label
        * ``first_qualifying_endpoint`` (str|None) -- endpoint component that first
          qualifies this window as positive (Table 1), or None/"" if negative.

    splits : mapping
        ``{"train"/"val"/"test": set(pid)}`` from :func:`patient_split`.

    Returns
    -------
    pandas.DataFrame
        Indexed by split name (plus an "all" row) with columns::

            patients, positive_patients, windows, positive_windows,
            first_qualifying_endpoints

        ``positive_patients`` counts patients with >=1 positive window;
        ``first_qualifying_endpoints`` counts positive windows carrying a
        non-empty first-qualifying-endpoint tag.
    """
    # Map each patient to its split for O(1) lookup.
    pid_to_split: dict[int, str] = {}
    for split_name, pids in splits.items():
        for pid in pids:
            pid_to_split[int(pid)] = split_name

    split_order = list(splits.keys())
    columns = [
        "patients",
        "positive_patients",
        "windows",
        "positive_windows",
        "first_qualifying_endpoints",
    ]

    # Accumulators keyed by split name.
    windows = {s: 0 for s in split_order}
    pos_windows = {s: 0 for s in split_order}
    fq_endpoints = {s: 0 for s in split_order}
    patients: dict[str, set] = {s: set() for s in split_order}
    pos_patients: dict[str, set] = {s: set() for s in split_order}

    for rec in records:
        pid = _record_field(rec, "patient_id", "pid")
        if pid is None:
            continue
        pid = int(pid)
        split_name = pid_to_split.get(pid)
        if split_name is None:
            continue  # patient not assigned to any split; skip defensively

        y = int(_record_field(rec, "y", "label", default=0) or 0)
        fqe = _record_field(rec, "first_qualifying_endpoint", "fqe", default=None)

        windows[split_name] += 1
        patients[split_name].add(pid)
        if y == 1:
            pos_windows[split_name] += 1
            pos_patients[split_name].add(pid)
            if fqe not in (None, ""):
                fq_endpoints[split_name] += 1

    rows = {}
    for s in split_order:
        rows[s] = [
            len(patients[s]),
            len(pos_patients[s]),
            windows[s],
            pos_windows[s],
            fq_endpoints[s],
        ]

    df = pd.DataFrame.from_dict(rows, orient="index", columns=columns)
    # Aggregate "all" row across splits.
    df.loc["all"] = df.sum(axis=0)
    df.index.name = "split"
    return df.astype(int)
