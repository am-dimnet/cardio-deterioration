"""Synthetic AM-DiMNet cohort (powers the smoke test; no external data).

This module fabricates a small, self-contained cohort whose statistical structure
mirrors the real design so the full pipeline (encoders -> quality-aware gated
fusion -> structured factorization -> heads -> losses -> metrics) can be
exercised end-to-end on CPU. It is faithful to the *method*, not to any real
patient data.

Design properties enforced here (paper Sec. 5 data contract):
    * Every sample is a plain ``dict`` matching the batch contract of SPEC Sec. 2
      exactly (keys, shapes, dtypes, MODALITIES/PROXY_COMPONENTS/HRV ordering).
    * Windows are grouped by patient; labels correlate with an injected, per-window
      latent that blends an *autonomic* (HRV-driven) and a *morphological* signal
      -- the two clinically-meaningful factors AM-DiMNet is built to disentangle
      (Eq. 16-17).
    * Cohort prevalence is calibrated to ``prevalence`` (default 0.219).
    * ~18% of windows randomly drop ONE non-ECG/PPG modality (mask column = 0,
      tensor zero-filled) to stress the quality-aware fusion (Eq. 14-15) and
      modality-dropout robustness.
    * ``activity`` is the proxy tertile of the window's activity-motion proxy
      score (Eq. 9 -> Eq. tertile), used for anchoring/adversarial invariance.

``make_loaders`` returns patient-disjoint train/val/test ``DataLoader``s using
:func:`am_dimnet.data.splits.patient_split`.
"""

from __future__ import annotations

import math
from typing import Iterable

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset

from ..constants import (
    HRV_FEATURES,
    MODALITIES,
    PROXY_COMPONENTS,
    WAVEFORM_MODS,
    mask_index,
    sqi_index,
)
from .features import activity_proxy_score, activity_tertile
from .splits import patient_split

__all__ = ["SyntheticCohort", "make_loaders"]

# Modalities eligible for random dropout = everything that is NOT a core waveform.
_DROPPABLE_MODS = [m for m in MODALITIES if m not in WAVEFORM_MODS]


class SyntheticCohort(Dataset):
    """A synthetic window-level cohort following the AM-DiMNet batch contract.

    Parameters
    ----------
    config : Config
        Provides the required dimensions: ``data.ecg_len``, ``data.ppg_len``,
        ``data.pcg_mels``, ``data.pcg_frames``, ``data.clinical_dim``,
        ``data.morph_dim``.
    n_patients : int
        Number of distinct synthetic patients.
    windows_per_patient : (int, int)
        Inclusive [min, max] window count sampled per patient (irregular cohort).
    prevalence : float
        Target fraction of positive windows (Eq. 1 base rate; default 0.219).
    dropout_rate : float
        Fraction of windows that drop exactly one non-ECG/PPG modality (~0.18).
    seed : int
        Master RNG seed; the whole cohort is deterministic given ``seed``.

    Notes
    -----
    Each item is materialised lazily but deterministically from a per-window RNG
    seeded by ``(seed, global_window_index)``, so ``__getitem__`` is pure and
    reproducible regardless of access order (important for shuffled loaders).
    """

    def __init__(
        self,
        config,
        n_patients: int = 64,
        windows_per_patient: tuple[int, int] = (20, 60),
        prevalence: float = 0.219,
        dropout_rate: float = 0.18,
        seed: int = 0,
    ) -> None:
        super().__init__()
        self.config = config
        self.n_patients = int(n_patients)
        self.prevalence = float(prevalence)
        self.dropout_rate = float(dropout_rate)
        self.seed = int(seed)

        d = config.data
        self.ecg_len = int(d.ecg_len)
        self.ppg_len = int(d.ppg_len)
        self.pcg_mels = int(d.pcg_mels)
        self.pcg_frames = int(d.pcg_frames)
        self.clinical_dim = int(d.clinical_dim)
        self.morph_dim = int(d.morph_dim)
        self.n_hrv = len(HRV_FEATURES)
        self.n_proxy = len(PROXY_COMPONENTS)
        self.n_mods = len(MODALITIES)

        lo, hi = int(windows_per_patient[0]), int(windows_per_patient[1])
        if lo > hi:
            lo, hi = hi, lo

        # --- assign a window count to every patient (deterministic) -----------
        cfg_rng = np.random.default_rng(self.seed)
        counts = cfg_rng.integers(lo, hi + 1, size=self.n_patients)

        # Random per-patient morphological/autonomic "phenotype" offsets so that
        # some patients are intrinsically higher risk (adds patient-level signal
        # on top of per-window variation, matching cluster structure).
        patient_bias = cfg_rng.normal(0.0, 0.6, size=self.n_patients)

        # Build a flat index: (patient_id, per-window seed) for every window.
        self._index: list[tuple[int, int]] = []
        self._patient_bias: dict[int, float] = {}
        gw = 0
        for pid in range(self.n_patients):
            self._patient_bias[pid] = float(patient_bias[pid])
            for _ in range(int(counts[pid])):
                self._index.append((pid, gw))
                gw += 1
        self._n = len(self._index)

        # Calibrate the logistic bias so the realised prevalence hits the target.
        self._risk_bias = self._calibrate_bias()

        # Per-feature HRV standardiser (fit on TRAIN only by ``make_loaders``).
        # None => emit raw physiological-scale HRV (used while fitting the stats).
        self._hrv_mean: "np.ndarray | None" = None
        self._hrv_std: "np.ndarray | None" = None

    # ------------------------------------------------------------------ utils
    def __len__(self) -> int:  # noqa: D401 - simple length
        return self._n

    @property
    def patient_ids(self) -> np.ndarray:
        """Per-window patient id array (length == len(self))."""
        return np.array([pid for pid, _ in self._index], dtype=np.int64)

    def set_hrv_standardizer(self, mean: np.ndarray, std: np.ndarray) -> None:
        """Freeze a per-feature HRV standardiser (fit on the training split).

        The 10-D HRV vector (Eq. 5) is emitted on raw physiological scales and is
        also the reconstruction target of the HRV anchor head (Eq. 18-19); without
        standardisation ``L_hrv`` dwarfs every other loss term. ``make_loaders``
        fits ``mean``/``std`` on TRAIN windows only and applies them to all splits,
        mirroring the training-set ``StandardScaler`` used on the real MIMIC-IV
        features (see ``data/preprocessing.py``).
        """
        self._hrv_mean = np.asarray(mean, dtype=np.float32).reshape(-1)
        self._hrv_std = np.asarray(std, dtype=np.float32).reshape(-1)
        self._hrv_std[self._hrv_std < 1e-6] = 1e-6

    def _latent_and_score(self, pid: int, gw: int) -> tuple[float, float, np.ndarray, float]:
        """Deterministically derive the risk latent + activity proxy for a window.

        Returns
        -------
        (risk_logit_core, activity_score, proxy_raw, morph_energy)
            ``risk_logit_core`` -- autonomic+morphological blend (pre-bias),
            ``activity_score``   -- Eq. 9 proxy score in [0,1],
            ``proxy_raw``        -- 4-D proxy component vector (already in [0,1]),
            ``morph_energy``     -- scalar driving the morphological descriptor.
        """
        rng = np.random.default_rng((self.seed, gw))

        # Injected latent factors AM-DiMNet is meant to disentangle:
        #   autonomic latent -> drives HRV features + part of the risk.
        #   morphological latent -> drives the morph descriptor + part of the risk.
        autonomic = float(rng.normal(0.0, 1.0))
        morph = float(rng.normal(0.0, 1.0))

        # Activity-motion proxy components (Eq. 7), already scaled to ~[0,1].
        # A shared per-window activity *level* shifts all four components together
        # (correlated, as real motion artefacts are), so the mean-based proxy
        # score (Eq. 9) spans [0,1] and all three activity tertiles (Table 9
        # thresholds 0.34/0.61) stay meaningfully populated -- the anchoring
        # (Eq. 22) and adversarial (Eq. 23) branches then see every class.
        level = float(rng.uniform(0.0, 1.0))
        proxy_raw = np.clip(
            level + rng.normal(0.0, 0.12, size=self.n_proxy), 0.0, 1.0
        ).astype(np.float64)
        activity_score = activity_proxy_score(proxy_raw)

        # Higher physical activity mildly confounds morphology (nuisance), which
        # is exactly what the adversarial branch (Eq. 23) must render invariant.
        morph_energy = morph + 0.7 * (activity_score - 0.5)

        # Core risk = autonomic + morphological signal + patient phenotype bias.
        risk_logit_core = (
            1.35 * autonomic
            + 1.10 * morph
            + self._patient_bias[pid]
        )
        return risk_logit_core, activity_score, proxy_raw, morph_energy

    def _calibrate_bias(self) -> float:
        """Bisection-solve the global logit bias so E[sigmoid] == prevalence."""
        cores = np.array(
            [self._latent_and_score(pid, gw)[0] for pid, gw in self._index],
            dtype=np.float64,
        )
        if cores.size == 0:
            return 0.0

        def mean_prob(bias: float) -> float:
            return float(np.mean(1.0 / (1.0 + np.exp(-(cores + bias)))))

        lo, hi = -20.0, 20.0
        target = self.prevalence
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if mean_prob(mid) < target:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    # -------------------------------------------------------------- item build
    def __getitem__(self, idx: int) -> dict:
        pid, gw = self._index[idx]
        rng = np.random.default_rng((self.seed, gw, 7))  # signal RNG (distinct)

        risk_core, activity_score, proxy_raw, morph_energy = self._latent_and_score(pid, gw)

        # --- label: Bernoulli on the calibrated risk probability -------------
        prob = 1.0 / (1.0 + math.exp(-(risk_core + self._risk_bias)))
        y = 1.0 if rng.random() < prob else 0.0

        # Recover the autonomic latent so HRV features co-vary with risk. We use
        # the same core RNG stream deterministically.
        lat_rng = np.random.default_rng((self.seed, gw))
        autonomic = float(lat_rng.normal(0.0, 1.0))
        morph = float(lat_rng.normal(0.0, 1.0))

        # --- waveforms: synthetic quasi-periodic signals ---------------------
        ecg = self._make_ecg(rng, self.ecg_len, autonomic, y)
        ppg = self._make_ppg(rng, self.ppg_len, autonomic, y)
        pcg = self._make_pcg(rng, self.pcg_mels, self.pcg_frames, morph_energy)

        # --- vector features -------------------------------------------------
        hrv = self._make_hrv(rng, autonomic)                     # [10]
        if self._hrv_mean is not None:                           # train-set z-score
            hrv = ((hrv - self._hrv_mean) / self._hrv_std).astype(np.float32)
        clinical = self._make_clinical(rng, risk_core)           # [clinical_dim]
        morph_target = self._make_morph_target(rng, morph_energy)  # [morph_dim]

        proxy = proxy_raw.astype(np.float32)                     # [4]
        activity = int(activity_tertile(activity_score))         # {0,1,2}

        # --- quality (SQI) + mask, ordered as MODALITIES ---------------------
        sqi_vec = np.clip(rng.beta(6.0, 2.0, size=self.n_mods), 0.0, 1.0).astype(np.float32)
        mask_vec = np.ones(self.n_mods, dtype=np.float32)

        # ~dropout_rate of windows drop exactly ONE non-ECG/PPG modality.
        if rng.random() < self.dropout_rate:
            drop_mod = _DROPPABLE_MODS[int(rng.integers(0, len(_DROPPABLE_MODS)))]
            j = mask_index(drop_mod)
            mask_vec[j] = 0.0
            sqi_vec[j] = 0.0  # quality collapses when a modality is absent (Eq. 11)

        # Zero-fill the tensors of any dropped modality so shapes stay fixed.
        if mask_vec[mask_index("proxy")] == 0.0:
            proxy = np.zeros_like(proxy)
        if mask_vec[mask_index("hrv")] == 0.0:
            hrv = np.zeros_like(hrv)
        if mask_vec[mask_index("clinical")] == 0.0:
            clinical = np.zeros_like(clinical)
        if mask_vec[mask_index("pcg")] == 0.0:
            pcg = np.zeros_like(pcg)

        return {
            "ecg": torch.from_numpy(ecg).float(),               # [1, ecg_len]
            "ppg": torch.from_numpy(ppg).float(),               # [1, ppg_len]
            "pcg": torch.from_numpy(pcg).float(),               # [1, mels, frames]
            "proxy": torch.from_numpy(proxy).float(),           # [4]
            "hrv": torch.from_numpy(hrv).float(),               # [10]
            "clinical": torch.from_numpy(clinical).float(),     # [clinical_dim]
            "sqi": torch.from_numpy(sqi_vec).float(),           # [6]
            "mask": torch.from_numpy(mask_vec).float(),         # [6]
            "y": torch.tensor(y, dtype=torch.float32),          # scalar
            "activity": torch.tensor(activity, dtype=torch.long),        # scalar
            "morph_target": torch.from_numpy(morph_target).float(),      # [morph_dim]
            "patient_id": torch.tensor(int(pid), dtype=torch.long),      # scalar
        }

    # --------------------------------------------------------- signal factories
    @staticmethod
    def _make_ecg(rng: np.random.Generator, length: int, autonomic: float, y: float) -> np.ndarray:
        """Quasi-periodic ECG-like waveform; HR shifts with the autonomic latent."""
        t = np.linspace(0.0, 5.0, length)  # ~5 s window
        hr = 70.0 + 8.0 * autonomic + 10.0 * y  # bpm; tachy with risk
        f = hr / 60.0
        phase = 2.0 * np.pi * f * t
        # R-peak-like spikes via a narrow raised-cosine on the beat phase.
        beat = np.cos(phase)
        qrs = np.exp(3.0 * (beat - 1.0)) * np.sign(np.sin(phase))
        wave = qrs + 0.15 * np.sin(2.0 * phase)
        wave = wave + rng.normal(0.0, 0.05, size=length)
        wave = (wave - wave.mean()) / (wave.std() + 1e-6)
        return wave.reshape(1, length).astype(np.float32)

    @staticmethod
    def _make_ppg(rng: np.random.Generator, length: int, autonomic: float, y: float) -> np.ndarray:
        """Smooth pulsatile PPG-like waveform sharing the HR of the ECG."""
        t = np.linspace(0.0, 5.0, length)
        hr = 70.0 + 8.0 * autonomic + 10.0 * y
        f = hr / 60.0
        phase = 2.0 * np.pi * f * t
        wave = np.sin(phase) + 0.3 * np.sin(2.0 * phase + 0.4)
        wave = wave + rng.normal(0.0, 0.04, size=length)
        wave = (wave - wave.mean()) / (wave.std() + 1e-6)
        return wave.reshape(1, length).astype(np.float32)

    @staticmethod
    def _make_pcg(
        rng: np.random.Generator, n_mels: int, n_frames: int, morph_energy: float
    ) -> np.ndarray:
        """Log-Mel-spectrogram-like PCG image; band energy tracks morphology."""
        base = rng.normal(0.0, 0.5, size=(n_mels, n_frames))
        mel_axis = np.linspace(0.0, 1.0, n_mels).reshape(-1, 1)
        # A morphology-dependent low-frequency band (S1/S2 energy surrogate).
        band = np.exp(-((mel_axis - 0.3) ** 2) / 0.02) * (1.0 + 0.5 * morph_energy)
        img = base + band
        img = (img - img.mean()) / (img.std() + 1e-6)
        return img.reshape(1, n_mels, n_frames).astype(np.float32)

    def _make_hrv(self, rng: np.random.Generator, autonomic: float) -> np.ndarray:
        """10-D HRV vector whose autonomic tone co-varies with the latent (Eq. 5).

        Values are given plausible physiological scales; the vector is the
        reconstruction target of the HRV anchor head (Eq. 18-19), so it must
        correlate with the injected autonomic latent for the anchor to be learnable.
        """
        mean_nn = 850.0 - 60.0 * autonomic + rng.normal(0.0, 20.0)
        sdnn = max(5.0, 45.0 + 12.0 * autonomic + rng.normal(0.0, 5.0))
        rmssd = max(5.0, 40.0 + 15.0 * autonomic + rng.normal(0.0, 5.0))
        pnn50 = float(np.clip(0.15 + 0.12 * autonomic + rng.normal(0.0, 0.03), 0.0, 1.0))
        lf = max(1.0, 500.0 + 200.0 * autonomic + rng.normal(0.0, 50.0))
        hf = max(1.0, 400.0 - 150.0 * autonomic + rng.normal(0.0, 50.0))
        lfhf = lf / (hf + 1e-6)
        sd1 = rmssd / math.sqrt(2.0)
        sd2 = max(1.0, math.sqrt(max(1.0, 2.0 * sdnn ** 2 - 0.5 * rmssd ** 2)))
        sampen = float(np.clip(1.2 + 0.2 * autonomic + rng.normal(0.0, 0.1), 0.0, 3.0))
        vec = np.array(
            [mean_nn, sdnn, rmssd, pnn50, lf, hf, lfhf, sd1, sd2, sampen],
            dtype=np.float32,
        )
        assert vec.shape[0] == self.n_hrv
        return vec

    def _make_clinical(self, rng: np.random.Generator, risk_core: float) -> np.ndarray:
        """Clinical covariate vector; a few dims carry weak risk signal."""
        v = rng.normal(0.0, 1.0, size=self.clinical_dim).astype(np.float32)
        k = min(4, self.clinical_dim)
        v[:k] += (0.4 * risk_core)
        return v

    def _make_morph_target(self, rng: np.random.Generator, morph_energy: float) -> np.ndarray:
        """Morphological descriptor target driven by the morphological latent (Eq. 20-21)."""
        base = rng.normal(0.0, 1.0, size=self.morph_dim).astype(np.float32)
        modulation = np.linspace(0.5, 1.5, self.morph_dim).astype(np.float32)
        return base + (morph_energy * modulation).astype(np.float32)


# ---------------------------------------------------------------------------
# Patient-disjoint DataLoaders
# ---------------------------------------------------------------------------
def make_loaders(
    config,
    n_patients: int = 64,
    windows_per_patient: tuple[int, int] = (20, 60),
    prevalence: float = 0.219,
    dropout_rate: float = 0.18,
    seed: int = 0,
    ratios: tuple[float, float, float] = (0.7, 0.15, 0.15),
    batch_size: int | None = None,
    num_workers: int = 0,
) -> dict[str, DataLoader]:
    """Build patient-disjoint train/val/test ``DataLoader``s over a synthetic cohort.

    Uses :func:`am_dimnet.data.splits.patient_split` so no patient's windows leak
    across splits. Train loader shuffles; val/test do not. Batch size defaults to
    ``config.train.batch_size``.

    Parameters
    ----------
    config : Config
        Provides tensor dims and ``train.batch_size``.
    n_patients, windows_per_patient, prevalence, dropout_rate, seed :
        Forwarded to :class:`SyntheticCohort`.
    ratios : (float, float, float)
        Patient-level train/val/test fractions.
    batch_size : int, optional
        Override for ``config.train.batch_size``.
    num_workers : int
        DataLoader workers (0 keeps the smoke test single-process & deterministic).

    Returns
    -------
    dict
        ``{"train": DataLoader, "val": DataLoader, "test": DataLoader}``.
    """
    cohort = SyntheticCohort(
        config,
        n_patients=n_patients,
        windows_per_patient=windows_per_patient,
        prevalence=prevalence,
        dropout_rate=dropout_rate,
        seed=seed,
    )

    pids = cohort.patient_ids  # per-window patient ids
    splits = patient_split(pids, ratios=ratios, seed=seed)

    # Map each window index -> its split via patient membership.
    idx_by_split: dict[str, list[int]] = {"train": [], "val": [], "test": []}
    for i, pid in enumerate(pids.tolist()):
        for split_name, member in splits.items():
            if pid in member:
                idx_by_split[split_name].append(i)
                break

    # Fit an HRV standardiser on TRAIN windows only (no leakage), then freeze it on
    # the shared cohort so val/test are transformed with training-set statistics.
    hj = mask_index("hrv")
    train_hrv = [
        cohort[i]["hrv"].numpy()
        for i in idx_by_split["train"]
        if float(cohort[i]["mask"][hj]) > 0.5
    ]
    if train_hrv:
        arr = np.stack(train_hrv, axis=0)
        cohort.set_hrv_standardizer(arr.mean(axis=0), arr.std(axis=0))

    if batch_size is None:
        batch_size = int(config.train.batch_size)
    # Keep the smoke test snappy: never demand a batch larger than the split.
    bs = max(1, int(batch_size))

    g = torch.Generator()
    g.manual_seed(seed)

    def _make(split_name: str, shuffle: bool) -> DataLoader:
        subset = Subset(cohort, idx_by_split[split_name])
        split_bs = min(bs, max(1, len(subset)))
        return DataLoader(
            subset,
            batch_size=split_bs,
            shuffle=shuffle and len(subset) > 0,
            num_workers=num_workers,
            drop_last=False,
            generator=g if shuffle else None,
            collate_fn=collate_batch,
        )

    return {
        "train": _make("train", True),
        "val": _make("val", False),
        "test": _make("test", False),
    }


def collate_batch(samples: Iterable[dict]) -> dict:
    """Stack per-window sample dicts into a batch dict (SPEC Sec. 2).

    Scalar fields (``y``, ``activity``, ``patient_id``) become shape ``[B]``;
    all other fields stack along a new leading batch axis. This is equivalent to
    the default collate for these keys but is made explicit so the batch-dict
    contract is guaranteed regardless of torch's default-collate behaviour.
    """
    samples = list(samples)
    batch: dict = {}
    keys = samples[0].keys()
    for key in keys:
        batch[key] = torch.stack([s[key] for s in samples], dim=0)
    return batch
