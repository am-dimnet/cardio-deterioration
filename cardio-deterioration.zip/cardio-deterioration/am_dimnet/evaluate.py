"""Evaluation driver for AM-DiMNet (SPEC Section 7).

Loads a trained :class:`am_dimnet.models.am_dimnet.AMDiMNet`, runs it over an
evaluation :class:`~torch.utils.data.DataLoader`, and computes the full reported
metric suite:

    * **Patient-level discrimination** (primary) - window probabilities are
      aggregated to one score per patient with the top-decile rule
      (:func:`~am_dimnet.metrics.patient_top_decile`, Eq. 30); AUROC / AUPRC /
      macro-F1 / MCC / Brier are computed over patients, each reported with a
      **patient-cluster bootstrap** 95% CI (:func:`~am_dimnet.metrics.bootstrap_ci`).
    * **Window-level discrimination + operating point** - the same metrics at the
      window level, plus a decision threshold selected on the validation split
      (Youden by default, :func:`~am_dimnet.calibrate.select_operating_threshold`)
      and the confusion-derived operating-point statistics with alarm
      consolidation (:func:`~am_dimnet.metrics.operating_point_stats`).
    * **Calibration** - post-hoc temperature scaling fit on validation logits
      (:class:`~am_dimnet.calibrate.TemperatureScaler`), then ECE-15 (Eq. 35),
      Brier, and the reliability curve on the (calibrated) test probabilities.
    * **Decision-curve analysis** - net benefit across threshold probabilities
      (:func:`~am_dimnet.metrics.decision_curve`).

``evaluate_model`` returns a single nested ``dict`` of plain Python scalars and
lists (JSON-serialisable). The CLI writes it to ``--out`` as JSON and a flat CSV.

CLI: ``python -m am_dimnet.evaluate --config configs/default.yaml --ckpt run.pt --out results/``
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader

from .calibrate import TemperatureScaler, select_operating_threshold
from .config import Config
from .data.synthetic import make_loaders
from .metrics import (
    auprc,
    auroc,
    bootstrap_ci,
    brier,
    decision_curve,
    expected_calibration_error,
    macro_f1,
    mcc,
    operating_point_stats,
    patient_top_decile,
    reliability_curve,
)
from .models.am_dimnet import AMDiMNet

__all__ = ["collect_logits", "evaluate_model", "main"]


# ---------------------------------------------------------------------------
# inference: gather logits / probs / labels / patient ids over a loader
# ---------------------------------------------------------------------------
@torch.no_grad()
def collect_logits(
    model: AMDiMNet,
    loader: DataLoader,
    device: Optional[torch.device] = None,
) -> Dict[str, np.ndarray]:
    """Run ``model`` over ``loader`` and return concatenated arrays.

    Returns a dict with 1-D numpy arrays::

        {"logit": [N], "prob": [N], "y": [N], "patient_id": [N]}

    ``prob`` is the model's own sigmoid output (uncalibrated); ``logit`` is the
    pre-sigmoid score used to fit temperature scaling on the validation split.
    """
    device = device or torch.device("cpu")
    model.eval()
    logits: List[np.ndarray] = []
    probs: List[np.ndarray] = []
    ys: List[np.ndarray] = []
    pids: List[np.ndarray] = []

    for batch in loader:
        moved = {k: (v.to(device) if torch.is_tensor(v) else v) for k, v in batch.items()}
        out = model(moved)
        logits.append(out["logit"].detach().cpu().numpy().reshape(-1))
        probs.append(out["prob"].detach().cpu().numpy().reshape(-1))
        ys.append(moved["y"].detach().cpu().numpy().reshape(-1))
        pids.append(moved["patient_id"].detach().cpu().numpy().reshape(-1))

    if not logits:
        empty = np.zeros(0, dtype=np.float64)
        return {
            "logit": empty,
            "prob": empty,
            "y": empty,
            "patient_id": empty.astype(np.int64),
        }
    return {
        "logit": np.concatenate(logits).astype(np.float64),
        "prob": np.concatenate(probs).astype(np.float64),
        "y": np.concatenate(ys).astype(np.float64),
        "patient_id": np.concatenate(pids).astype(np.int64),
    }


# ---------------------------------------------------------------------------
# scalar metric bundle (shared by window- and patient-level reporting)
# ---------------------------------------------------------------------------
def _discrimination_bundle(prob: np.ndarray, y: np.ndarray, threshold: float) -> Dict[str, float]:
    """AUROC / AUPRC / macro-F1 / MCC / Brier at ``threshold`` (point estimates)."""
    return {
        "auroc": auroc(prob, y),
        "auprc": auprc(prob, y),
        "macro_f1": macro_f1(prob, y, threshold=threshold),
        "mcc": mcc(prob, y, threshold=threshold),
        "brier": brier(prob, y),
    }


def _bootstrap_bundle(
    prob: np.ndarray,
    y: np.ndarray,
    patient_id: np.ndarray,
    threshold: float,
    n_boot: int,
    seed: int,
) -> Dict[str, Dict[str, float]]:
    """Patient-cluster bootstrap CIs for AUROC / AUPRC / macro-F1 / MCC / Brier.

    Each metric is wrapped as a ``(prob, y) -> float`` closure so
    :func:`~am_dimnet.metrics.bootstrap_ci` can resample **over patients**
    (respecting within-patient window correlation, SPEC Section 6).
    """
    thr = float(threshold)
    metric_fns = {
        "auroc": lambda p, t: auroc(p, t),
        "auprc": lambda p, t: auprc(p, t),
        "macro_f1": lambda p, t: macro_f1(p, t, threshold=thr),
        "mcc": lambda p, t: mcc(p, t, threshold=thr),
        "brier": lambda p, t: brier(p, t),
    }
    out: Dict[str, Dict[str, float]] = {}
    for name, fn in metric_fns.items():
        out[name] = bootstrap_ci(fn, prob, y, patient_id, n=n_boot, seed=seed)
    return out


# ---------------------------------------------------------------------------
# helpers to make results JSON-serialisable
# ---------------------------------------------------------------------------
def _to_jsonable(obj: Any) -> Any:
    """Recursively convert numpy scalars/arrays to plain Python for JSON/CSV."""
    if isinstance(obj, dict):
        return {str(k): _to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return [_to_jsonable(v) for v in obj.tolist()]
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, float):
        # Keep NaN/inf representable in JSON via allow_nan (json handles them).
        return obj
    return obj


def _median_windows_per_patient(patient_id: np.ndarray) -> Optional[int]:
    """Median number of windows per patient (for the alarm-rate normalisation)."""
    if patient_id.size == 0:
        return None
    _uids, counts = np.unique(patient_id, return_counts=True)
    return int(np.median(counts))


# ---------------------------------------------------------------------------
# main evaluation entry point
# ---------------------------------------------------------------------------
def evaluate_model(
    model: AMDiMNet,
    loader: DataLoader,
    val_loader: Optional[DataLoader] = None,
    device: Optional[torch.device] = None,
    threshold_target: Any = "youden",
    n_bootstrap: int = 1000,
    seed: int = 0,
    step_s: float = 60.0,
    gap_h: float = 1.5,
    horizon_h: float = 24.0,
    dca_thresholds: Optional[List[float]] = None,
) -> Dict[str, Any]:
    """Compute the full AM-DiMNet metric suite on ``loader`` (SPEC Section 7).

    Parameters
    ----------
    model : AMDiMNet
        Trained model (weights already loaded). Set to ``eval`` internally.
    loader : DataLoader
        The evaluation (test) loader following the batch contract.
    val_loader : DataLoader, optional
        Validation loader used to (a) fit temperature scaling and (b) select the
        operating threshold. If ``None``, the *test* split is used for both,
        which is optimistic and only appropriate for the smoke test.
    device : torch.device, optional
        Defaults to CPU.
    threshold_target : {"youden", "f1"} or float
        Passed to :func:`~am_dimnet.calibrate.select_operating_threshold`; a
        float is treated as a sensitivity floor.
    n_bootstrap : int
        Patient-cluster bootstrap replicates for the patient-level CIs.
    seed : int
        Bootstrap RNG seed.
    step_s, gap_h, horizon_h : float
        Windowing constants forwarded to the operating-point / alarm metrics
        (SPEC ``data.step_s`` / ``data.gap_h`` / ``data.horizon_h``).
    dca_thresholds : list of float, optional
        Threshold-probability grid for decision-curve analysis (default
        ``0.02 .. 0.50`` in 25 steps, the clinically relevant low-threshold
        range for a high-consequence alert).

    Returns
    -------
    dict
        A nested, JSON-serialisable results dict with top-level keys::

            "n_windows", "n_patients", "prevalence_window", "prevalence_patient",
            "temperature", "operating_threshold", "threshold_target",
            "window": {... discrimination + operating_point ...},
            "patient": {... discrimination + bootstrap_ci ...},
            "calibration": {"ece_15", "brier", "reliability": {...}},
            "decision_curve": {...}
    """
    device = device or torch.device("cpu")

    # --- inference on test (+ val for calibration/threshold) --------------
    test = collect_logits(model, loader, device=device)
    if test["logit"].size == 0:
        raise ValueError("evaluation loader produced no samples")

    if val_loader is not None and len(getattr(val_loader, "dataset", [])) > 0:
        val = collect_logits(model, val_loader, device=device)
    else:
        val = test  # fall back to test (optimistic; smoke-test only)

    # --- post-hoc calibration: temperature scaling on validation logits ----
    # TemperatureScaler is monotone (preserves ranking / AUROC) and only fixes
    # confidence; it is fit on the validation split and applied frozen to test.
    prob_test_uncal = test["prob"]
    if len(np.unique(val["y"])) >= 2:
        scaler = TemperatureScaler().fit(val["logit"], val["y"])
        temperature = float(scaler.temperature)
        prob_test = scaler.transform(test["logit"])
        prob_val = scaler.transform(val["logit"])
    else:
        # Degenerate single-class validation: skip calibration (T = 1).
        temperature = 1.0
        prob_test = prob_test_uncal
        prob_val = val["prob"]

    y_test = test["y"]
    pid_test = test["patient_id"]

    # --- operating threshold selected on validation ------------------------
    if len(np.unique(val["y"])) >= 2:
        threshold = float(select_operating_threshold(prob_val, val["y"], target=threshold_target))
    else:
        threshold = 0.5

    # ================= WINDOW-LEVEL =======================================
    window_disc = _discrimination_bundle(prob_test, y_test, threshold)
    wpp = _median_windows_per_patient(pid_test)
    op = operating_point_stats(
        prob_test,
        y_test,
        threshold=threshold,
        windows_per_patient=wpp,
        step_s=step_s,
        horizon_h=horizon_h,
        gap_h=gap_h,
    )
    window_block: Dict[str, Any] = {
        "discrimination": window_disc,
        "operating_point": op,
        "n": int(prob_test.size),
        "prevalence": float(np.mean(y_test)) if y_test.size else float("nan"),
    }

    # ================= PATIENT-LEVEL (primary, Eq. 30) =====================
    # Aggregate window probabilities -> one risk score per patient (top-decile
    # mean) and patient label = max over windows.
    y_hat_pt, uids, y_true_pt = patient_top_decile(prob_test, pid_test, y=y_test)

    # Patient-level operating threshold (re-selected on the val patient scores).
    if val is not test and len(np.unique(val["y"])) >= 2:
        yv_hat, _uv, yv_true = patient_top_decile(prob_val, val["patient_id"], y=val["y"])
        if len(np.unique(yv_true)) >= 2:
            pt_threshold = float(select_operating_threshold(yv_hat, yv_true, target=threshold_target))
        else:
            pt_threshold = threshold
    else:
        pt_threshold = threshold

    patient_disc = _discrimination_bundle(y_hat_pt, y_true_pt, pt_threshold)
    patient_boot = _bootstrap_bundle(
        prob_test,
        y_test,
        pid_test,
        threshold=threshold,
        n_boot=int(n_bootstrap),
        seed=int(seed),
    )
    # Patient-level AUROC/AUPRC bootstrap: resample patients, aggregate, score.
    patient_boot_agg = _patient_level_bootstrap(
        prob_test, y_test, pid_test, n_boot=int(n_bootstrap), seed=int(seed)
    )
    patient_block: Dict[str, Any] = {
        "discrimination": patient_disc,
        "operating_threshold": pt_threshold,
        "n_patients": int(uids.size),
        "prevalence": float(np.mean(y_true_pt)) if y_true_pt.size else float("nan"),
        # Window-level metric CIs, resampled over patient clusters.
        "bootstrap_ci_window_metrics": patient_boot,
        # Patient-level (aggregated) metric CIs.
        "bootstrap_ci_patient_metrics": patient_boot_agg,
    }

    # ================= CALIBRATION (Eq. 35) ================================
    calibration_block: Dict[str, Any] = {
        "temperature": temperature,
        "ece_15": expected_calibration_error(prob_test, y_test, n_bins=15),
        "ece_15_uncalibrated": expected_calibration_error(prob_test_uncal, y_test, n_bins=15),
        "brier": brier(prob_test, y_test),
        "brier_uncalibrated": brier(prob_test_uncal, y_test),
        "reliability": reliability_curve(prob_test, y_test, n_bins=15),
    }

    # ================= DECISION CURVE ======================================
    if dca_thresholds is None:
        dca_thresholds = list(np.linspace(0.02, 0.50, 25))
    dca = decision_curve(prob_test, y_test, thresholds=dca_thresholds)

    results: Dict[str, Any] = {
        "n_windows": int(prob_test.size),
        "n_patients": int(uids.size),
        "prevalence_window": float(np.mean(y_test)) if y_test.size else float("nan"),
        "prevalence_patient": float(np.mean(y_true_pt)) if y_true_pt.size else float("nan"),
        "temperature": temperature,
        "operating_threshold": threshold,
        "threshold_target": str(threshold_target),
        "window": window_block,
        "patient": patient_block,
        "calibration": calibration_block,
        "decision_curve": dca,
    }
    return _to_jsonable(results)


def _patient_level_bootstrap(
    prob: np.ndarray,
    y: np.ndarray,
    patient_id: np.ndarray,
    n_boot: int,
    seed: int,
    alpha: float = 0.05,
) -> Dict[str, Dict[str, float]]:
    """Patient-cluster bootstrap CIs for *patient-level* AUROC / AUPRC (Eq. 30).

    Each replicate draws patients with replacement, re-aggregates their windows
    with the top-decile rule (:func:`patient_top_decile`), and scores AUROC /
    AUPRC over the resampled patient set. Because aggregation is intrinsically
    patient-wise, we resample the patient index directly here rather than through
    :func:`~am_dimnet.metrics.bootstrap_ci` (which operates on window arrays).
    """
    uids = np.unique(patient_id)
    groups = {int(u): np.where(patient_id == u)[0] for u in uids}
    n_patients = uids.size
    rng = np.random.default_rng(seed)

    # Point estimates on the full sample.
    y_hat, _u, y_true = patient_top_decile(prob, patient_id, y=y)
    point = {"auroc": auroc(y_hat, y_true), "auprc": auprc(y_hat, y_true)}

    boot: Dict[str, List[float]] = {"auroc": [], "auprc": []}
    for _ in range(int(n_boot)):
        drawn = rng.choice(uids, size=n_patients, replace=True)
        # Aggregate each drawn patient independently (duplicates allowed).
        yh = []
        yt = []
        for u in drawn:
            g = groups[int(u)]
            vals = np.sort(prob[g])[::-1]
            k = max(1, int(np.ceil(0.10 * vals.shape[0])))
            yh.append(float(vals[:k].mean()))
            yt.append(float(y[g].max()))
        yh_arr = np.asarray(yh, dtype=np.float64)
        yt_arr = np.asarray(yt, dtype=np.float64)
        a = auroc(yh_arr, yt_arr)
        p = auprc(yh_arr, yt_arr)
        if np.isfinite(a):
            boot["auroc"].append(a)
        if np.isfinite(p):
            boot["auprc"].append(p)

    out: Dict[str, Dict[str, float]] = {}
    for name in ("auroc", "auprc"):
        arr = np.asarray(boot[name], dtype=np.float64)
        if arr.size == 0:
            out[name] = {
                "point": point[name],
                "mean": float("nan"),
                "lower": float("nan"),
                "upper": float("nan"),
                "se": float("nan"),
                "n_valid": 0.0,
            }
            continue
        out[name] = {
            "point": point[name],
            "mean": float(arr.mean()),
            "lower": float(np.percentile(arr, 100.0 * (alpha / 2.0))),
            "upper": float(np.percentile(arr, 100.0 * (1.0 - alpha / 2.0))),
            "se": float(arr.std(ddof=1)) if arr.size > 1 else 0.0,
            "n_valid": float(arr.size),
        }
    return out


# ---------------------------------------------------------------------------
# result serialisation (JSON + flat CSV)
# ---------------------------------------------------------------------------
def _flatten(prefix: str, obj: Any, rows: Dict[str, Any]) -> None:
    """Flatten a nested results dict into ``dotted.key -> scalar`` rows.

    Lists of scalars are joined with ``;`` so the whole result fits a single-row
    CSV; nested dicts recurse with dotted keys.
    """
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            _flatten(key, v, rows)
    elif isinstance(obj, (list, tuple)):
        # Join scalar lists; skip lists of dicts (kept in JSON only).
        if all(not isinstance(v, (dict, list, tuple)) for v in obj):
            rows[prefix] = ";".join(str(v) for v in obj)
    else:
        rows[prefix] = obj


def write_results(results: Dict[str, Any], out: str) -> Tuple[str, str]:
    """Write ``results`` to ``<out>/metrics.json`` and ``<out>/metrics.csv``.

    ``out`` may be a directory (files named ``metrics.{json,csv}``) or a file
    path with a ``.json`` extension (the CSV sibling shares the stem). Returns
    the ``(json_path, csv_path)`` actually written.
    """
    if out.endswith(".json"):
        json_path = out
        csv_path = out[: -len(".json")] + ".csv"
        os.makedirs(os.path.dirname(os.path.abspath(json_path)) or ".", exist_ok=True)
    else:
        os.makedirs(out, exist_ok=True)
        json_path = os.path.join(out, "metrics.json")
        csv_path = os.path.join(out, "metrics.csv")

    with open(json_path, "w", encoding="utf-8") as fh:
        json.dump(results, fh, indent=2, allow_nan=True)

    flat: Dict[str, Any] = {}
    _flatten("", results, flat)
    with open(csv_path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["metric", "value"])
        for k in sorted(flat.keys()):
            writer.writerow([k, flat[k]])

    return json_path, csv_path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m am_dimnet.evaluate",
        description=(
            "Evaluate a trained AM-DiMNet: patient-level discrimination (Eq. 30) "
            "with patient-cluster bootstrap CIs, window-level operating point, "
            "temperature calibration + ECE-15 (Eq. 35), and decision-curve "
            "analysis. Writes JSON + CSV to --out."
        ),
    )
    parser.add_argument("--config", type=str, default=None, help="YAML config (mirrors am_dimnet.config.Config).")
    parser.add_argument("--ckpt", type=str, default=None, help="Path to a checkpoint saved by am_dimnet.train (state_dict + config).")
    parser.add_argument("--out", type=str, default="results", help="Output directory or .json path for the metric suite.")
    parser.add_argument("--seed", type=int, default=None, help="Seed for the synthetic cohort + bootstrap (default: train.seeds[0]).")
    parser.add_argument("--n-patients", type=int, default=64, help="Synthetic cohort size when no external data is used.")
    parser.add_argument("--prevalence", type=float, default=0.219, help="Synthetic positive-window prevalence.")
    parser.add_argument("--n-bootstrap", type=int, default=1000, help="Patient-cluster bootstrap replicates for the CIs.")
    parser.add_argument("--threshold-target", type=str, default="youden", help="Operating-threshold target: 'youden', 'f1', or a sensitivity floor in (0,1].")
    parser.add_argument("--split", type=str, default="test", choices=["train", "val", "test"], help="Which synthetic split to evaluate on (default: test).")
    parser.add_argument("--quiet", action="store_true", help="Suppress the printed summary.")
    return parser


def _resolve_config(args: argparse.Namespace, ckpt: Optional[Dict[str, Any]]) -> Config:
    """Config precedence: --config > checkpoint's stored config > defaults."""
    if args.config:
        return Config.load(args.config)
    if ckpt is not None and "config" in ckpt:
        return Config.from_dict(ckpt["config"])
    default_yaml = os.path.join("configs", "default.yaml")
    if os.path.exists(default_yaml):
        try:
            return Config.load(default_yaml)
        except Exception:  # pragma: no cover
            pass
    return Config.default()


def _parse_threshold_target(raw: str) -> Any:
    """Interpret the CLI threshold target ('youden'/'f1' or a float floor)."""
    key = raw.strip().lower()
    if key in ("youden", "f1"):
        return key
    try:
        return float(key)
    except ValueError:
        return "youden"


def main(argv: Optional[List[str]] = None) -> int:
    """CLI entry point: ``python -m am_dimnet.evaluate --config ... --ckpt ...``."""
    args = _build_arg_parser().parse_args(argv)

    ckpt: Optional[Dict[str, Any]] = None
    if args.ckpt:
        ckpt = torch.load(args.ckpt, map_location="cpu", weights_only=False)

    config = _resolve_config(args, ckpt)
    seed = args.seed if args.seed is not None else int(config.train.seeds[0])
    device = torch.device("cpu")

    # Build the model and (optionally) load trained weights.
    model = AMDiMNet(config).to(device)
    if ckpt is not None:
        state = ckpt.get("state_dict", ckpt)
        model.load_state_dict(state)
    model.eval()
    model.adv_lambda = 1.0

    # Data: synthetic cohort by default (SPEC Section 5). Val is used for
    # calibration + threshold selection; the requested split is evaluated.
    loaders = make_loaders(
        config,
        n_patients=int(args.n_patients),
        prevalence=float(args.prevalence),
        seed=seed,
    )
    eval_loader = loaders[args.split]
    val_loader = loaders.get("val")

    results = evaluate_model(
        model,
        eval_loader,
        val_loader=val_loader,
        device=device,
        threshold_target=_parse_threshold_target(args.threshold_target),
        n_bootstrap=int(args.n_bootstrap),
        seed=int(seed),
        step_s=float(config.data.step_s),
        gap_h=float(config.data.gap_h),
        horizon_h=float(config.data.horizon_h),
    )

    json_path, csv_path = write_results(results, args.out)

    if not args.quiet:
        pt = results["patient"]["discrimination"]
        win = results["window"]["discrimination"]
        cal = results["calibration"]
        print(
            "Evaluation complete\n"
            f"  windows={results['n_windows']} patients={results['n_patients']} "
            f"prev(win)={results['prevalence_window']:.3f} prev(pt)={results['prevalence_patient']:.3f}\n"
            f"  patient  AUROC={pt['auroc']:.4f} AUPRC={pt['auprc']:.4f} "
            f"F1={pt['macro_f1']:.4f} MCC={pt['mcc']:.4f}\n"
            f"  window   AUROC={win['auroc']:.4f} AUPRC={win['auprc']:.4f}\n"
            f"  calib    T={cal['temperature']:.3f} ECE15={cal['ece_15']:.4f} "
            f"Brier={cal['brier']:.4f}\n"
            f"  threshold={results['operating_threshold']:.4f} "
            f"(target={results['threshold_target']})\n"
            f"  wrote {json_path} and {csv_path}"
        )

    return 0


if __name__ == "__main__":  # pragma: no cover - CLI entry point
    raise SystemExit(main())
