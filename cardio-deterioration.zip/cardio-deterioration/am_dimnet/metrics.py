"""Evaluation metrics for AM-DiMNet.

Implements the discrimination, calibration, operating-point, decision-curve and
patient-level aggregation metrics used to report AM-DiMNet performance.  All
public functions return plain Python floats, ``numpy.ndarray`` objects, or plain
``dict`` objects (no torch tensors) so that results are trivially serialisable to
JSON/CSV by :mod:`am_dimnet.evaluate`.

Paper cross-references (see SPEC section 6):
  * Discrimination : AUROC / AUPRC / macro-F1 / MCC / Brier (wrap scikit-learn).
  * Eq. 35        : event-frequency Expected Calibration Error (``ECE_BINS`` = 15).
  * Eq. 30        : patient-level top-decile aggregation.
  * Eq. 31        : patient-level max aggregation.
  * Operating point: sensitivity/specificity/PPV/NPV/FPR plus alarm-consolidated
                     false-alarm rate and median lead time.

Conventions
-----------
``prob`` is the predicted event probability in ``[0, 1]`` (already calibrated if
calibration is applied upstream).  ``y`` is the binary ground-truth label in
``{0, 1}``.  ``patient_id`` is an integer cluster id used for patient-disjoint
aggregation and for the patient-cluster bootstrap.
"""

from __future__ import annotations

from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    matthews_corrcoef,
    roc_auc_score,
)

# ECE bin count (SPEC section 0 / Eq. 35).  Prefer the shared constant if the
# constants module is importable, but fall back to the literal so this module is
# import-clean even when evaluated in isolation.
try:  # pragma: no cover - trivial import shim
    from .constants import ECE_BINS as _ECE_BINS
except Exception:  # pragma: no cover
    _ECE_BINS = 15
ECE_BINS = _ECE_BINS


# ---------------------------------------------------------------------------
# small internal helpers
# ---------------------------------------------------------------------------
def _as_1d_float(a: Iterable) -> np.ndarray:
    """Return ``a`` as a contiguous 1-D float64 numpy array."""
    arr = np.asarray(a, dtype=np.float64).reshape(-1)
    return arr


def _as_1d_int(a: Iterable) -> np.ndarray:
    """Return ``a`` as a contiguous 1-D int64 numpy array (labels / ids)."""
    return np.asarray(a, dtype=np.int64).reshape(-1)


def _validate_prob_y(prob: Iterable, y: Iterable) -> Tuple[np.ndarray, np.ndarray]:
    """Coerce ``prob`` and ``y`` to aligned 1-D arrays and sanity-check them."""
    p = _as_1d_float(prob)
    t = _as_1d_float(y)
    if p.shape[0] != t.shape[0]:
        raise ValueError(
            f"prob and y length mismatch: {p.shape[0]} vs {t.shape[0]}"
        )
    if p.size == 0:
        raise ValueError("empty prob/y arrays")
    return p, t


# ---------------------------------------------------------------------------
# discrimination + scalar scoring metrics (scikit-learn wrappers)
# ---------------------------------------------------------------------------
def auroc(prob: Iterable, y: Iterable) -> float:
    """Area under the ROC curve.

    Threshold-free; computed on probabilities.  Returns ``nan`` when only one
    class is present (AUROC undefined).
    """
    p, t = _validate_prob_y(prob, y)
    if len(np.unique(t)) < 2:
        return float("nan")
    return float(roc_auc_score(t, p))


def auprc(prob: Iterable, y: Iterable) -> float:
    """Area under the precision-recall curve (average precision).

    Threshold-free; the informative summary under class imbalance.  Returns
    ``nan`` when no positive is present.
    """
    p, t = _validate_prob_y(prob, y)
    if t.sum() == 0:
        return float("nan")
    return float(average_precision_score(t, p))


def macro_f1(prob: Iterable, y: Iterable, threshold: float = 0.5) -> float:
    """Macro-averaged F1 over the two classes at a fixed ``threshold``."""
    p, t = _validate_prob_y(prob, y)
    yhat = (p >= threshold).astype(np.int64)
    return float(f1_score(t.astype(np.int64), yhat, average="macro", zero_division=0))


def mcc(prob: Iterable, y: Iterable, threshold: float = 0.5) -> float:
    """Matthews correlation coefficient at a fixed ``threshold``."""
    p, t = _validate_prob_y(prob, y)
    yhat = (p >= threshold).astype(np.int64)
    return float(matthews_corrcoef(t.astype(np.int64), yhat))


def brier(prob: Iterable, y: Iterable) -> float:
    """Brier score (mean squared error between probability and label).

    Lower is better; a proper scoring rule combining calibration and refinement.
    """
    p, t = _validate_prob_y(prob, y)
    return float(brier_score_loss(t.astype(np.int64), p))


# ---------------------------------------------------------------------------
# calibration: Eq. 35 ECE + reliability curve
# ---------------------------------------------------------------------------
def expected_calibration_error(
    prob: Iterable,
    y: Iterable,
    n_bins: int = ECE_BINS,
) -> float:
    r"""Event-frequency Expected Calibration Error (Eq. 35).

    Partitions ``[0, 1]`` into ``n_bins`` equal-width bins :math:`B_m`.  With
    :math:`\mathrm{conf}(B_m)` the mean predicted risk in the bin and
    :math:`\mathrm{acc}(B_m)` the empirical event frequency (fraction of
    positives) in the bin,

    .. math::

        \mathrm{ECE} = \sum_{m=1}^{M} \frac{|B_m|}{N}
                       \, \bigl| \mathrm{acc}(B_m) - \mathrm{conf}(B_m) \bigr|.

    Empty bins contribute zero.  Returns a float in ``[0, 1]``.
    """
    p, t = _validate_prob_y(prob, y)
    n_bins = int(n_bins)
    if n_bins < 1:
        raise ValueError("n_bins must be >= 1")
    n = p.shape[0]
    # Bin edges: n_bins equal-width bins over [0, 1].
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    # Assign each probability to a bin index in [0, n_bins-1]; clip protects the
    # right edge (prob == 1.0) which np.digitize would push to n_bins.
    idx = np.clip(np.digitize(p, edges[1:-1], right=False), 0, n_bins - 1)
    ece = 0.0
    for m in range(n_bins):
        sel = idx == m
        count = int(sel.sum())
        if count == 0:
            continue
        conf = float(p[sel].mean())          # mean predicted risk in bin
        acc = float(t[sel].mean())           # empirical event frequency in bin
        ece += (count / n) * abs(acc - conf)
    return float(ece)


def reliability_curve(
    prob: Iterable,
    y: Iterable,
    n_bins: int = ECE_BINS,
) -> Dict[str, np.ndarray]:
    """Reliability-diagram data (event frequency vs mean predicted risk).

    Returns a dict with one row per *non-empty* bin::

        {
          "bin_lower":   np.ndarray,   # left edge of each bin
          "bin_upper":   np.ndarray,   # right edge of each bin
          "mean_pred":   np.ndarray,   # conf(B_m): mean predicted risk
          "event_freq":  np.ndarray,   # acc(B_m):  observed event frequency
          "count":       np.ndarray,   # |B_m|: number of samples in the bin
        }

    Companion to :func:`expected_calibration_error` (Eq. 35); consumed by the
    plotting utilities in :mod:`am_dimnet.evaluate`.
    """
    p, t = _validate_prob_y(prob, y)
    n_bins = int(n_bins)
    if n_bins < 1:
        raise ValueError("n_bins must be >= 1")
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1], right=False), 0, n_bins - 1)

    lowers: List[float] = []
    uppers: List[float] = []
    mean_pred: List[float] = []
    event_freq: List[float] = []
    counts: List[int] = []
    for m in range(n_bins):
        sel = idx == m
        count = int(sel.sum())
        if count == 0:
            continue
        lowers.append(float(edges[m]))
        uppers.append(float(edges[m + 1]))
        mean_pred.append(float(p[sel].mean()))
        event_freq.append(float(t[sel].mean()))
        counts.append(count)
    return {
        "bin_lower": np.asarray(lowers, dtype=np.float64),
        "bin_upper": np.asarray(uppers, dtype=np.float64),
        "mean_pred": np.asarray(mean_pred, dtype=np.float64),
        "event_freq": np.asarray(event_freq, dtype=np.float64),
        "count": np.asarray(counts, dtype=np.int64),
    }


# ---------------------------------------------------------------------------
# operating point: confusion-derived stats + alarm consolidation
# ---------------------------------------------------------------------------
def operating_point_stats(
    prob: Iterable,
    y: Iterable,
    threshold: float,
    windows_per_patient: Optional[int] = None,
    monitoring_hours: Optional[float] = None,
    step_s: float = 60.0,
    refractory_min: float = 30.0,
    horizon_h: float = 24.0,
    gap_h: float = 1.5,
) -> Dict[str, float]:
    """Confusion-matrix statistics at ``threshold`` plus alarm-rate metrics.

    Basic operating-point statistics (all threshold-dependent)::

        sens = TP / (TP + FN)     spec = TN / (TN + FP)
        ppv  = TP / (TP + FP)     npv  = TN / (TN + FN)
        fpr  = FP / (FP + TN)     ( = 1 - spec )

    Alarm-oriented statistics
    --------------------------
    A continuous monitor emits one prediction per sliding window (``step_s`` s
    apart, SPEC ``data.step_s``).  Reporting the raw per-window false-positive
    count would over-count a single sustained excursion, so we apply the two
    clinical de-duplication rules used in the paper's operating-point analysis:

    * **Alarm consolidation** — consecutive positive windows (in time order) are
      merged into a single *alarm episode*; only the first window of a run raises
      an audible alarm.
    * **Refractory interval** — after an alarm fires, further positive windows
      within ``refractory_min`` minutes are suppressed (silenced) and do not
      generate a new alarm.  This mimics the alarm-latch behaviour of bedside
      monitors and prevents alarm-fatigue inflation of the rate.

    ``false_alarms_per_day`` counts consolidated, refractory-gated alarms on
    *negative* windows and normalises by the total monitored duration.  The
    monitored duration is ``monitoring_hours`` when provided, otherwise it is
    inferred from ``windows_per_patient`` (or the sample count) times ``step_s``.

    ``median_lead_time_h`` is the median time from the *first* fired alarm to the
    predicted event onset, expressed in hours.  Because a positive label at a
    window means an event occurs in ``[end + gap_h, end + gap_h + horizon_h]``
    (Eq. 2-3), a window-level detection provides at least ``gap_h`` hours of
    warning; we report the conservative lower bound ``gap_h`` for the first true
    alarm of each positive episode (the earliest actionable notice).

    Parameters
    ----------
    threshold : float
        Decision threshold applied to ``prob``.
    windows_per_patient : int, optional
        If given, ``prob``/``y`` are treated as concatenated per-patient streams
        of this fixed length; alarm consolidation and refractory suppression are
        applied *within* each patient stream.  If ``None``, the whole array is
        treated as a single time-ordered stream.
    monitoring_hours : float, optional
        Total monitored duration (hours) used to normalise the false-alarm rate.
        If ``None``, it is derived from the window count and ``step_s``.
    step_s : float
        Sliding-window step in seconds (SPEC ``data.step_s``; default 60 s).
    refractory_min : float
        Refractory/silence interval in minutes after an alarm (default 30 min).
    horizon_h, gap_h : float
        Prediction horizon and gap (SPEC ``data.horizon_h`` / ``data.gap_h``);
        used to bound the reported lead time.

    Returns
    -------
    dict
        ``sens, spec, ppv, npv, fpr, false_alarms_per_day, median_lead_time_h,
        tp, fp, tn, fn, n_alarms, n_false_alarms``.
    """
    p, t = _validate_prob_y(prob, y)
    t = t.astype(np.int64)
    n = p.shape[0]
    yhat = (p >= float(threshold)).astype(np.int64)

    tp = int(np.sum((yhat == 1) & (t == 1)))
    fp = int(np.sum((yhat == 1) & (t == 0)))
    tn = int(np.sum((yhat == 0) & (t == 0)))
    fn = int(np.sum((yhat == 0) & (t == 1)))

    def _safe_div(a: float, b: float) -> float:
        return float(a / b) if b > 0 else float("nan")

    sens = _safe_div(tp, tp + fn)
    spec = _safe_div(tn, tn + fp)
    ppv = _safe_div(tp, tp + fp)
    npv = _safe_div(tn, tn + fn)
    fpr = _safe_div(fp, fp + tn)

    # --- partition the flat arrays into per-patient time-ordered streams ------
    if windows_per_patient is not None and int(windows_per_patient) > 0:
        w = int(windows_per_patient)
        starts = list(range(0, n, w))
        streams = [(s, min(s + w, n)) for s in starts]
    else:
        streams = [(0, n)]

    refractory_windows = max(1, int(round((refractory_min * 60.0) / step_s)))

    n_alarms = 0            # consolidated alarms on any window
    n_false_alarms = 0      # consolidated alarms on negative windows
    lead_times_h: List[float] = []

    for s, e in streams:
        yh = yhat[s:e]
        yy = t[s:e]
        last_alarm = -(10**9)  # index of the last fired alarm (in-stream)
        for i in range(len(yh)):
            if yh[i] != 1:
                continue
            # Alarm consolidation: skip if the immediately preceding window was
            # already positive (same sustained episode).
            if i > 0 and yh[i - 1] == 1:
                continue
            # Refractory suppression: skip if within the refractory window of the
            # last fired alarm.
            if (i - last_alarm) <= refractory_windows:
                continue
            # This window fires a real (consolidated, non-refractory) alarm.
            last_alarm = i
            n_alarms += 1
            if yy[i] == 0:
                n_false_alarms += 1
            else:
                # True alarm: conservative actionable lead time is the gap.
                lead_times_h.append(float(gap_h))

    # --- false alarms per day -------------------------------------------------
    if monitoring_hours is not None and float(monitoring_hours) > 0:
        total_hours = float(monitoring_hours)
    else:
        total_hours = (n * step_s) / 3600.0
    false_alarms_per_day = (
        float(n_false_alarms / total_hours * 24.0) if total_hours > 0 else float("nan")
    )

    median_lead_time_h = (
        float(np.median(lead_times_h)) if len(lead_times_h) > 0 else float("nan")
    )

    return {
        "sens": sens,
        "spec": spec,
        "ppv": ppv,
        "npv": npv,
        "fpr": fpr,
        "false_alarms_per_day": false_alarms_per_day,
        "median_lead_time_h": median_lead_time_h,
        "tp": float(tp),
        "fp": float(fp),
        "tn": float(tn),
        "fn": float(fn),
        "n_alarms": float(n_alarms),
        "n_false_alarms": float(n_false_alarms),
    }


# ---------------------------------------------------------------------------
# decision-curve analysis (net benefit)
# ---------------------------------------------------------------------------
def decision_curve(
    prob: Iterable,
    y: Iterable,
    thresholds: Sequence[float],
) -> Dict[str, np.ndarray]:
    r"""Decision-curve analysis: net benefit across threshold probabilities.

    For a threshold probability :math:`p_t`, treating patients whose predicted
    risk exceeds :math:`p_t` yields net benefit (Vickers & Elkin, 2006)

    .. math::

        \mathrm{NB}(p_t) = \frac{TP}{N} - \frac{FP}{N}\,\frac{p_t}{1 - p_t},

    where ``TP``/``FP`` are counted at the operating point ``prob >= p_t``.  The
    two reference strategies are

    * **treat-all** : :math:`\mathrm{NB} = \pi - (1-\pi)\,p_t/(1-p_t)`
      with prevalence :math:`\pi`;
    * **treat-none**: :math:`\mathrm{NB} = 0`.

    Returns a dict of equal-length arrays::

        {"threshold", "net_benefit", "treat_all", "treat_none"}.
    """
    p, t = _validate_prob_y(prob, y)
    t = t.astype(np.int64)
    n = p.shape[0]
    prevalence = float(t.mean())
    thr = np.asarray(thresholds, dtype=np.float64).reshape(-1)

    net_benefit = np.empty_like(thr)
    treat_all = np.empty_like(thr)
    treat_none = np.zeros_like(thr)
    for k, pt in enumerate(thr):
        # Guard the odds factor at pt -> 1 (division by zero).
        if pt >= 1.0:
            net_benefit[k] = float("nan")
            treat_all[k] = float("nan")
            continue
        odds = pt / (1.0 - pt) if (1.0 - pt) > 0 else np.inf
        yhat = (p >= pt).astype(np.int64)
        tp = float(np.sum((yhat == 1) & (t == 1)))
        fp = float(np.sum((yhat == 1) & (t == 0)))
        net_benefit[k] = tp / n - fp / n * odds
        treat_all[k] = prevalence - (1.0 - prevalence) * odds
    return {
        "threshold": thr,
        "net_benefit": net_benefit,
        "treat_all": treat_all,
        "treat_none": treat_none,
    }


# ---------------------------------------------------------------------------
# patient-level aggregation (Eq. 30 / Eq. 31)
# ---------------------------------------------------------------------------
def _grouped_by_patient(
    prob: np.ndarray, patient_id: np.ndarray
) -> Tuple[np.ndarray, List[np.ndarray]]:
    """Return unique patient ids and the per-patient index groups (sorted)."""
    uids = np.unique(patient_id)
    groups = [np.where(patient_id == pid)[0] for pid in uids]
    return uids, groups


def patient_top_decile(
    prob: Iterable,
    patient_id: Iterable,
    y: Optional[Iterable] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    r"""Patient-level top-decile risk aggregation (Eq. 30).

    Each patient's risk score is the mean of that patient's *top-decile*
    (highest 10 %) window probabilities:

    .. math::

        \hat{Y}_i = \frac{1}{|\mathcal{T}_i|}
                    \sum_{w \in \mathcal{T}_i} \hat{p}_{i,w},
        \qquad
        \mathcal{T}_i = \text{top-}10\%\ \text{windows of patient } i.

    The top-decile set contains ``ceil(0.10 * n_i)`` windows (at least one) so
    that a single-window patient is well defined.  This suppresses transient
    single-window noise while remaining sensitive to sustained elevation.

    Parameters
    ----------
    prob : array
        Per-window probabilities.
    patient_id : array
        Per-window patient cluster id (same length as ``prob``).
    y : array, optional
        Per-window labels.  When provided, a patient-level label
        (``max`` over the patient's windows) is also returned.

    Returns
    -------
    (Y_hat, pid) or (Y_hat, pid, Y_true)
        ``Y_hat`` : aggregated risk per patient, ordered by ascending ``pid``.
        ``pid``   : the corresponding unique patient ids.
        ``Y_true``: patient-level labels (only when ``y`` is given).
    """
    p = _as_1d_float(prob)
    ids = _as_1d_int(patient_id)
    if p.shape[0] != ids.shape[0]:
        raise ValueError("prob and patient_id length mismatch")
    uids, groups = _grouped_by_patient(p, ids)

    y_hat = np.empty(len(uids), dtype=np.float64)
    for j, g in enumerate(groups):
        vals = np.sort(p[g])[::-1]  # descending
        k = int(np.ceil(0.10 * vals.shape[0]))
        k = max(1, k)
        y_hat[j] = float(vals[:k].mean())

    if y is None:
        return y_hat, uids

    t = _as_1d_float(y)
    if t.shape[0] != p.shape[0]:
        raise ValueError("prob and y length mismatch")
    y_true = np.asarray(
        [float(t[g].max()) for g in groups], dtype=np.float64
    )
    return y_hat, uids, y_true


def patient_max(
    prob: Iterable,
    patient_id: Iterable,
    y: Optional[Iterable] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    r"""Patient-level max risk aggregation (Eq. 31).

    Each patient's risk is the maximum window probability observed:

    .. math::

        \hat{Y}_i = \max_{w} \hat{p}_{i,w}.

    The most sensitive aggregation (any single high-risk window flags the
    patient); complements :func:`patient_top_decile`.

    Returns ``(Y_hat, pid)`` or ``(Y_hat, pid, Y_true)`` as in
    :func:`patient_top_decile`.
    """
    p = _as_1d_float(prob)
    ids = _as_1d_int(patient_id)
    if p.shape[0] != ids.shape[0]:
        raise ValueError("prob and patient_id length mismatch")
    uids, groups = _grouped_by_patient(p, ids)

    y_hat = np.asarray([float(p[g].max()) for g in groups], dtype=np.float64)

    if y is None:
        return y_hat, uids

    t = _as_1d_float(y)
    if t.shape[0] != p.shape[0]:
        raise ValueError("prob and y length mismatch")
    y_true = np.asarray([float(t[g].max()) for g in groups], dtype=np.float64)
    return y_hat, uids, y_true


# ---------------------------------------------------------------------------
# patient-cluster bootstrap confidence interval
# ---------------------------------------------------------------------------
def bootstrap_ci(
    metric_fn: Callable[[np.ndarray, np.ndarray], float],
    prob: Iterable,
    y: Iterable,
    patient_id: Iterable,
    n: int = 1000,
    seed: int = 0,
    alpha: float = 0.05,
) -> Dict[str, float]:
    """Patient-cluster bootstrap confidence interval for ``metric_fn``.

    Resampling is performed over **patients**, not windows: on each replicate we
    draw ``n_patients`` patient ids with replacement and concatenate *all*
    windows belonging to the drawn patients.  This respects the within-patient
    correlation of sliding windows and yields honest (wider) intervals than a
    naive window-level bootstrap.

    ``metric_fn`` must accept ``(prob, y)`` arrays and return a scalar (e.g.
    :func:`auroc`, :func:`auprc`, or a lambda wrapping a patient-level
    aggregation).  Replicates that raise or return a non-finite value (e.g. a
    single-class resample for AUROC) are discarded.

    Returns
    -------
    dict
        ``{"point": <metric on full data>, "mean": <bootstrap mean>,
           "lower": <alpha/2 percentile>, "upper": <1-alpha/2 percentile>,
           "se": <bootstrap std>, "n_valid": <#usable replicates>}``.
    """
    p = _as_1d_float(prob)
    t = _as_1d_float(y)
    ids = _as_1d_int(patient_id)
    if not (p.shape[0] == t.shape[0] == ids.shape[0]):
        raise ValueError("prob, y and patient_id must have equal length")

    # Point estimate on the full sample.
    try:
        point = float(metric_fn(p, t))
    except Exception:
        point = float("nan")

    uids, groups = _grouped_by_patient(p, ids)
    group_map = {int(u): g for u, g in zip(uids, groups)}
    n_patients = len(uids)
    rng = np.random.default_rng(seed)

    stats: List[float] = []
    for _ in range(int(n)):
        drawn = rng.choice(uids, size=n_patients, replace=True)
        idx = np.concatenate([group_map[int(u)] for u in drawn])
        try:
            val = float(metric_fn(p[idx], t[idx]))
        except Exception:
            continue
        if np.isfinite(val):
            stats.append(val)

    if len(stats) == 0:
        return {
            "point": point,
            "mean": float("nan"),
            "lower": float("nan"),
            "upper": float("nan"),
            "se": float("nan"),
            "n_valid": 0.0,
        }
    arr = np.asarray(stats, dtype=np.float64)
    lo = float(np.percentile(arr, 100.0 * (alpha / 2.0)))
    hi = float(np.percentile(arr, 100.0 * (1.0 - alpha / 2.0)))
    return {
        "point": point,
        "mean": float(arr.mean()),
        "lower": lo,
        "upper": hi,
        "se": float(arr.std(ddof=1)) if arr.shape[0] > 1 else 0.0,
        "n_valid": float(arr.shape[0]),
    }


__all__ = [
    "auroc",
    "auprc",
    "macro_f1",
    "mcc",
    "brier",
    "expected_calibration_error",
    "reliability_curve",
    "operating_point_stats",
    "decision_curve",
    "patient_top_decile",
    "patient_max",
    "bootstrap_ci",
    "ECE_BINS",
]
