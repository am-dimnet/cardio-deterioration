"""AM-DiMNet model primitives (SPEC Section 3).

Re-exports the building blocks plus the assembled network and multi-task loss
so callers can do ``from am_dimnet.models import AMDiMNet, AMDiMNetLoss, ...``.
"""

from __future__ import annotations

from .encoders import ECGEncoder, PPGEncoder, PCGEncoder, VectorEncoder
from .fusion import QualityAwareGatedFusion
from .factorization import StructuredFactorization
from .heads import (
    RiskHead,
    HRVReconstructor,
    MorphReconstructor,
    ActivityHead,
    AdversaryHead,
    GradientReversal,
    grad_reverse,
)
from .am_dimnet import AMDiMNet
from .losses import AMDiMNetLoss

__all__ = [
    # encoders (Eq. 12-13)
    "ECGEncoder",
    "PPGEncoder",
    "PCGEncoder",
    "VectorEncoder",
    # fusion (Eq. 14-15)
    "QualityAwareGatedFusion",
    # factorization (Eq. 16)
    "StructuredFactorization",
    # heads (Eq. 17, 18, 20, 22, 23)
    "RiskHead",
    "HRVReconstructor",
    "MorphReconstructor",
    "ActivityHead",
    "AdversaryHead",
    "GradientReversal",
    "grad_reverse",
    # assembled network (Eq. 12-23) + multi-task loss (Eq. 19-28)
    "AMDiMNet",
    "AMDiMNetLoss",
]
