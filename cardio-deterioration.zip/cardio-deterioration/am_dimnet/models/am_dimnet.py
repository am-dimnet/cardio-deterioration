"""AM-DiMNet full model assembly (SPEC Section 3).

Assembles the complete HRV-anchored autonomic-morphological structured
factorization network from the primitive modules:

    per-modality encoders  (Eq. 12-13, ``encoders.py``)
        -> quality-aware gated fusion  (Eq. 14-15, ``fusion.py``)
        -> structured factorization    (Eq. 16, ``factorization.py``)
        -> task / anchoring / adversarial heads (Eq. 17-23, ``heads.py``)

The forward pass consumes a batch dict following the SPEC Section 2 contract and
returns the output dict specified in SPEC Section 3:

    logit, prob, fused, alpha, z,
    recon_hrv, recon_morph, act_logits,
    adv_auto_logits, adv_morph_logits

Adversarial heads receive their input through ``grad_reverse(z, self.adv_lambda)``
so that minimizing the adversary loss (Eq. 23) makes ``z_auto`` / ``z_morph``
activity-invariant. ``adv_lambda`` is a settable attribute (GRL warmup schedule,
default 1.0). The PCG branch is optional: if its availability mask column is
all-zero across the batch the encoder is skipped and it contributes ``v=0`` to
fusion (masked out anyway, Eq. 14).
"""

from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn

from ..config import Config
from ..constants import MODALITIES, WAVEFORM_MODS
from .encoders import ECGEncoder, PCGEncoder, PPGEncoder, VectorEncoder
from .fusion import QualityAwareGatedFusion
from .factorization import StructuredFactorization
from .heads import (
    ActivityHead,
    AdversaryHead,
    HRVReconstructor,
    MorphReconstructor,
    RiskHead,
    grad_reverse,
)

__all__ = ["AMDiMNet"]


def _mask_index(mod: str) -> int:
    """Column index of ``mod`` in the ordered ``MODALITIES`` set (Eq. 11)."""
    return MODALITIES.index(mod)


class AMDiMNet(nn.Module):
    """AM-DiMNet: end-to-end multimodal cardiovascular-deterioration model.

    Builds one encoder per modality in ``MODALITIES`` (waveform CNNs for
    ECG/PPG, a 2-D CNN for PCG, MLP encoders for proxy/HRV/clinical), the
    quality-aware gated fusion (Eq. 14-15), the five-factor structured
    factorization (Eq. 16), and every task/anchoring/adversarial head
    (Eq. 17-23).

    Args:
        config: fully-populated :class:`~am_dimnet.config.Config`.

    Attributes:
        adv_lambda: gradient-reversal strength for the adversarial heads
            (Eq. 23), settable by the trainer for GRL warmup; default 1.0.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        self.config = config

        m = config.model
        d = config.data
        embed_dim = m.embed_dim
        latent_dim = m.latent_dim
        dropout = m.dropout

        self.embed_dim = embed_dim
        self.latent_dim = latent_dim
        self.morph_dim = d.morph_dim

        # -- Per-modality encoders (Eq. 12-13) -----------------------------
        self.ecg_encoder = ECGEncoder(embed_dim, dropout)
        self.ppg_encoder = PPGEncoder(embed_dim, dropout)
        self.pcg_encoder = PCGEncoder(embed_dim, dropout)
        self.proxy_encoder = VectorEncoder(4, embed_dim, dropout)  # proxy: 4-dim (Eq. 7)
        self.hrv_encoder = VectorEncoder(10, embed_dim, dropout)   # HRV: 10-dim (Eq. 5)
        self.clinical_encoder = VectorEncoder(d.clinical_dim, embed_dim, dropout)

        # -- Quality-aware gated fusion (Eq. 14-15) ------------------------
        self.fusion = QualityAwareGatedFusion(embed_dim, eps=m.gate_eps)

        # -- Structured factorization (Eq. 16) -----------------------------
        self.factorization = StructuredFactorization(embed_dim, latent_dim, dropout)

        # -- Heads ---------------------------------------------------------
        self.risk_head = RiskHead(latent_dim, dropout)                     # Eq. 17
        self.hrv_reconstructor = HRVReconstructor(latent_dim, n_hrv=10)    # Eq. 18
        self.morph_reconstructor = MorphReconstructor(latent_dim, d.morph_dim)  # Eq. 20
        self.activity_head = ActivityHead(latent_dim, n_classes=3)        # Eq. 22
        self.adv_auto = AdversaryHead(latent_dim, n_classes=3)            # Eq. 23 (z_auto)
        self.adv_morph = AdversaryHead(latent_dim, n_classes=3)          # Eq. 23 (z_morph)

        # Gradient-reversal strength (GRL warmup schedule; Eq. 23). Stored as a
        # plain Python attribute so the trainer can update it between epochs.
        self.adv_lambda: float = 1.0

    # ----------------------------------------------------------------------
    # Encoding
    # ----------------------------------------------------------------------
    def _encode(self, batch: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Encode every modality to its projected embedding v_r (Eq. 12-13).

        Returns a dict keyed by ``MODALITIES`` giving ``[B, embed_dim]`` per
        modality. Waveform encoders receive the batch waveform tensors; vector
        encoders receive proxy/HRV/clinical vectors. The optional PCG branch is
        skipped (contributing a zero embedding) when its mask column is all-zero
        across the batch, avoiding a wasted 2-D conv pass.
        """
        # Batch geometry from an always-present waveform modality.
        ref = batch[WAVEFORM_MODS[0]]
        b = ref.shape[0]
        device, dtype = ref.device, ref.dtype

        v: Dict[str, torch.Tensor] = {}
        v["ecg"] = self.ecg_encoder(batch["ecg"])
        v["ppg"] = self.ppg_encoder(batch["ppg"])
        v["proxy"] = self.proxy_encoder(batch["proxy"])
        v["hrv"] = self.hrv_encoder(batch["hrv"])
        v["clinical"] = self.clinical_encoder(batch["clinical"])

        # Optional PCG branch (Eq. 12-13, SPEC Section 3): skip if unavailable.
        pcg_present = False
        mask = batch.get("mask")
        if "pcg" in batch and batch["pcg"] is not None:
            if mask is not None:
                col = _mask_index("pcg")
                pcg_present = bool(mask[:, col].any().item())
            else:  # no mask supplied -> assume the provided tensor is real
                pcg_present = True

        if pcg_present:
            v["pcg"] = self.pcg_encoder(batch["pcg"])
        else:
            # Contribute a zero embedding; fusion masks it out (Eq. 14).
            v["pcg"] = torch.zeros(b, self.embed_dim, device=device, dtype=dtype)

        return v

    # ----------------------------------------------------------------------
    # Forward
    # ----------------------------------------------------------------------
    def forward(self, batch: Dict[str, torch.Tensor]) -> Dict[str, object]:
        """Run the full AM-DiMNet forward pass on a batch (SPEC Section 3).

        Args:
            batch: dict following the SPEC Section 2 contract; must provide
                ``ecg, ppg, proxy, hrv, clinical, sqi, mask`` (``pcg`` optional).

        Returns:
            out: dict with keys

                ``logit`` [B], ``prob`` [B], ``fused`` [B, embed_dim],
                ``alpha`` dict{mod:[B]}, ``z`` dict{factor:[B, latent_dim]},
                ``recon_hrv`` [B, 10], ``recon_morph`` [B, morph_dim],
                ``act_logits`` [B, 3], ``adv_auto_logits`` [B, 3],
                ``adv_morph_logits`` [B, 3].
        """
        sqi = batch["sqi"]
        mask = batch["mask"]

        # 1) Per-modality embeddings v_r (Eq. 12-13).
        v = self._encode(batch)

        # 2) Quality-aware gated fusion -> h, alpha (Eq. 14-15).
        fused, alpha = self.fusion(v, sqi, mask)

        # 3) Structured factorization -> five latent factors (Eq. 16).
        z = self.factorization(fused)

        # 4) Risk head over [z_auto; z_morph; z_base] (Eq. 17).
        logit = self.risk_head(z["auto"], z["morph"], z["base"])
        prob = torch.sigmoid(logit)

        # 5) Anchoring reconstructions (Eq. 18, Eq. 20).
        recon_hrv = self.hrv_reconstructor(z["auto"])       # [B, 10]
        recon_morph = self.morph_reconstructor(z["morph"])  # [B, morph_dim]

        # 6) Activity anchoring on z_act (Eq. 22).
        act_logits = self.activity_head(z["act"])           # [B, 3]

        # 7) Adversarial deconfounding on z_auto / z_morph through the GRL
        #    (Eq. 23). Forward is identity; backward negates+scales the gradient
        #    by ``adv_lambda`` so the risk-related factors become
        #    activity-invariant while the discriminators still train.
        adv_auto_logits = self.adv_auto(grad_reverse(z["auto"], self.adv_lambda))
        adv_morph_logits = self.adv_morph(grad_reverse(z["morph"], self.adv_lambda))

        return {
            "logit": logit,
            "prob": prob,
            "fused": fused,
            "alpha": alpha,
            "z": z,
            "recon_hrv": recon_hrv,
            "recon_morph": recon_morph,
            "act_logits": act_logits,
            "adv_auto_logits": adv_auto_logits,
            "adv_morph_logits": adv_morph_logits,
        }
