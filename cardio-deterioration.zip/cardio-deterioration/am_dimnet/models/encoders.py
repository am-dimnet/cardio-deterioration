"""Modality-specific encoders (SPEC Section 3, Eq. 12-13).

Each encoder maps a raw modality input to an intermediate representation
``u_r = E_r(X_r)`` (Eq. 12) and then applies a linear projection into the
shared embedding space ``v_r = W_r u_r + b_r`` (Eq. 13). Both stages are folded
into a single ``nn.Module`` so every encoder outputs the projected
representation ``v_r`` directly at ``embed_dim``.

Encoders:
    * ``ECGEncoder`` / ``PPGEncoder`` -- 1-D CNN over waveforms  [B,1,L]  -> [B,E]
    * ``PCGEncoder``                  -- 2-D CNN over log-Mel     [B,1,M,T]-> [B,E]
    * ``VectorEncoder``               -- MLP over feature vectors [B,in]  -> [B,E]

Conv stacks are kept modest (three blocks, <=128 channels) so a CPU forward on
batch sizes up to 96 stays fast, matching the reproducibility goal in SPEC S9.
"""

from __future__ import annotations

import torch
import torch.nn as nn

__all__ = ["ECGEncoder", "PPGEncoder", "PCGEncoder", "VectorEncoder"]


# --------------------------------------------------------------------------
# 1-D waveform encoders (ECG, PPG)
# --------------------------------------------------------------------------
class _Conv1dBlock(nn.Module):
    """Conv1d -> BatchNorm -> GELU -> MaxPool(2) block."""

    def __init__(self, in_ch: int, out_ch: int, kernel_size: int = 7) -> None:
        super().__init__()
        padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=kernel_size, padding=padding, bias=False),
            nn.BatchNorm1d(out_ch),
            nn.GELU(),
            nn.MaxPool1d(kernel_size=2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class _Waveform1DEncoder(nn.Module):
    """Shared 1-D CNN backbone for waveform modalities (Eq. 12-13).

    Three convolutional blocks (32 -> 64 -> 128 channels) followed by global
    average pooling produce ``u_r``; a final linear layer implements the shared
    projection ``v_r = W_r u_r + b_r`` (Eq. 13).

    forward: ``[B, 1, L] -> [B, embed_dim]``.
    """

    def __init__(self, embed_dim: int, dropout: float) -> None:
        super().__init__()
        self.features = nn.Sequential(
            _Conv1dBlock(1, 32, kernel_size=7),
            _Conv1dBlock(32, 64, kernel_size=7),
            _Conv1dBlock(64, 128, kernel_size=5),
        )
        self.pool = nn.AdaptiveAvgPool1d(1)   # global average pool -> u_r
        self.dropout = nn.Dropout(dropout)
        self.project = nn.Linear(128, embed_dim)  # v_r = W_r u_r + b_r (Eq. 13)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 3:
            raise ValueError(f"expected [B,1,L] waveform input, got shape {tuple(x.shape)}")
        h = self.features(x)             # [B, 128, L']
        h = self.pool(h).squeeze(-1)     # [B, 128]  (u_r)
        h = self.dropout(h)
        return self.project(h)           # [B, embed_dim]  (v_r)


class ECGEncoder(_Waveform1DEncoder):
    """ECG waveform encoder (1-D CNN); learns electrical morphology and rhythm.

    forward: ``[B, 1, ecg_len] -> [B, embed_dim]`` (Eq. 12-13).
    """


class PPGEncoder(_Waveform1DEncoder):
    """PPG waveform encoder (1-D CNN); learns pulse morphology / hemodynamics.

    forward: ``[B, 1, ppg_len] -> [B, embed_dim]`` (Eq. 12-13).
    """


# --------------------------------------------------------------------------
# 2-D spectrogram encoder (PCG, optional branch)
# --------------------------------------------------------------------------
class _Conv2dBlock(nn.Module):
    """Conv2d -> BatchNorm -> GELU -> MaxPool(2) block."""

    def __init__(self, in_ch: int, out_ch: int, kernel_size: int = 3) -> None:
        super().__init__()
        padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=kernel_size, padding=padding, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.GELU(),
            nn.MaxPool2d(kernel_size=2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class PCGEncoder(nn.Module):
    """PCG log-Mel spectrogram encoder (2-D CNN); optional branch (Eq. 12-13).

    Three 2-D conv blocks (16 -> 32 -> 64 channels) with global average pooling
    produce ``u_r``, followed by the shared projection ``v_r`` (Eq. 13). When
    PCG is unavailable the caller supplies a zero-filled tensor / zero mask and
    the contribution is masked out at fusion (Eq. 14).

    forward: ``[B, 1, pcg_mels, pcg_frames] -> [B, embed_dim]``.
    """

    def __init__(self, embed_dim: int, dropout: float) -> None:
        super().__init__()
        self.features = nn.Sequential(
            _Conv2dBlock(1, 16, kernel_size=3),
            _Conv2dBlock(16, 32, kernel_size=3),
            _Conv2dBlock(32, 64, kernel_size=3),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)     # global average pool -> u_r
        self.dropout = nn.Dropout(dropout)
        self.project = nn.Linear(64, embed_dim)  # v_r = W_r u_r + b_r (Eq. 13)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 4:
            raise ValueError(
                f"expected [B,1,M,T] spectrogram input, got shape {tuple(x.shape)}"
            )
        h = self.features(x)              # [B, 64, M', T']
        h = self.pool(h).flatten(1)       # [B, 64]  (u_r)
        h = self.dropout(h)
        return self.project(h)            # [B, embed_dim]  (v_r)


# --------------------------------------------------------------------------
# Tabular / feature-vector encoder (proxy, HRV, clinical)
# --------------------------------------------------------------------------
class VectorEncoder(nn.Module):
    """MLP encoder for feature-vector modalities (proxy, HRV, clinical).

    Two hidden layers map ``X_r in R^{in_dim}`` to the intermediate ``u_r``,
    with a final linear projection to the shared embedding ``v_r`` (Eq. 12-13).
    Used with ``in_dim`` = 4 (proxy, Eq. 7), 10 (HRV, Eq. 5), or ``clinical_dim``.

    forward: ``[B, in_dim] -> [B, embed_dim]``.
    """

    def __init__(self, in_dim: int, embed_dim: int, dropout: float) -> None:
        super().__init__()
        hidden = max(embed_dim, 2 * in_dim)
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, embed_dim),  # v_r = W_r u_r + b_r (Eq. 13)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 2:
            raise ValueError(f"expected [B, in_dim] vector input, got shape {tuple(x.shape)}")
        return self.net(x)                 # [B, embed_dim]  (v_r)
