"""Autonomic-morphological structured factorization (SPEC Section 3, Eq. 16).

Maps the fused representation ``h`` into five physiologically motivated latent
factors via independent MLP heads ``G_p`` (Eq. 16):

    z_auto  = G_auto(h)    # autonomic regulation (HRV / beat-to-beat variability)
    z_morph = G_morph(h)   # cardiovascular morphology (ECG/PPG; PCG optional)
    z_act   = G_act(h)     # activity-related confounding
    z_base  = G_base(h)    # patient-specific baseline variation
    z_noise = G_noise(h)   # signal quality / acquisition artifacts

Only ``auto``, ``morph``, ``base`` feed the risk head (Eq. 17); ``act`` and
``noise`` are used for deconfounding, uncertainty, and robustness. The factors
are guided by physiological anchors and adversarial probing -- "structured
factorization", not a claim of strict causal disentanglement.
"""

from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn

from ..constants import FACTORS

__all__ = ["StructuredFactorization"]


class _FactorHead(nn.Module):
    """Single factor head ``G_p``: a two-layer MLP ``h -> z_p`` (Eq. 16)."""

    def __init__(self, embed_dim: int, latent_dim: int, dropout: float) -> None:
        super().__init__()
        hidden = max(embed_dim // 2, latent_dim)
        self.net = nn.Sequential(
            nn.Linear(embed_dim, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, latent_dim),
        )

    def forward(self, h: torch.Tensor) -> torch.Tensor:
        return self.net(h)


class StructuredFactorization(nn.Module):
    """Five-head structured factorization of the fused vector (Eq. 16).

    Args:
        embed_dim: dimension of the fused representation ``h``.
        latent_dim: per-factor latent dimension.
        dropout: dropout rate inside each factor head (defaults to 0.0 so the
            module is usable standalone; the assembled model passes the
            configured rate).
    """

    def __init__(self, embed_dim: int, latent_dim: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.embed_dim = embed_dim
        self.latent_dim = latent_dim
        # One MLP head G_p per structured factor, keyed by FACTORS order.
        self.heads = nn.ModuleDict(
            {p: _FactorHead(embed_dim, latent_dim, dropout) for p in FACTORS}
        )

    def forward(self, h: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Decompose ``h`` into the five structured latent factors.

        Args:
            h: fused representation ``[B, embed_dim]``.

        Returns:
            dict mapping each factor name in ``FACTORS`` to ``[B, latent_dim]``.
        """
        if h.dim() != 2 or h.shape[-1] != self.embed_dim:
            raise ValueError(
                f"expected h of shape [B, {self.embed_dim}], got {tuple(h.shape)}"
            )
        return {p: self.heads[p](h) for p in FACTORS}
