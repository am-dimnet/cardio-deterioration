"""Quality-aware gated multimodal fusion (SPEC Section 3, Eq. 14-15).

Implements the quality-aware gated fusion module defined over the fixed
candidate-modality set M = {ECG, PPG, PCG, proxy, HRV, clinical}. The
availability mask (not a sample-dependent index set) controls which modalities
contribute, so an unavailable modality (mask=0, v=0, q=0) contributes to
neither the numerator nor the denominator of the gate.

Fusion weight (Eq. 14):

    alpha_r = m_r * exp( w_g^T [ v_r ; q_r ; m_r ] )
              / ( sum_{s in M} m_s * exp( w_g^T [ v_s ; q_s ; m_s ] ) + eps )

Fused representation (Eq. 15):

    h = sum_{r in M} alpha_r v_r

The gate scorer ``w_g`` is a single shared ``Linear(embed_dim + 2, 1)`` applied
per modality to the concatenation ``[v_r ; q_r ; m_r]``.
"""

from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn as nn

from ..constants import MODALITIES

__all__ = ["QualityAwareGatedFusion"]


class QualityAwareGatedFusion(nn.Module):
    """Quality-aware gated fusion over the fixed modality set M (Eq. 14-15).

    Args:
        embed_dim: shared embedding dimension E of each ``v_r``.
        eps: numerical-stability constant added to the gate denominator
            (Eq. 14). Defaults to the SPEC/Table-4 value ``1e-6``.
    """

    def __init__(self, embed_dim: int, eps: float = 1.0e-6) -> None:
        super().__init__()
        self.embed_dim = embed_dim
        self.eps = eps
        # Shared gating scorer w_g applied to [v_r ; q_r ; m_r] (dim = E + 2).
        self.gate = nn.Linear(embed_dim + 2, 1)

    def forward(
        self,
        v: Dict[str, torch.Tensor],
        sqi: torch.Tensor,
        mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """Fuse per-modality embeddings into a single representation.

        Args:
            v: dict mapping each modality name in ``MODALITIES`` to its projected
               embedding ``[B, embed_dim]``. Missing/absent modalities should be
               supplied as zero tensors with the corresponding mask column = 0.
            sqi: signal-quality scores ``q_r`` of shape ``[B, 6]`` in ``[0, 1]``,
               column order = ``MODALITIES`` (Eq. 10).
            mask: availability mask ``m_r`` of shape ``[B, 6]`` in ``{0, 1}``,
               column order = ``MODALITIES`` (Eq. 11).

        Returns:
            h: fused representation ``[B, embed_dim]`` (Eq. 15).
            alpha: dict mapping each modality name to its normalized fusion
                weight ``[B]`` (Eq. 14).
        """
        if sqi.shape[-1] != len(MODALITIES) or mask.shape[-1] != len(MODALITIES):
            raise ValueError(
                f"sqi/mask last dim must be {len(MODALITIES)} (order={MODALITIES}), "
                f"got sqi={tuple(sqi.shape)}, mask={tuple(mask.shape)}"
            )

        # Reference modality to infer batch size / device / dtype.
        ref = v[MODALITIES[0]]
        batch = ref.shape[0]
        device, dtype = ref.device, ref.dtype

        # Per-modality unnormalized gate logits: s_r = w_g^T [v_r ; q_r ; m_r].
        logits = []       # list of [B] tensors, one per modality
        masks = []        # list of [B] tensors, one per modality
        for r in MODALITIES:
            v_r = v[r]                                   # [B, E]
            col = MODALITIES.index(r)
            q_r = sqi[:, col:col + 1].to(dtype)          # [B, 1]
            m_r = mask[:, col:col + 1].to(dtype)         # [B, 1]
            feat = torch.cat([v_r, q_r, m_r], dim=-1)    # [B, E + 2]
            logits.append(self.gate(feat).squeeze(-1))   # [B]
            masks.append(m_r.squeeze(-1))                # [B]

        logit_mat = torch.stack(logits, dim=1)           # [B, R]
        mask_mat = torch.stack(masks, dim=1)             # [B, R]

        # Numerically stable masked softmax. Subtracting the per-row max keeps
        # exp() bounded; masked-out modalities are then forced to zero weight so
        # they contribute to neither numerator nor denominator (Eq. 14).
        max_logit = logit_mat.max(dim=1, keepdim=True).values.detach()
        exp_mat = torch.exp(logit_mat - max_logit) * mask_mat  # [B, R]
        denom = exp_mat.sum(dim=1, keepdim=True) + self.eps     # [B, 1]
        alpha_mat = exp_mat / denom                             # [B, R]

        # Fused representation h = sum_r alpha_r v_r (Eq. 15).
        v_stack = torch.stack([v[r] for r in MODALITIES], dim=1)  # [B, R, E]
        h = (alpha_mat.unsqueeze(-1) * v_stack).sum(dim=1)        # [B, E]

        # Guard against an all-masked row (no available modalities): return a
        # zero embedding rather than NaN. Such rows should not occur in the
        # primary cohort (ECG/PPG always present), but this keeps forward safe.
        if not torch.isfinite(h).all():  # pragma: no cover - defensive
            h = torch.nan_to_num(h, nan=0.0, posinf=0.0, neginf=0.0)

        alpha = {r: alpha_mat[:, i] for i, r in enumerate(MODALITIES)}
        # Ensure the returned batch dimension matches the input even for the
        # degenerate empty-modality edge case above.
        assert h.shape == (batch, self.embed_dim)
        _ = device  # device is inherited from v; kept for clarity
        return h, alpha
