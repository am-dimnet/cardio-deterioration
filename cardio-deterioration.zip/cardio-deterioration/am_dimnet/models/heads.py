"""Task and anchoring heads + gradient reversal (SPEC Section 3).

Implements the output heads attached to the structured latent factors:

    * ``RiskHead``          -- deterioration risk logit from [z_auto; z_morph;
                               z_base] (Eq. 17).
    * ``HRVReconstructor``  -- reconstructs the 10-dim HRV vector from z_auto
                               (autonomic anchoring, Eq. 18-19).
    * ``MorphReconstructor``-- reconstructs morphology descriptors from z_morph
                               (morphology anchoring, Eq. 20-21).
    * ``ActivityHead``      -- activity-tertile classifier on z_act (Eq. 22).
    * ``AdversaryHead``     -- activity discriminator on z_auto / z_morph,
                               applied through gradient reversal for adversarial
                               deconfounding (Eq. 23).
    * ``GradientReversal`` / ``grad_reverse`` -- gradient-reversal layer.

The risk head returns a raw logit (the sigmoid of Eq. 17 is applied by the
caller / loss so class-weighted BCE-with-logits can be used, Eq. 26).
"""

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn
from torch.autograd import Function

__all__ = [
    "RiskHead",
    "HRVReconstructor",
    "MorphReconstructor",
    "ActivityHead",
    "AdversaryHead",
    "GradientReversal",
    "grad_reverse",
]


# --------------------------------------------------------------------------
# Gradient reversal layer (used for adversarial deconfounding, Eq. 23)
# --------------------------------------------------------------------------
class GradientReversal(Function):
    """Gradient Reversal Layer (Ganin & Lempitsky, 2015).

    Acts as the identity in the forward pass; in the backward pass it multiplies
    the incoming gradient by ``-lambda_``. Placing it before the adversarial
    activity discriminators (Eq. 23) makes minimizing the discriminator loss
    push ``z_auto`` / ``z_morph`` to become *less* predictive of activity
    intensity, i.e. activity-invariant.
    """

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, lambda_: float) -> torch.Tensor:
        ctx.lambda_ = float(lambda_)
        # ``view_as`` yields an identity output while keeping autograd wiring.
        return x.view_as(x)

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor):
        # Reverse and scale the gradient; ``None`` for the non-tensor lambda_.
        return grad_output.neg() * ctx.lambda_, None


def grad_reverse(x: torch.Tensor, lambda_: float = 1.0) -> torch.Tensor:
    """Apply the gradient-reversal layer to ``x`` with strength ``lambda_``.

    Forward is the identity; backward negates and scales the gradient by
    ``lambda_`` (Eq. 23). ``lambda_`` is typically warmed up by the trainer.
    """
    return GradientReversal.apply(x, lambda_)


# --------------------------------------------------------------------------
# Risk head (Eq. 17)
# --------------------------------------------------------------------------
class RiskHead(nn.Module):
    """Deterioration risk head over [z_auto; z_morph; z_base] (Eq. 17).

    A two-layer MLP maps the concatenated risk-related factors
    ``[B, 3*latent_dim]`` to a single logit ``[B]``. The sigmoid in Eq. 17 is
    deferred to the caller so that class-weighted BCE-with-logits (Eq. 26) can
    be applied for numerical stability.
    """

    def __init__(self, latent_dim: int, dropout: float) -> None:
        super().__init__()
        in_dim = 3 * latent_dim
        hidden = max(latent_dim, in_dim // 2)
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden),
            nn.LayerNorm(hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, 1),
        )

    def forward(
        self,
        z_auto: torch.Tensor,
        z_morph: torch.Tensor,
        z_base: torch.Tensor,
    ) -> torch.Tensor:
        """Return the risk logit ``[B]`` (pre-sigmoid, Eq. 17)."""
        z = torch.cat([z_auto, z_morph, z_base], dim=-1)  # [B, 3*latent_dim]
        return self.net(z).squeeze(-1)                    # [B]


# --------------------------------------------------------------------------
# Anchoring reconstructors (Eq. 18, Eq. 20)
# --------------------------------------------------------------------------
class HRVReconstructor(nn.Module):
    """HRV reconstruction head on z_auto (autonomic anchoring, Eq. 18).

    Reconstructs the explicit 10-dim HRV feature vector (Eq. 5) from the
    autonomic latent factor, encouraging ``z_auto`` to preserve HRV information
    (loss in Eq. 19).

    forward: ``[B, latent_dim] -> [B, n_hrv]``.
    """

    def __init__(self, latent_dim: int, n_hrv: int = 10) -> None:
        super().__init__()
        hidden = max(latent_dim, n_hrv)
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, n_hrv),
        )

    def forward(self, z_auto: torch.Tensor) -> torch.Tensor:
        return self.net(z_auto)


class MorphReconstructor(nn.Module):
    """Morphology reconstruction head on z_morph (Eq. 20).

    Reconstructs morphological descriptors (QRS-related descriptors, pulse
    width/amplitude, rise/decay time, ...) from the morphology latent factor,
    reducing the risk that morphological abnormalities leak into ``z_auto``
    (loss in Eq. 21).

    forward: ``[B, latent_dim] -> [B, morph_dim]``.
    """

    def __init__(self, latent_dim: int, morph_dim: int) -> None:
        super().__init__()
        hidden = max(latent_dim, morph_dim)
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, morph_dim),
        )

    def forward(self, z_morph: torch.Tensor) -> torch.Tensor:
        return self.net(z_morph)


# --------------------------------------------------------------------------
# Activity classifier and adversarial discriminator (Eq. 22, Eq. 23)
# --------------------------------------------------------------------------
class ActivityHead(nn.Module):
    """Activity-tertile classifier on z_act (Eq. 22).

    Predicts the activity/motion-proxy tertile class (low/moderate/high) from
    the activity latent factor, anchoring ``z_act`` to activity intensity
    (cross-entropy loss, Eq. 22).

    forward: ``[B, latent_dim] -> [B, n_classes]`` (raw logits).
    """

    def __init__(self, latent_dim: int, n_classes: int = 3) -> None:
        super().__init__()
        hidden = max(latent_dim, n_classes)
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, n_classes),
        )

    def forward(self, z_act: torch.Tensor) -> torch.Tensor:
        return self.net(z_act)


class AdversaryHead(nn.Module):
    """Adversarial activity discriminator on z_auto / z_morph (Eq. 23).

    Predicts activity intensity from a risk-related latent factor. In the
    assembled model its input is passed through ``grad_reverse`` so that
    minimizing this classifier's loss trains the discriminator while pushing the
    upstream factor to be activity-invariant (adversarial deconfounding, Eq. 23).

    forward: ``[B, latent_dim] -> [B, n_classes]`` (raw logits).
    """

    def __init__(self, latent_dim: int, n_classes: int = 3) -> None:
        super().__init__()
        hidden = max(latent_dim, n_classes)
        self.net = nn.Sequential(
            nn.Linear(latent_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, n_classes),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)
