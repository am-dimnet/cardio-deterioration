"""Multi-task loss for AM-DiMNet (SPEC Section 4, Eq. 19-28).

Combines the deterioration-risk objective with the physiological anchoring,
activity-classification, adversarial-deconfounding, latent-orthogonality, and
calibration terms into a single weighted objective (Eq. 28):

    total = L_risk
          + lambda_hrv   L_hrv
          + lambda_morph L_morph
          + lambda_act   L_act
          + lambda_adv   L_adv
          + lambda_orth  L_orth
          + lambda_cal   L_cal

with the weights read from ``config.loss`` (defaults: 0.35, 0.28, 0.20, 0.15,
0.06, 0.08). Individual terms:

    * ``L_risk``  class-weighted BCE-with-logits (Eq. 26), pos_weight = w1/w0.
    * ``L_hrv``   MSE between reconstructed and target HRV, masked by HRV
                  availability (Eq. 19).
    * ``L_morph`` MSE between reconstructed and target morphology (Eq. 21).
    * ``L_act``   cross-entropy of the activity-tertile classifier (Eq. 22).
    * ``L_adv``   sum of the two adversarial activity cross-entropies (Eq. 23).
    * ``L_orth``  centered + row-normalized cross-factor covariance penalty
                  (Eq. 24-25).
    * ``L_cal``   Brier score MSE(prob, y) (Eq. 27).

``AMDiMNetLoss(config).forward(out, batch)`` returns ``(total, parts)`` where
``parts`` is a dict of the individual (unweighted) scalar terms plus ``total``.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import Config
from ..constants import FACTORS, MODALITIES

__all__ = ["AMDiMNetLoss"]


def _hrv_available_mask(batch: Dict[str, torch.Tensor], device, dtype) -> torch.Tensor:
    """Per-sample HRV-availability weight in ``[0, 1]`` (Eq. 19 masking).

    Uses the HRV column of the availability mask (order = ``MODALITIES``) so the
    autonomic anchoring term (Eq. 19) is only applied where an HRV target
    actually exists. Falls back to all-ones if no mask is supplied.
    """
    mask = batch.get("mask")
    if mask is None:
        b = batch["hrv"].shape[0]
        return torch.ones(b, device=device, dtype=dtype)
    col = MODALITIES.index("hrv")
    return mask[:, col].to(device=device, dtype=dtype)


class AMDiMNetLoss(nn.Module):
    """Weighted multi-task loss for AM-DiMNet (Eq. 28).

    Args:
        config: :class:`~am_dimnet.config.Config`; ``config.loss`` supplies the
            term weights and ``config.train.pos_weight`` (if set) fixes the
            class-imbalance ratio ``w1/w0`` for ``L_risk`` (Eq. 26). When
            ``pos_weight`` is ``None`` the ratio is estimated per batch from the
            label prevalence.
    """

    def __init__(self, config: Config) -> None:
        super().__init__()
        self.config = config
        lc = config.loss
        self.lambda_hrv = lc.lambda_hrv
        self.lambda_morph = lc.lambda_morph
        self.lambda_act = lc.lambda_act
        self.lambda_adv = lc.lambda_adv
        self.lambda_orth = lc.lambda_orth
        self.lambda_cal = lc.lambda_cal
        # Optional fixed positive-class weight (w1/w0); None -> per-batch (Eq. 26).
        self.pos_weight: Optional[float] = config.train.pos_weight

    # ----------------------------------------------------------------------
    # Individual terms
    # ----------------------------------------------------------------------
    def _risk_loss(self, logit: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """Class-weighted BCE-with-logits (Eq. 26).

        ``pos_weight = w1 / w0``; when unset it is estimated from the batch
        prevalence ``p`` as ``(1 - p) / p`` (i.e. inverse class frequency),
        clamped to a finite range so an all-negative / all-positive mini-batch
        does not produce a degenerate weight.
        """
        y = y.to(logit.dtype)
        if self.pos_weight is not None:
            pw = float(self.pos_weight)
        else:
            prevalence = y.mean().clamp(min=1e-4, max=1 - 1e-4)
            pw = float(((1.0 - prevalence) / prevalence).item())
        pw = max(min(pw, 1e4), 1e-4)
        pos_weight = torch.tensor(pw, device=logit.device, dtype=logit.dtype)
        return F.binary_cross_entropy_with_logits(logit, y, pos_weight=pos_weight)

    def _hrv_loss(self, recon_hrv: torch.Tensor, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Masked HRV-reconstruction MSE (autonomic anchoring, Eq. 19)."""
        target = batch["hrv"]
        w = _hrv_available_mask(batch, recon_hrv.device, recon_hrv.dtype)  # [B]
        # Per-sample MSE over the 10 HRV features, then availability-weighted mean.
        per_sample = ((recon_hrv - target) ** 2).mean(dim=-1)             # [B]
        denom = w.sum().clamp(min=1.0)
        return (per_sample * w).sum() / denom

    def _morph_loss(self, recon_morph: torch.Tensor, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Morphology-reconstruction MSE (morphology anchoring, Eq. 21)."""
        return F.mse_loss(recon_morph, batch["morph_target"])

    def _act_loss(self, act_logits: torch.Tensor, batch: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Activity-tertile cross-entropy on z_act (Eq. 22)."""
        return F.cross_entropy(act_logits, batch["activity"].long())

    def _adv_loss(
        self,
        adv_auto_logits: torch.Tensor,
        adv_morph_logits: torch.Tensor,
        batch: Dict[str, torch.Tensor],
    ) -> torch.Tensor:
        """Adversarial activity cross-entropy on z_auto and z_morph (Eq. 23).

        The gradient-reversal layer is applied inside the model, so *minimizing*
        this sum trains the discriminators while pushing the risk-related
        factors toward activity-invariance.
        """
        activity = batch["activity"].long()
        return (
            F.cross_entropy(adv_auto_logits, activity)
            + F.cross_entropy(adv_morph_logits, activity)
        )

    def _orth_loss(self, z: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Centered + row-normalized cross-factor orthogonality penalty (Eq. 24-25).

        For each factor ``p`` the batch of latents ``Z_p in R^{B x d}`` is:

            1. batch-centered:   ``Zt_p = H_B Z_p``  with ``H_B = I - 11^T / B``
               (Eq. 24) so each latent dimension has zero batch mean;
            2. row-normalized:   each row scaled to unit L2 norm (RowNorm),
               making the penalty invariant to per-sample latent magnitude.

        The penalty is the mean squared Frobenius norm of the normalized
        cross-covariance ``Zt_p^T Zt_q / B`` over all unordered factor pairs
        ``p != q`` (Eq. 25), driving distinct factors to be decorrelated.
        """
        factors = FACTORS
        b = z[factors[0]].shape[0]

        # Center over the batch (H_B Z_p) then unit-normalize each row.
        normed: Dict[str, torch.Tensor] = {}
        for p in factors:
            zp = z[p]                                   # [B, d]
            zc = zp - zp.mean(dim=0, keepdim=True)      # H_B Z_p  (Eq. 24)
            zc = F.normalize(zc, p=2, dim=1, eps=1e-8)  # RowNorm (unit L2 per row)
            normed[p] = zc

        # Mean over unordered pairs of || Zt_p^T Zt_q / B ||_F^2 (Eq. 25).
        total = z[factors[0]].new_zeros(())
        n_pairs = 0
        for i in range(len(factors)):
            for j in range(i + 1, len(factors)):
                cross = normed[factors[i]].t() @ normed[factors[j]] / b  # [d, d]
                total = total + (cross ** 2).sum()
                n_pairs += 1
        return total / max(n_pairs, 1)

    def _cal_loss(self, prob: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """Brier-score calibration term MSE(prob, y) (Eq. 27)."""
        return F.mse_loss(prob, y.to(prob.dtype))

    # ----------------------------------------------------------------------
    # Aggregate
    # ----------------------------------------------------------------------
    def forward(
        self,
        out: Dict[str, object],
        batch: Dict[str, torch.Tensor],
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """Compute the weighted multi-task loss (Eq. 28).

        Args:
            out: model output dict (SPEC Section 3): must provide ``logit``,
                ``prob``, ``recon_hrv``, ``recon_morph``, ``act_logits``,
                ``adv_auto_logits``, ``adv_morph_logits``, ``z``.
            batch: batch dict (SPEC Section 2): must provide ``y``, ``hrv``,
                ``morph_target``, ``activity`` (and, for masking, ``mask``).

        Returns:
            total: scalar weighted total loss (Eq. 28).
            parts: dict of the individual unweighted scalar terms
                (``L_risk, L_hrv, L_morph, L_act, L_adv, L_orth, L_cal``) plus
                ``total`` for logging.
        """
        y = batch["y"]

        l_risk = self._risk_loss(out["logit"], y)                          # Eq. 26
        l_hrv = self._hrv_loss(out["recon_hrv"], batch)                    # Eq. 19
        l_morph = self._morph_loss(out["recon_morph"], batch)             # Eq. 21
        l_act = self._act_loss(out["act_logits"], batch)                  # Eq. 22
        l_adv = self._adv_loss(                                            # Eq. 23
            out["adv_auto_logits"], out["adv_morph_logits"], batch
        )
        l_orth = self._orth_loss(out["z"])                               # Eq. 24-25
        l_cal = self._cal_loss(out["prob"], y)                          # Eq. 27

        total = (
            l_risk
            + self.lambda_hrv * l_hrv
            + self.lambda_morph * l_morph
            + self.lambda_act * l_act
            + self.lambda_adv * l_adv
            + self.lambda_orth * l_orth
            + self.lambda_cal * l_cal
        )  # Eq. 28

        parts = {
            "L_risk": l_risk.detach(),
            "L_hrv": l_hrv.detach(),
            "L_morph": l_morph.detach(),
            "L_act": l_act.detach(),
            "L_adv": l_adv.detach(),
            "L_orth": l_orth.detach(),
            "L_cal": l_cal.detach(),
            "total": total.detach(),
        }
        return total, parts
