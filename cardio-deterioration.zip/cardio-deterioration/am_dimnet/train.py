"""Training driver for AM-DiMNet (SPEC Section 7).

Implements the supervised training loop for the assembled network
(:class:`am_dimnet.models.am_dimnet.AMDiMNet`) with the multi-task objective
(:class:`am_dimnet.models.losses.AMDiMNetLoss`, Eq. 28):

    * **Optimiser** - AdamW with the Table-4 learning rate / weight decay
      (``train.lr`` / ``train.weight_decay``).
    * **Early stopping** - monitors the *patient-level* AUROC on the validation
      split (top-decile aggregation, Eq. 30) with ``train.patience`` epochs of
      grace; the best-AUROC weights are restored at the end.
    * **Modality-dropout augmentation** - during training each *droppable*
      (non-ECG/PPG) modality is independently masked out with probability
      ``train.modality_dropout``, mirroring the quality-aware fusion's ability to
      operate under missing modalities (Eq. 14-15) and the modality-dropout
      robustness protocol.
    * **GRL warm-up** - the gradient-reversal strength ``adv_lambda`` used by the
      adversarial deconfounding heads (Eq. 23) is annealed from 0 -> 1 across the
      first fraction of training with the standard domain-adaptation schedule
      ``2 / (1 + exp(-gamma * p)) - 1`` (Ganin & Lempitsky, 2015), so the
      discriminators are not fought before the encoders have learned anything.

Public API
----------
``set_seed(seed)``                       - seed python / numpy / torch (+cudnn).
``train_one(config, loaders, seed)``     - train once, return ``(model, history)``.

The ``__main__`` CLI builds :class:`~am_dimnet.data.synthetic.SyntheticCohort`
loaders by default and runs :func:`train_one`; with ``--config`` it loads a YAML
mirroring :class:`~am_dimnet.config.Config` (see ``configs/default.yaml``).
"""

from __future__ import annotations

import argparse
import math
import os
import random
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader

from .config import Config
from .constants import MODALITIES, WAVEFORM_MODS
from .data.synthetic import make_loaders
from .metrics import auroc, patient_top_decile
from .models.am_dimnet import AMDiMNet
from .models.losses import AMDiMNetLoss

__all__ = ["set_seed", "train_one", "TrainHistory", "main"]


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
def set_seed(seed: int) -> None:
    """Seed all RNGs used in training for deterministic runs (SPEC Section 9).

    Seeds the ``random``, ``numpy`` and ``torch`` (CPU + CUDA) generators and
    forces cuDNN into deterministic, non-benchmarking mode. Also sets
    ``PYTHONHASHSEED`` so hash-order-dependent structures are stable.
    """
    seed = int(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():  # pragma: no cover - CPU smoke test path
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ---------------------------------------------------------------------------
# History container
# ---------------------------------------------------------------------------
class TrainHistory:
    """Per-epoch training/validation trace returned by :func:`train_one`.

    Stores parallel lists indexed by epoch so callers (and the evaluation
    driver) can plot learning curves or recover the selected epoch. Behaves like
    a mapping (``history["val_auroc"]``) and exposes convenience attributes.
    """

    def __init__(self) -> None:
        self.epoch: List[int] = []
        self.train_loss: List[float] = []
        self.val_loss: List[float] = []
        self.val_auroc: List[float] = []              # patient-level AUROC (Eq. 30)
        self.val_window_auroc: List[float] = []       # window-level AUROC
        self.adv_lambda: List[float] = []             # GRL strength that epoch
        self.parts: List[Dict[str, float]] = []       # mean loss components
        self.best_epoch: int = -1
        self.best_val_auroc: float = float("-inf")

    def append(
        self,
        epoch: int,
        train_loss: float,
        val_loss: float,
        val_auroc: float,
        val_window_auroc: float,
        adv_lambda: float,
        parts: Dict[str, float],
    ) -> None:
        self.epoch.append(int(epoch))
        self.train_loss.append(float(train_loss))
        self.val_loss.append(float(val_loss))
        self.val_auroc.append(float(val_auroc))
        self.val_window_auroc.append(float(val_window_auroc))
        self.adv_lambda.append(float(adv_lambda))
        self.parts.append({k: float(v) for k, v in parts.items()})

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to a plain dict (JSON-friendly)."""
        return {
            "epoch": list(self.epoch),
            "train_loss": list(self.train_loss),
            "val_loss": list(self.val_loss),
            "val_auroc": list(self.val_auroc),
            "val_window_auroc": list(self.val_window_auroc),
            "adv_lambda": list(self.adv_lambda),
            "parts": [dict(p) for p in self.parts],
            "best_epoch": int(self.best_epoch),
            "best_val_auroc": float(self.best_val_auroc),
        }


# ---------------------------------------------------------------------------
# Batch utilities
# ---------------------------------------------------------------------------
# Modalities eligible for training-time modality dropout = everything that is
# NOT a core waveform (ECG/PPG are always present in the primary cohort).
_DROPPABLE_MODS = [m for m in MODALITIES if m not in WAVEFORM_MODS]


def _mod_col(mod: str) -> int:
    """Column index of ``mod`` in the ordered MODALITIES set (SPEC Section 2).

    Mask and SQI vectors are both ordered by :data:`MODALITIES`, so a single
    lookup yields the shared column. Computed locally (not imported) so training
    stays import-clean regardless of optional constants helpers.
    """
    return MODALITIES.index(mod)

# Vector tensors that must be zero-filled when their modality is dropped so that
# the fused representation only sees the mask, never stale features (Eq. 11).
_MOD_TO_TENSOR_KEY = {
    "proxy": "proxy",
    "hrv": "hrv",
    "clinical": "clinical",
    "pcg": "pcg",
}


def _move_batch(batch: Dict[str, torch.Tensor], device: torch.device) -> Dict[str, torch.Tensor]:
    """Move every tensor field of a batch dict to ``device`` (non-tensors passed through)."""
    out: Dict[str, torch.Tensor] = {}
    for k, v in batch.items():
        out[k] = v.to(device) if torch.is_tensor(v) else v
    return out


def apply_modality_dropout(
    batch: Dict[str, torch.Tensor],
    rate: float,
    generator: Optional[torch.Generator] = None,
) -> Dict[str, torch.Tensor]:
    """Randomly drop droppable modalities from a *training* batch (augmentation).

    Each non-ECG/PPG modality (``proxy``, ``hrv``, ``clinical``, ``pcg``) is
    independently zeroed with probability ``rate`` **per sample**: the mask
    column is set to 0, the corresponding SQI column is collapsed to 0, and the
    modality's tensor is zero-filled so no residual signal leaks past the gate
    (Eq. 11 / Eq. 14-15). ECG and PPG are never dropped (always-present primary
    waveforms). Returns a *new* batch dict (input tensors are cloned, not mutated
    in place) so the original loader batch is untouched.

    Parameters
    ----------
    batch : dict
        A batch following the SPEC Section 2 contract (already on the device).
    rate : float
        Per-modality drop probability (``train.modality_dropout``); ``<=0`` is a
        no-op returning the batch unchanged.
    generator : torch.Generator, optional
        RNG for reproducible dropout masks (defaults to the global torch RNG).
    """
    if rate <= 0.0:
        return batch

    mask = batch["mask"]
    B = mask.shape[0]
    device = mask.device

    # Clone the tensors we may modify (leave the rest as shared references).
    new_mask = mask.clone()
    new_sqi = batch["sqi"].clone()
    cloned: Dict[str, torch.Tensor] = {}

    for mod in _DROPPABLE_MODS:
        j = _mod_col(mod)
        # Draw one Bernoulli(rate) per sample; only drop where currently present.
        rnd = torch.rand(B, generator=generator, device=device)
        drop = (rnd < float(rate)) & (new_mask[:, j] > 0)
        if not bool(drop.any()):
            continue
        new_mask[drop, j] = 0.0
        new_sqi[drop, j] = 0.0
        key = _MOD_TO_TENSOR_KEY.get(mod)
        if key is not None and key in batch:
            if key not in cloned:
                cloned[key] = batch[key].clone()
            # Zero the dropped samples' tensor (broadcast over feature dims).
            t = cloned[key]
            if t.dim() == 1:
                t[drop] = 0.0
            else:
                t[drop] = 0.0

    out = dict(batch)
    out["mask"] = new_mask
    out["sqi"] = new_sqi
    out.update(cloned)
    return out


# ---------------------------------------------------------------------------
# GRL warm-up schedule (Eq. 23 adversarial deconfounding)
# ---------------------------------------------------------------------------
def grl_lambda(progress: float, gamma: float = 10.0) -> float:
    """Gradient-reversal strength warm-up 0 -> 1 (Ganin & Lempitsky, 2015).

    ``lambda(p) = 2 / (1 + exp(-gamma * p)) - 1`` with training progress
    ``p in [0, 1]``. Starts at 0 (no adversary) and saturates near 1, so the
    activity discriminators (Eq. 23) engage only once the shared encoders and
    factors have begun to form -- avoiding early, destabilising adversarial
    gradients on ``z_auto`` / ``z_morph``.
    """
    p = float(min(max(progress, 0.0), 1.0))
    return float(2.0 / (1.0 + math.exp(-gamma * p)) - 1.0)


# ---------------------------------------------------------------------------
# pos_weight (class imbalance, Eq. 26)
# ---------------------------------------------------------------------------
def _infer_pos_weight(config: Config, train_loader: DataLoader) -> Optional[float]:
    """Return ``pos_weight = omega1/omega0`` for L_risk (Eq. 26).

    Uses ``config.train.pos_weight`` if set; otherwise estimates it from the
    training-set prevalence ``pi`` as ``(1 - pi) / pi`` (inverse class frequency),
    which is the standard class-balancing weight for BCE-with-logits.
    """
    if config.train.pos_weight is not None:
        return float(config.train.pos_weight)
    n_pos = 0
    n_tot = 0
    for batch in train_loader:
        y = batch["y"]
        n_pos += int(torch.sum(y > 0.5).item())
        n_tot += int(y.numel())
    if n_tot == 0 or n_pos == 0 or n_pos == n_tot:
        return None  # degenerate; loss falls back to unweighted BCE
    pi = n_pos / n_tot
    return float((1.0 - pi) / pi)


# ---------------------------------------------------------------------------
# validation pass
# ---------------------------------------------------------------------------
@torch.no_grad()
def _collect_predictions(
    model: AMDiMNet,
    loader: DataLoader,
    loss_fn: Optional[AMDiMNetLoss],
    device: torch.device,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, float, Dict[str, float]]:
    """Run ``model`` over ``loader`` and gather probs / labels / patient ids.

    Returns ``(prob, y, patient_id, mean_loss, mean_parts)``. ``mean_loss`` and
    ``mean_parts`` are 0 / empty when ``loss_fn`` is ``None``.
    """
    model.eval()
    probs: List[np.ndarray] = []
    ys: List[np.ndarray] = []
    pids: List[np.ndarray] = []
    total_loss = 0.0
    n_batches = 0
    parts_acc: Dict[str, float] = {}

    for batch in loader:
        batch = _move_batch(batch, device)
        out = model(batch)
        probs.append(out["prob"].detach().cpu().numpy().reshape(-1))
        ys.append(batch["y"].detach().cpu().numpy().reshape(-1))
        pids.append(batch["patient_id"].detach().cpu().numpy().reshape(-1))
        if loss_fn is not None:
            total, parts = loss_fn(out, batch)
            total_loss += float(total.item())
            for k, v in parts.items():
                parts_acc[k] = parts_acc.get(k, 0.0) + float(
                    v.item() if torch.is_tensor(v) else v
                )
            n_batches += 1

    if not probs:
        empty = np.zeros(0, dtype=np.float64)
        return empty, empty, empty.astype(np.int64), 0.0, {}

    prob = np.concatenate(probs)
    y = np.concatenate(ys)
    pid = np.concatenate(pids).astype(np.int64)
    mean_loss = (total_loss / n_batches) if n_batches > 0 else 0.0
    mean_parts = {k: v / n_batches for k, v in parts_acc.items()} if n_batches > 0 else {}
    return prob, y, pid, mean_loss, mean_parts


def _patient_auroc(prob: np.ndarray, y: np.ndarray, pid: np.ndarray) -> float:
    """Patient-level AUROC via top-decile aggregation (Eq. 30 + AUROC).

    Aggregates window probabilities to one score per patient (top-decile mean,
    Eq. 30), takes each patient's label as the max over its windows, and returns
    AUROC over patients. ``nan`` when a single class is present.
    """
    if prob.size == 0:
        return float("nan")
    y_hat, _uids, y_true = patient_top_decile(prob, pid, y=y)
    return auroc(y_hat, y_true)


# ---------------------------------------------------------------------------
# main training entry point
# ---------------------------------------------------------------------------
def train_one(
    config: Config,
    loaders: Dict[str, DataLoader],
    seed: int,
    device: Optional[torch.device] = None,
    warmup_frac: float = 0.5,
    verbose: bool = False,
) -> Tuple[AMDiMNet, TrainHistory]:
    """Train a single AM-DiMNet model (SPEC Section 7).

    Parameters
    ----------
    config : Config
        Full configuration (Table 4 defaults). ``config.train`` supplies the
        optimiser, schedule, dropout, and early-stopping settings.
    loaders : dict
        ``{"train", "val", "test"}`` -> ``DataLoader`` following the batch
        contract (SPEC Section 2). Only ``train``/``val`` are used here.
    seed : int
        RNG seed; makes the whole run deterministic (weights, dropout masks,
        shuffling if the loader honours a seeded generator).
    device : torch.device, optional
        Defaults to CPU (the smoke test is CPU-only); CUDA used if requested.
    warmup_frac : float
        Fraction of ``max_epochs`` over which the GRL strength anneals 0 -> 1
        (Eq. 23). ``adv_lambda`` reaches ~1 by ``warmup_frac * max_epochs``.
    verbose : bool
        Print a one-line summary per epoch.

    Returns
    -------
    (model, history)
        ``model`` carries the best-validation-AUROC weights (early stopping on
        patient-level AUROC, Eq. 30). ``history`` is a :class:`TrainHistory`.

    Notes
    -----
    * AdamW(lr=``train.lr``, weight_decay=``train.weight_decay``) over all model
      parameters (Table 4).
    * Modality-dropout augmentation applied to every training batch
      (``train.modality_dropout``).
    * The adversarial GRL strength is written to ``model.adv_lambda`` before each
      epoch's forward passes (the model applies ``grad_reverse`` internally,
      SPEC Section 3 / Eq. 23).
    """
    set_seed(seed)
    device = device or torch.device("cpu")

    train_loader = loaders["train"]
    val_loader = loaders.get("val")

    # --- build model + loss ------------------------------------------------
    model = AMDiMNet(config).to(device)

    # Estimate pos_weight from the training prevalence unless pinned in config.
    pos_weight = _infer_pos_weight(config, train_loader)
    # Thread the resolved pos_weight into the loss without mutating the shared
    # Config in place (keep the loss self-contained per SPEC Section 4).
    loss_fn = AMDiMNetLoss(config)
    _install_pos_weight(loss_fn, pos_weight, device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config.train.lr),
        weight_decay=float(config.train.weight_decay),
    )

    max_epochs = int(config.train.max_epochs)
    patience = int(config.train.patience)
    modality_dropout = float(config.train.modality_dropout)
    warmup_epochs = max(1.0, float(warmup_frac) * max_epochs)

    # Dedicated generator for reproducible modality-dropout masks.
    drop_gen = torch.Generator(device=device)
    drop_gen.manual_seed(seed + 1)

    history = TrainHistory()
    best_state: Optional[Dict[str, torch.Tensor]] = None
    best_auroc = float("-inf")
    best_epoch = -1
    epochs_no_improve = 0

    for epoch in range(max_epochs):
        # GRL warm-up: progress within the warm-up window, saturating at 1.
        progress = min(1.0, epoch / warmup_epochs)
        adv_lambda = grl_lambda(progress)
        model.adv_lambda = float(adv_lambda)

        # ---------------- train ------------------------------------------
        model.train()
        running_loss = 0.0
        n_batches = 0
        for batch in train_loader:
            batch = _move_batch(batch, device)
            batch = apply_modality_dropout(batch, modality_dropout, generator=drop_gen)

            optimizer.zero_grad(set_to_none=True)
            out = model(batch)
            total, _parts = loss_fn(out, batch)
            total.backward()
            optimizer.step()

            running_loss += float(total.item())
            n_batches += 1

        train_loss = (running_loss / n_batches) if n_batches > 0 else float("nan")

        # ---------------- validate (early-stopping signal) ----------------
        if val_loader is not None and len(getattr(val_loader, "dataset", [])) > 0:
            model.adv_lambda = float(adv_lambda)
            v_prob, v_y, v_pid, v_loss, v_parts = _collect_predictions(
                model, val_loader, loss_fn, device
            )
            val_auroc = _patient_auroc(v_prob, v_y, v_pid)
            val_window_auroc = auroc(v_prob, v_y) if v_prob.size else float("nan")
        else:
            # No validation split: fall back to the training loss for stopping.
            v_loss, v_parts = train_loss, {}
            val_auroc = float("nan")
            val_window_auroc = float("nan")

        history.append(
            epoch=epoch,
            train_loss=train_loss,
            val_loss=v_loss,
            val_auroc=val_auroc,
            val_window_auroc=val_window_auroc,
            adv_lambda=adv_lambda,
            parts=v_parts,
        )

        # ---------------- early stopping on patient-level val AUROC -------
        # Use the patient-level AUROC when defined; if it is nan (degenerate
        # single-class val), fall back to minimising validation loss.
        monitor = val_auroc
        improved = False
        if math.isnan(monitor):
            # Lower val_loss is better -> convert to a maximisation signal.
            surrogate = -v_loss
            if surrogate > best_auroc:
                best_auroc = surrogate
                improved = True
        else:
            if monitor > best_auroc:
                best_auroc = monitor
                improved = True

        if improved:
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            epochs_no_improve = 0
        else:
            epochs_no_improve += 1

        if verbose:
            print(
                f"epoch {epoch:03d} | train_loss {train_loss:.4f} | "
                f"val_loss {v_loss:.4f} | val_auroc(pt) {val_auroc:.4f} | "
                f"val_auroc(win) {val_window_auroc:.4f} | adv_lambda {adv_lambda:.3f}"
            )

        if epochs_no_improve >= patience:
            if verbose:
                print(
                    f"early stopping at epoch {epoch} "
                    f"(no improvement for {patience} epochs; best epoch {best_epoch})"
                )
            break

    # Restore the best-validation weights.
    if best_state is not None:
        model.load_state_dict(best_state)
    history.best_epoch = best_epoch
    history.best_val_auroc = (
        float(best_auroc) if not math.isnan(best_auroc) and best_auroc != float("-inf") else float("nan")
    )
    # Reset adv_lambda to the fully-on value for downstream evaluation/inference.
    model.adv_lambda = 1.0
    return model, history


def _install_pos_weight(
    loss_fn: AMDiMNetLoss, pos_weight: Optional[float], device: torch.device
) -> None:
    """Best-effort injection of the resolved ``pos_weight`` into the loss module.

    The loss (SPEC Section 4) computes ``pos_weight = omega1/omega0`` for the
    class-weighted BCE (Eq. 26). Different loss implementations expose this
    differently, so we set the common attribute names if present; if none exist
    the loss simply uses its own default (config / auto), keeping this a no-op.
    """
    if pos_weight is None:
        return
    pw_tensor = torch.tensor(float(pos_weight), dtype=torch.float32, device=device)
    for attr in ("pos_weight", "_pos_weight"):
        if hasattr(loss_fn, attr):
            try:
                setattr(loss_fn, attr, pw_tensor)
                return
            except Exception:  # pragma: no cover - defensive
                pass
    # As a fallback, expose it as a plain attribute the loss may consult.
    try:
        setattr(loss_fn, "pos_weight", pw_tensor)
    except Exception:  # pragma: no cover
        pass


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m am_dimnet.train",
        description=(
            "Train AM-DiMNet on a synthetic cohort (default) or a config-specified "
            "setup. Early stopping on patient-level validation AUROC (Eq. 30)."
        ),
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to a YAML config mirroring am_dimnet.config.Config "
        "(default: configs/default.yaml if present, else built-in defaults).",
    )
    parser.add_argument(
        "--seed", type=int, default=None,
        help="Random seed (default: first entry of train.seeds).",
    )
    parser.add_argument(
        "--epochs", type=int, default=None,
        help="Override config.train.max_epochs (useful for a quick CLI run).",
    )
    parser.add_argument(
        "--n-patients", type=int, default=64,
        help="Synthetic cohort size (SyntheticCohort n_patients).",
    )
    parser.add_argument(
        "--prevalence", type=float, default=0.219,
        help="Synthetic positive-window prevalence (default 0.219).",
    )
    parser.add_argument(
        "--ckpt", type=str, default=None,
        help="If set, save the trained model state_dict + config to this path.",
    )
    parser.add_argument(
        "--warmup-frac", type=float, default=0.5,
        help="Fraction of max_epochs over which the GRL strength anneals 0->1.",
    )
    parser.add_argument(
        "--quiet", action="store_true",
        help="Suppress per-epoch logging.",
    )
    return parser


def _resolve_config(args: argparse.Namespace) -> Config:
    """Load the config from --config, else configs/default.yaml, else defaults."""
    if args.config:
        return Config.load(args.config)
    default_yaml = os.path.join("configs", "default.yaml")
    if os.path.exists(default_yaml):
        try:
            return Config.load(default_yaml)
        except Exception:  # pragma: no cover - fall back to code defaults
            pass
    return Config.default()


def main(argv: Optional[List[str]] = None) -> int:
    """CLI entry point: ``python -m am_dimnet.train [--config ...]``."""
    args = _build_arg_parser().parse_args(argv)
    config = _resolve_config(args)

    if args.epochs is not None:
        config.train.max_epochs = int(args.epochs)

    seed = args.seed if args.seed is not None else int(config.train.seeds[0])
    set_seed(seed)

    # Default data source: the self-contained synthetic cohort (SPEC Section 5).
    loaders = make_loaders(
        config,
        n_patients=int(args.n_patients),
        prevalence=float(args.prevalence),
        seed=seed,
    )

    model, history = train_one(
        config,
        loaders,
        seed=seed,
        warmup_frac=float(args.warmup_frac),
        verbose=not args.quiet,
    )

    if not args.quiet:
        print(
            f"training complete | best epoch {history.best_epoch} | "
            f"best val AUROC(pt) {history.best_val_auroc:.4f}"
        )

    if args.ckpt:
        os.makedirs(os.path.dirname(os.path.abspath(args.ckpt)) or ".", exist_ok=True)
        torch.save(
            {
                "state_dict": model.state_dict(),
                "config": config.to_dict(),
                "seed": int(seed),
                "history": history.to_dict(),
            },
            args.ckpt,
        )
        if not args.quiet:
            print(f"saved checkpoint -> {args.ckpt}")

    return 0


if __name__ == "__main__":  # pragma: no cover - CLI entry point
    raise SystemExit(main())
