# Data Access — PhysioNet MIMIC-IV (Clinical + Waveform)

AM-DiMNet is developed and evaluated on the **MIMIC-IV Clinical Database** and
the **MIMIC-IV Waveform Database**, both distributed by
[PhysioNet](https://physionet.org/). These are **credentialed-access** datasets
governed by their own Data Use Agreements (DUAs). **This repository ships no
patient data and redistributes none.** You must obtain the data yourself.

---

## 1. What you must do before touching any data

1. **Create a PhysioNet account** at https://physionet.org/register/.
2. **Complete CITI "Data or Specimens Only Research" training** and upload the
   completion report to PhysioNet, per their instructions.
3. **Become a credentialed user** (PhysioNet reviews and approves credentialing).
4. **Sign the Data Use Agreement** for each dataset you access:
   - MIMIC-IV Clinical Database (v3.1 or the version you cite).
   - MIMIC-IV Waveform Database (v0.1.0 or the version you cite).
5. Only then may you download the data to a machine that complies with the DUA.

Consult the canonical dataset pages for exact, current requirements:

- MIMIC-IV Clinical Database: https://physionet.org/content/mimiciv/
- MIMIC-IV Waveform Database:  https://physionet.org/content/mimic4wdb/

---

## 2. Terms you agree to (summary — the signed DUA governs)

The signed PhysioNet DUA is authoritative. Key obligations include:

- **No redistribution.** Do not share, re-host, publish, or otherwise
  redistribute the raw or derived data to anyone who is not independently
  credentialed and covered by the same DUA. This includes derived cohort CSVs,
  extracted windows, and cached features produced by this pipeline.
- **No re-identification.** Do not attempt to identify individuals or contact
  any individual, institution, or provider represented in the data.
- **Restricted sharing of derivatives.** Treat everything under `data/` as
  confidential data governed by the DUA, not as shareable artifacts.
- **Responsible use.** Use the data only for the research purpose you declared.

Because of these terms, `data/`, `checkpoints/`, and `results/` are
**git-ignored** in this repository (see `.gitignore`). Never commit any file
derived from the data, and never publish trained checkpoints that could encode
protected content without confirming your DUA permits it.

---

## 3. Expected local layout

Point `configs/mimic.yaml` (`paths:` block) at your local copies. A typical
layout after download:

```
/data/physionet.org/files/
  mimiciv/3.1/                     # MIMIC-IV Clinical Database
    hosp/  icu/                    # module CSVs (or a loaded Postgres instance)
  mimic4wdb/0.1.0/                 # MIMIC-IV Waveform Database (WFDB records)
```

The clinical modules may be used either as CSV/parquet or loaded into a
PostgreSQL instance (see the official `mimic-code` build scripts). The cohort
extraction reads SQL from `sql/cohort_extraction.sql` and
`sql/endpoint_labeling.sql` against the connection configured in the `db:` block
of `configs/mimic.yaml`.

---

## 4. Credentials handling

- **Never commit credentials.** The `db.password` field in `configs/mimic.yaml`
  is intentionally empty. Provide the password via the `MIMIC_DB_PASSWORD`
  environment variable, a `~/.pgpass` file, or a libpq service definition.
- `.env` and `.pgpass` are git-ignored.
- Host/user default to `MIMIC_DB_HOST` / `MIMIC_DB_USER` environment variables.

---

## 5. Running without the real data

You do **not** need MIMIC-IV to exercise the method. The self-contained
`SyntheticCohort` (`am_dimnet/data/synthetic.py`) reproduces the batch contract
and powers the smoke test and all unit-level checks:

```bash
python -m am_dimnet.smoke_test
```

Use the synthetic path for development, CI, and verifying the code path end to
end; use the MIMIC-IV path only once you are credentialed.
