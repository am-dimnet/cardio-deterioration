# Reproducibility Guide

This document gives the exact, step-by-step procedure to (a) verify the
implementation on synthetic data and (b) reproduce the full MIMIC-IV pipeline
end to end. It complements the top-level `README.md`.

> **Note on numbers.** The manuscript reports results on the real MIMIC-IV
> cohort. This repository does not embed any performance numbers; when run on
> synthetic data it produces *qualitatively* sensible outputs (finite, decreasing
> loss; above-chance discrimination; calibratable probabilities), not the
> paper's headline metrics. Reproducing the paper's numbers requires the
> credentialed MIMIC-IV data (see `docs/data_access.md`).

---

## 0. Environment

Pick one:

```bash
# pip
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# or conda
conda env create -f environment.yml
conda activate am-dimnet
```

Python 3.10+ and PyTorch 2.x. No GPU is required for the smoke test.

Determinism: every entry point seeds Python/NumPy/PyTorch. The training seeds
are `train.seeds = [11, 23, 42, 71, 97]` (5 independent runs). Exact
bit-for-bit reproducibility across different hardware/BLAS/PyTorch builds is not
guaranteed; report the mean +/- SD across seeds as in the manuscript.

---

## 1. Smoke test (no data required)

Confirms the whole method wires together on CPU in under ~1 minute:

```bash
python -m am_dimnet.smoke_test
```

It builds `Config.default()`, creates a tiny `SyntheticCohort` with
patient-disjoint loaders, runs a forward pass and asserts every output shape,
computes `AMDiMNetLoss` and takes a couple of optimizer steps (loss finite and
decreasing), then runs temperature calibration and the metric suite
(AUROC / AUPRC / ECE-15 / operating point) on the tiny test split. On success it
prints `SMOKE TEST PASSED`.

---

## 2. Full MIMIC-IV reproduction pipeline

Run the stages in order. Each wrapper script sets `set -euo pipefail` and reads
paths/DB settings from `configs/mimic.yaml`. Complete PhysioNet credentialing
first (`docs/data_access.md`).

### 2.1 Extract cohort + labels
```bash
scripts/run_extract.sh configs/mimic.yaml
```
Selects candidate ICU stays with waveform linkage and applies the cohort-flow
exclusions (Table 12): waveform availability, ECG/PPG availability, minimum
duration, RR-quality, temporal alignment, pre-existing-endpoint, and
gap-window-endpoint filters. Endpoint labels follow Table 1 and the
gap/horizon definition (Eq. 2-3): a window is positive if >= 1 endpoint
component occurs in `[window_end + gap_h, window_end + gap_h + horizon_h]`.
Outputs a cohort table and a flow log under `paths.cohort_csv`.

### 2.2 Preprocess -> features -> windows -> splits
```bash
scripts/run_preprocess.sh configs/mimic.yaml
```
Bandpasses each modality (Table 4 bands), segments 5-min windows at 60 s step,
resamples ECG/PPG to `data.ecg_len`/`data.ppg_len`, builds PCG log-Mel
spectrograms, and computes HRV (Eq. 5), activity-proxy components (Eq. 7-9),
and per-modality SQI (Eq. 10). Assembles batch-contract window records and then
builds the **patient-disjoint** train/val/test split (70/15/15) with
`patient_split`. A `split_summary` table (Tables 10-11) is emitted for audit.

### 2.3 Train (5 seeds)
```bash
scripts/run_train.sh configs/mimic.yaml
```
Trains AM-DiMNet with AdamW (`train.lr`, `train.weight_decay`), early stopping
on validation AUROC (`train.patience`), modality-dropout augmentation
(`train.modality_dropout`), and a GRL lambda warmup for adversarial
deconfounding. Writes one checkpoint per seed under `paths.checkpoints_dir`.
The composite objective is Eq. 28 with weights from `configs/*.yaml` `loss:`.

To train a single seed:
```bash
scripts/run_train.sh configs/mimic.yaml 42
```

### 2.4 Calibrate + evaluate
```bash
scripts/run_evaluate.sh checkpoints/seed42.ckpt configs/mimic.yaml results/seed42
```
Fits temperature scaling on validation logits, selects the operating threshold
(Youden / F1 / sensitivity-floor), and computes the full metric suite at patient
level (`patient_top_decile` Eq. 30 / `patient_max` Eq. 31) plus window-level
quality/operating-point stats: AUROC, AUPRC, macro-F1, MCC, Brier, ECE-15
(Eq. 35), reliability and decision curves, subgroup breakdowns (activity
tertiles, very-low-quality subgroup), and patient-cluster bootstrap CIs. Results
are written as JSON/CSV under the output directory.

### 2.5 Aggregate across seeds
Repeat 2.4 for each seed checkpoint and aggregate (mean +/- SD) to reproduce the
manuscript's reported statistics. The evaluation JSON/CSV are the inputs to the
paper's tables and figures.

---

## 3. Baselines

Baselines consume the identical batch contract (`am_dimnet/baselines/`):
classical HRV models (LogReg / RandomForest / XGBoost), single-modality CNNs,
fusion variants (early / late / attention / modality-dropout / adversarial
deconfounding), and foundation-model wrappers (MOMENT, NormWear) whose
pretrained encoders are swappable, documented stubs. Train/evaluate them through
the same `train.py` / `evaluate.py` entry points for an apples-to-apples
comparison.

---

## 4. Troubleshooting

- **Smoke test slow / OOM:** it is CPU-sized by design; ensure no other heavy
  process competes. It should finish in ~1 minute.
- **`xgboost` import error:** it is an optional dependency; the classical
  baseline guards the import and skips the XGBoost variant if unavailable.
- **DB connection errors in `run_extract.sh`:** verify the `db:` block in
  `configs/mimic.yaml` and that `MIMIC_DB_PASSWORD` (or `~/.pgpass`) is set.
- **Non-identical numbers across machines:** expected; report seed mean +/- SD.
