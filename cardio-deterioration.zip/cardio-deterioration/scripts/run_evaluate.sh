#!/usr/bin/env bash
# run_evaluate.sh -- Calibrate + evaluate a trained AM-DiMNet checkpoint.
#
# Wraps am_dimnet.evaluate: fits temperature scaling on validation logits,
# selects the operating threshold, then computes the full patient-level +
# window-level metric suite (AUROC/AUPRC/macro-F1/MCC/Brier/ECE-15), reliability
# and decision curves, operating-point + subgroup stats, with patient-cluster
# bootstrap CIs. Writes JSON/CSV to --out. NOT part of the smoke test.
#
# Usage:
#   scripts/run_evaluate.sh CKPT [CONFIG] [OUTDIR]
# Example:
#   scripts/run_evaluate.sh checkpoints/seed42.ckpt configs/mimic.yaml results/seed42
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

if [ "$#" -lt 1 ]; then
  echo "usage: scripts/run_evaluate.sh CKPT [CONFIG] [OUTDIR]" >&2
  exit 2
fi

CKPT="$1"
CONFIG="${2:-configs/default.yaml}"
OUTDIR="${3:-results}"

echo "[run_evaluate] repo root : $REPO_ROOT"
echo "[run_evaluate] config    : $CONFIG"
echo "[run_evaluate] ckpt      : $CKPT"
echo "[run_evaluate] out       : $OUTDIR"
echo "[run_evaluate] calibrating + evaluating ..."

python -m am_dimnet.evaluate --config "$CONFIG" --ckpt "$CKPT" --out "$OUTDIR"

echo "[run_evaluate] done. Metrics/calibration written under $OUTDIR."
