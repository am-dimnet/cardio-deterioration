#!/usr/bin/env bash
# run_extract.sh -- MIMIC-IV cohort extraction (Table 12 flow) + endpoint labels.
#
# Thin wrapper around am_dimnet.data.cohort.extract_cohort / endpoints, driven
# by configs/mimic.yaml. Requires PhysioNet credentialing and a populated
# MIMIC-IV database (see docs/data_access.md). NOT part of the smoke test.
#
# Usage:
#   scripts/run_extract.sh [CONFIG]
# Env:
#   MIMIC_DB_HOST / MIMIC_DB_USER / MIMIC_DB_PASSWORD  (see configs/mimic.yaml)
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${1:-configs/mimic.yaml}"

echo "[run_extract] repo root : $REPO_ROOT"
echo "[run_extract] config    : $CONFIG"
echo "[run_extract] extracting candidate ICU stays + waveform linkage ..."

python -m am_dimnet.data.cohort --config "$CONFIG"

echo "[run_extract] done. Cohort CSV + flow log written under paths.cohort_csv."
