#!/usr/bin/env bash
# run_preprocess.sh -- Signal preprocessing, feature extraction, and windowing.
#
# Bandpasses ECG/PPG/PCG (Table 4 bands), segments 5-min windows (step 60 s),
# computes HRV (Eq. 5) + activity-proxy (Eq. 7-9) + SQI (Eq. 10) features, and
# assembles batch-contract window records via
# am_dimnet.data.preprocessing.build_window_record. Then builds the
# patient-disjoint train/val/test split (am_dimnet.data.splits.patient_split).
# NOT part of the smoke test.
#
# Usage:
#   scripts/run_preprocess.sh [CONFIG]
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${1:-configs/mimic.yaml}"

echo "[run_preprocess] repo root : $REPO_ROOT"
echo "[run_preprocess] config    : $CONFIG"
echo "[run_preprocess] preprocessing signals -> windows -> features ..."

python -m am_dimnet.data.preprocessing --config "$CONFIG"

echo "[run_preprocess] building patient-disjoint splits ..."
python -m am_dimnet.data.splits --config "$CONFIG"

echo "[run_preprocess] done. Windows under paths.windows_dir, splits at paths.splits_json."
