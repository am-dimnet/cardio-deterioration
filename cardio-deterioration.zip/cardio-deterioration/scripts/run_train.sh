#!/usr/bin/env bash
# run_train.sh -- Train AM-DiMNet across the 5 seeds (train.seeds).
#
# Wraps am_dimnet.train (AdamW, early stopping on val AUROC, modality-dropout
# augmentation, GRL lambda warmup). One checkpoint per seed is written under
# paths.checkpoints_dir. NOT part of the smoke test.
#
# Usage:
#   scripts/run_train.sh [CONFIG] [SEED ...]
# Examples:
#   scripts/run_train.sh                         # default config, all 5 seeds
#   scripts/run_train.sh configs/mimic.yaml      # mimic config, all 5 seeds
#   scripts/run_train.sh configs/mimic.yaml 42   # single seed
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

CONFIG="${1:-configs/default.yaml}"
shift || true
SEEDS=("$@")

echo "[run_train] repo root : $REPO_ROOT"
echo "[run_train] config    : $CONFIG"

if [ "${#SEEDS[@]}" -eq 0 ]; then
  echo "[run_train] training all seeds from ${CONFIG} (train.seeds) ..."
  python -m am_dimnet.train --config "$CONFIG"
else
  for seed in "${SEEDS[@]}"; do
    echo "[run_train] training seed ${seed} ..."
    python -m am_dimnet.train --config "$CONFIG" --seed "$seed"
  done
fi

echo "[run_train] done. Checkpoints under paths.checkpoints_dir."
