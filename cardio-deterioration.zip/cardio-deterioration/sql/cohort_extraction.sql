-- =====================================================================
-- AM-DiMNet : MIMIC-IV waveform-linked cohort extraction
-- ---------------------------------------------------------------------
-- Produces one row per CANDIDATE ICU stay together with the boolean /
-- quantitative flags for every Table 12 exclusion criterion. The Python
-- driver (am_dimnet/data/cohort.py :: extract_cohort) applies the seven
-- Table 12 exclusions IN ORDER and logs the count removed at each step,
-- so this query stays auditable and the flow diagram is reconstructible.
--
-- DATA USE: MIMIC-IV is credentialed PhysioNet data. Do NOT commit any
-- extracted rows. Run only against your own licensed instance.
--
-- Parameterisation (bind via your driver; psycopg2 / SQLAlchemy names shown
-- as :name — rename to %(name)s or @name for your dialect):
--   :window_min     observation window length (minutes)   [default 5]
--   :gap_h          prediction gap  Delta_g (hours)        [default 1.5]
--   :horizon_h      prediction horizon Delta_p (hours)     [default 24]
--   :min_seconds    minimum monitored duration (seconds)   [default 300]
--   :rr_quality_min minimum usable-RR fraction             [default 0.7]
--   :align_tol_s    max |ECG-PPG| start skew (seconds)     [default 2]
--
-- Schemas assumed: mimiciv_icu, mimiciv_hosp, and a waveform-link table
-- `mimiciv_wdb.waveform_link` (subject_id, stay_id, has_ecg, has_ppg,
-- has_pcg, wf_start, wf_end, ecg_start, ppg_start, usable_rr_fraction).
-- Adjust the `wf` CTE to match your waveform-index table.
-- =====================================================================

WITH
-- ---------------------------------------------------------------------
-- Base ICU stays (denominator of the Table 12 flow diagram).
-- ---------------------------------------------------------------------
base_stays AS (
    SELECT
        icu.subject_id,
        icu.hadm_id,
        icu.stay_id,
        icu.intime,
        icu.outtime,
        EXTRACT(EPOCH FROM (icu.outtime - icu.intime)) AS stay_seconds
    FROM mimiciv_icu.icustays icu
    WHERE icu.outtime IS NOT NULL
      AND icu.outtime > icu.intime
),

-- ---------------------------------------------------------------------
-- Table 12 / step 1 + 2: waveform linkage and ECG/PPG channel presence.
-- One row per stay from the waveform index; flags surfaced for the driver.
-- ---------------------------------------------------------------------
wf AS (
    SELECT
        w.stay_id,
        BOOL_OR(TRUE)                        AS has_waveform,   -- step 1
        BOOL_OR(w.has_ecg)                   AS has_ecg,        -- step 2
        BOOL_OR(w.has_ppg)                   AS has_ppg,        -- step 2
        BOOL_OR(COALESCE(w.has_pcg, FALSE))  AS has_pcg,        -- optional PCG branch
        MIN(w.wf_start)                      AS wf_start,
        MAX(w.wf_end)                        AS wf_end,
        -- step 3: total monitored waveform seconds
        SUM(EXTRACT(EPOCH FROM (w.wf_end - w.wf_start))) AS monitored_seconds,
        -- step 4: fraction of RR intervals passing quality gate (Eq. 5 inputs)
        AVG(w.usable_rr_fraction)            AS rr_quality,
        -- step 5: |ECG start - PPG start| temporal skew (seconds)
        MIN(ABS(EXTRACT(EPOCH FROM (w.ecg_start - w.ppg_start)))) AS align_offset_s
    FROM mimiciv_wdb.waveform_link w
    GROUP BY w.stay_id
),

-- ---------------------------------------------------------------------
-- Endpoint event times per stay (Table 1 composite; see endpoint_labeling.sql
-- for the full per-component extraction). Here we only need, per stay, the
-- FIRST endpoint time to test steps 6 & 7 relative to the first window.
-- We inline a compact union of the Table 1 item ids so the cohort query is
-- self-contained; endpoint_labeling.sql is the authoritative per-component
-- version used for actual window labels.
-- ---------------------------------------------------------------------
endpoint_events AS (
    -- vasoactive escalation: norepi 221906, epi 221289, dopamine 221662,
    -- dobutamine 221653, vasopressin 222315  |  acute HF IV furosemide 221794
    SELECT ie.stay_id, ie.starttime AS event_time
    FROM mimiciv_icu.inputevents ie
    WHERE ie.itemid IN (221906, 221289, 221662, 221653, 222315, 221794, 225152, 228340)

    UNION ALL
    -- cardiac arrest / CPR (225466, 225468, 224385) and
    -- malignant arrhythmia charted event 224168 (chartevents)
    SELECT ce.stay_id, ce.charttime AS event_time
    FROM mimiciv_icu.chartevents ce
    WHERE ce.itemid IN (225466, 225468, 224385, 224168)

    UNION ALL
    -- procedure-based: arrest/CPR 225466/225468, malignant arrhythmia
    -- cardioversion 225448, urgent CV intervention 225752/225459/225802
    SELECT pe.stay_id, pe.starttime AS event_time
    FROM mimiciv_icu.procedureevents pe
    WHERE pe.itemid IN (225466, 225468, 225448, 225752, 225459, 225802)

    UNION ALL
    -- death (admissions.deathtime scoped to the stay)
    SELECT icu.stay_id, adm.deathtime AS event_time
    FROM mimiciv_icu.icustays icu
    JOIN mimiciv_hosp.admissions adm ON adm.hadm_id = icu.hadm_id
    WHERE adm.deathtime IS NOT NULL
),

first_endpoint AS (
    SELECT stay_id, MIN(event_time) AS first_endpoint_time
    FROM endpoint_events
    GROUP BY stay_id
),

-- ---------------------------------------------------------------------
-- Assemble candidate rows with all Table 12 flags.
--   window_start_first = intime + window_min           (first labelable point)
--   Step 6 pre_existing_endpoint : endpoint at/before the first window end.
--   Step 7 endpoint_in_gap       : endpoint inside the gap window
--                                  (window_end, window_end + gap_h].
-- ---------------------------------------------------------------------
candidates AS (
    SELECT
        b.subject_id,
        b.hadm_id,
        b.stay_id,
        b.intime,
        b.outtime,
        b.stay_seconds,
        COALESCE(wf.has_waveform, FALSE)                    AS has_waveform,
        COALESCE(wf.has_ecg, FALSE)                         AS has_ecg,
        COALESCE(wf.has_ppg, FALSE)                         AS has_ppg,
        COALESCE(wf.has_pcg, FALSE)                         AS has_pcg,
        COALESCE(wf.monitored_seconds, 0)                   AS monitored_seconds,
        wf.rr_quality                                       AS rr_quality,
        wf.align_offset_s                                   AS align_offset_s,
        fe.first_endpoint_time,
        -- first observation window end = intime + window_min minutes
        (b.intime + make_interval(mins => :window_min))     AS first_window_end,
        -- Step 6: endpoint already present by the first window end.
        (fe.first_endpoint_time IS NOT NULL
         AND fe.first_endpoint_time
             <= b.intime + make_interval(mins => :window_min))
                                                            AS endpoint_before_start,
        -- Step 7: endpoint inside the prediction gap (window_end, window_end+gap].
        (fe.first_endpoint_time IS NOT NULL
         AND fe.first_endpoint_time
             >  b.intime + make_interval(mins => :window_min)
         AND fe.first_endpoint_time
             <= b.intime + make_interval(mins => :window_min)
                        + make_interval(hours => :gap_h))
                                                            AS endpoint_in_gap
    FROM base_stays b
    LEFT JOIN wf           ON wf.stay_id = b.stay_id
    LEFT JOIN first_endpoint fe ON fe.stay_id = b.stay_id
)

-- ---------------------------------------------------------------------
-- Return every candidate + flags. The Python driver applies the ordered
-- Table 12 exclusions and produces the flow log. (We deliberately do NOT
-- filter here so the driver can count removals per step.)
-- ---------------------------------------------------------------------
SELECT
    subject_id,
    hadm_id,
    stay_id,
    intime,
    outtime,
    stay_seconds,
    has_waveform,
    has_ecg,
    has_ppg,
    has_pcg,
    monitored_seconds,
    rr_quality,
    align_offset_s,
    first_endpoint_time,
    first_window_end,
    endpoint_before_start,
    endpoint_in_gap
FROM candidates
ORDER BY subject_id, stay_id;
