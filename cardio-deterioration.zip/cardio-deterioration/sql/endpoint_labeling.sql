-- =====================================================================
-- AM-DiMNet : composite deterioration endpoint extraction (Table 1)
-- ---------------------------------------------------------------------
-- Returns ONE ROW PER ENDPOINT-COMPONENT EVENT for the cohort stays, tagged
-- with the component name, source table, itemid, and event time. The Python
-- labeler (am_dimnet/data/endpoints.py :: label_window / Eq. 2-3) consumes
-- these rows and marks a window positive iff >=1 event falls inside
--     [window_end + gap_h, window_end + gap_h + horizon_h].
--
-- Each CTE below implements exactly one Table 1 component using the EXACT
-- itemids from SPEC Section 5. Comments name every id.
--
-- DATA USE: credentialed MIMIC-IV only. Do NOT commit extracted rows.
--
-- Parameterisation (bind via your driver):
--   :stay_ids   array/tuple of cohort stay_ids to restrict extraction (optional;
--               omit the WHERE ... = ANY(:stay_ids) clauses to extract all).
--
-- Schemas: mimiciv_icu (chartevents, procedureevents, inputevents, icustays),
--          mimiciv_hosp (admissions, patients, prescriptions).
-- =====================================================================

WITH
-- ---------------------------------------------------------------------
-- Component 1 : Cardiac arrest / CPR
--   225466 = Non-invasive / manual CPR          (procedureevents)
--   225468 = Unplanned CPR / defibrillation      (procedureevents / chartevents)
--   224385 = Intubation / arrest-associated event (chartevents)
-- ---------------------------------------------------------------------
cardiac_arrest_cpr AS (
    SELECT stay_id,
           'cardiac_arrest_cpr'::text AS component,
           'procedureevents'::text    AS source_table,
           itemid,
           starttime AS event_time
    FROM mimiciv_icu.procedureevents
    WHERE itemid IN (225466, 225468, 224385)
    UNION ALL
    SELECT stay_id,
           'cardiac_arrest_cpr'::text AS component,
           'chartevents'::text        AS source_table,
           itemid,
           charttime AS event_time
    FROM mimiciv_icu.chartevents
    WHERE itemid IN (225466, 225468, 224385)
),

-- ---------------------------------------------------------------------
-- Component 2 : Death
--   admissions.deathtime (in-hospital death), patients.dod (date of death).
--   Scoped to the ICU stay via icustays.intime/outtime window.
-- ---------------------------------------------------------------------
death AS (
    SELECT icu.stay_id,
           'death'::text        AS component,
           'admissions'::text   AS source_table,
           NULL::integer        AS itemid,
           adm.deathtime        AS event_time
    FROM mimiciv_icu.icustays icu
    JOIN mimiciv_hosp.admissions adm ON adm.hadm_id = icu.hadm_id
    WHERE adm.deathtime IS NOT NULL
    UNION ALL
    SELECT icu.stay_id,
           'death'::text        AS component,
           'patients'::text     AS source_table,
           NULL::integer        AS itemid,
           -- patients.dod is a date; treat midnight as the event instant.
           (pat.dod::timestamp) AS event_time
    FROM mimiciv_icu.icustays icu
    JOIN mimiciv_hosp.patients pat ON pat.subject_id = icu.subject_id
    WHERE pat.dod IS NOT NULL
      AND pat.dod::timestamp >= icu.intime
      AND pat.dod::timestamp <= icu.outtime + make_interval(hours => 24)
),

-- ---------------------------------------------------------------------
-- Component 3 : Vasoactive / inotrope escalation (inputevents)
--   221906 = norepinephrine   221289 = epinephrine   221662 = dopamine
--   221653 = dobutamine       222315 = vasopressin
-- ---------------------------------------------------------------------
vasoactive_escalation AS (
    SELECT stay_id,
           'vasoactive_escalation'::text AS component,
           'inputevents'::text           AS source_table,
           itemid,
           starttime AS event_time
    FROM mimiciv_icu.inputevents
    WHERE itemid IN (221906, 221289, 221662, 221653, 222315)
),

-- ---------------------------------------------------------------------
-- Component 4 : Acute heart-failure treatment
--   221794 = IV furosemide (inputevents)  225152 = inotrope/afterload agent
--   228340 = acute HF pharmacologic support
--   Corroborated by IV diuretic orders in prescriptions.
-- ---------------------------------------------------------------------
acute_hf AS (
    SELECT stay_id,
           'acute_hf'::text     AS component,
           'inputevents'::text  AS source_table,
           itemid,
           starttime AS event_time
    FROM mimiciv_icu.inputevents
    WHERE itemid IN (221794, 225152, 228340)
    UNION ALL
    SELECT icu.stay_id,
           'acute_hf'::text      AS component,
           'prescriptions'::text AS source_table,
           NULL::integer         AS itemid,
           pr.starttime          AS event_time
    FROM mimiciv_hosp.prescriptions pr
    JOIN mimiciv_icu.icustays icu ON icu.hadm_id = pr.hadm_id
    WHERE lower(pr.drug) LIKE '%furosemide%'
      AND lower(COALESCE(pr.route, '')) IN ('iv', 'iv drip', 'iv bolus')
      AND pr.starttime BETWEEN icu.intime AND icu.outtime
),

-- ---------------------------------------------------------------------
-- Component 5 : Malignant / haemodynamically-significant arrhythmia
--   224168 = arrhythmia charted event  (chartevents)
--   225448 = cardioversion             (procedureevents)
--   225468 = defibrillation / CPR event
-- ---------------------------------------------------------------------
malignant_arrhythmia AS (
    SELECT stay_id,
           'malignant_arrhythmia'::text AS component,
           'chartevents'::text          AS source_table,
           itemid,
           charttime AS event_time
    FROM mimiciv_icu.chartevents
    WHERE itemid IN (224168, 225448, 225468)
    UNION ALL
    SELECT stay_id,
           'malignant_arrhythmia'::text AS component,
           'procedureevents'::text      AS source_table,
           itemid,
           starttime AS event_time
    FROM mimiciv_icu.procedureevents
    WHERE itemid IN (224168, 225448, 225468)
),

-- ---------------------------------------------------------------------
-- Component 6 : Urgent cardiovascular intervention (procedureevents)
--   225752 = arterial line / urgent invasive access
--   225459 = chest tube / pericardial drainage
--   225802 = dialysis / mechanical circulatory support initiation
-- ---------------------------------------------------------------------
urgent_cv_intervention AS (
    SELECT stay_id,
           'urgent_cv_intervention'::text AS component,
           'procedureevents'::text        AS source_table,
           itemid,
           starttime AS event_time
    FROM mimiciv_icu.procedureevents
    WHERE itemid IN (225752, 225459, 225802)
),

-- ---------------------------------------------------------------------
-- Union of all components (the composite endpoint, Table 1 / Eq. 3).
-- ---------------------------------------------------------------------
all_events AS (
    SELECT * FROM cardiac_arrest_cpr
    UNION ALL SELECT * FROM death
    UNION ALL SELECT * FROM vasoactive_escalation
    UNION ALL SELECT * FROM acute_hf
    UNION ALL SELECT * FROM malignant_arrhythmia
    UNION ALL SELECT * FROM urgent_cv_intervention
)

SELECT
    e.stay_id,
    e.component,
    e.source_table,
    e.itemid,
    e.event_time,
    -- event time in hours since ICU admission, matching the reference clock
    -- used by label_window() / first_qualifying_endpoint() (Eq. 2-3).
    EXTRACT(EPOCH FROM (e.event_time - icu.intime)) / 3600.0 AS event_hours_from_intime
FROM all_events e
JOIN mimiciv_icu.icustays icu ON icu.stay_id = e.stay_id
WHERE e.event_time IS NOT NULL
  -- Optional cohort restriction; remove this predicate to extract all stays.
  -- AND e.stay_id = ANY(:stay_ids)
ORDER BY e.stay_id, e.event_time, e.component;
