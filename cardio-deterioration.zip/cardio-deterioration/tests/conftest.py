"""Shared pytest fixtures for the AM-DiMNet test suite.

Everything runs on CPU with a tiny synthetic cohort, so the whole suite finishes
in a few seconds and needs no external data.
"""
from __future__ import annotations

import os
import sys

import pytest
import torch

# Make the repo root importable when pytest is invoked from anywhere.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from am_dimnet.config import Config  # noqa: E402
from am_dimnet.data.synthetic import make_loaders  # noqa: E402
from am_dimnet.models.am_dimnet import AMDiMNet  # noqa: E402


@pytest.fixture(scope="session")
def config() -> Config:
    return Config.default()


@pytest.fixture(scope="session")
def loaders(config):
    """Patient-disjoint train/val/test loaders over a small synthetic cohort."""
    torch.manual_seed(0)
    return make_loaders(
        config,
        n_patients=48,
        windows_per_patient=(18, 30),
        seed=13,
        batch_size=32,
    )


@pytest.fixture(scope="session")
def batch(loaders):
    return next(iter(loaders["train"]))


@pytest.fixture(scope="session")
def model(config):
    torch.manual_seed(0)
    m = AMDiMNet(config)
    m.eval()
    return m
