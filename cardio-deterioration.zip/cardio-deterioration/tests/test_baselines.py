"""Every baseline consumes the batch contract and emits a [B] risk logit / prob."""
from __future__ import annotations

import numpy as np
import pytest
import torch

from am_dimnet.baselines import classical, cnn, fusion_baselines, foundation


NEURAL_BASELINES = [
    ("ECGCNN", cnn.ECGCNN),
    ("PPGCNN", cnn.PPGCNN),
    ("EarlyFusion", fusion_baselines.EarlyFusion),
    ("LateFusion", fusion_baselines.LateFusion),
    ("AttentionFusion", fusion_baselines.AttentionFusion),
    ("ModalityDropoutFusion", fusion_baselines.ModalityDropoutFusion),
    ("AdversarialDeconfounding", fusion_baselines.AdversarialDeconfounding),
    ("MomentBaseline", foundation.MomentBaseline),
    ("NormWearBaseline", foundation.NormWearBaseline),
]


@pytest.mark.parametrize("name,ctor", NEURAL_BASELINES, ids=[n for n, _ in NEURAL_BASELINES])
def test_neural_baseline_forward(config, batch, name, ctor):
    torch.manual_seed(0)
    model = ctor(config)
    model.eval()
    with torch.no_grad():
        out = model(batch)
    logit = out if torch.is_tensor(out) else out.get("logit", out.get("prob"))
    B = batch["y"].shape[0]
    assert logit.shape[0] == B
    assert torch.isfinite(logit).all()


@pytest.mark.filterwarnings("ignore::RuntimeWarning")  # benign LBFGS matmul warnings on tiny data
@pytest.mark.parametrize("cls", [classical.LogRegBaseline, classical.RandomForestBaseline])
def test_classical_baseline_fit_predict(loaders, cls):
    model = cls()
    model.fit(loaders["train"])
    for b in loaders["test"]:
        p = model.predict_proba(b)
        assert p.shape[0] == b["y"].shape[0]
        assert np.all(p >= 0.0) and np.all(p <= 1.0)
        logit = model.predict_logits(b)
        assert logit.shape[0] == b["y"].shape[0]
        break
