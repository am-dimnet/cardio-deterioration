"""Config defaults and package constants must match the manuscript (Table 4,
loss-weights equation, SPEC Section 0)."""
from __future__ import annotations

from am_dimnet import constants as K
from am_dimnet.config import Config


def test_config_defaults_match_table4():
    c = Config.default()
    assert c.model.embed_dim == 128
    assert c.model.latent_dim == 32
    assert c.train.batch_size == 96
    assert abs(c.train.lr - 7.5e-4) < 1e-12
    assert abs(c.train.weight_decay - 1.2e-4) < 1e-12
    assert abs(c.model.dropout - 0.27) < 1e-9
    assert abs(c.train.modality_dropout - 0.18) < 1e-9
    assert c.train.max_epochs == 120
    assert c.train.patience == 16
    assert len(c.train.seeds) == 5


def test_loss_weights_match_manuscript():
    c = Config.default()
    assert abs(c.loss.lambda_hrv - 0.35) < 1e-9
    assert abs(c.loss.lambda_morph - 0.28) < 1e-9
    assert abs(c.loss.lambda_act - 0.20) < 1e-9
    assert abs(c.loss.lambda_adv - 0.15) < 1e-9
    assert abs(c.loss.lambda_orth - 0.06) < 1e-9
    assert abs(c.loss.lambda_cal - 0.08) < 1e-9


def test_config_roundtrip():
    c = Config.default()
    d = c.to_dict()
    assert d["model"]["embed_dim"] == 128
    assert d["loss"]["lambda_hrv"] == 0.35


def test_constants():
    assert K.MODALITIES == ["ecg", "ppg", "pcg", "proxy", "hrv", "clinical"]
    assert K.FACTORS == ["auto", "morph", "act", "base", "noise"]
    assert K.RISK_FACTORS == ["auto", "morph", "base"]
    assert set(K.RISK_FACTORS).issubset(set(K.FACTORS))
    assert len(K.HRV_FEATURES) == 10
    assert len(K.PROXY_COMPONENTS) == 4
    assert K.N_ACTIVITY_CLASSES == 3
    assert K.ECE_BINS == 15
    assert tuple(K.PROXY_TERTILES) == (0.34, 0.61)
