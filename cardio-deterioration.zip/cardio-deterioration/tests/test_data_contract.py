"""The synthetic cohort must honour the batch dict contract (SPEC Section 2),
patient-disjoint splits, target prevalence, feature standardisation, and the
modality-dropout behaviour."""
from __future__ import annotations

import numpy as np
import torch

from am_dimnet import constants as K
from am_dimnet.config import Config
from am_dimnet.data.synthetic import SyntheticCohort, make_loaders


def test_batch_keys_shapes_dtypes(config, batch):
    d = config.data
    B = batch["y"].shape[0]
    assert batch["ecg"].shape == (B, 1, d.ecg_len)
    assert batch["ppg"].shape == (B, 1, d.ppg_len)
    assert batch["pcg"].shape == (B, 1, d.pcg_mels, d.pcg_frames)
    assert batch["proxy"].shape == (B, 4)
    assert batch["hrv"].shape == (B, 10)
    assert batch["clinical"].shape == (B, d.clinical_dim)
    assert batch["sqi"].shape == (B, len(K.MODALITIES))
    assert batch["mask"].shape == (B, len(K.MODALITIES))
    assert batch["morph_target"].shape == (B, d.morph_dim)
    assert batch["y"].dtype == torch.float32
    assert batch["activity"].dtype == torch.int64
    assert batch["patient_id"].dtype == torch.int64


def test_mask_and_sqi_ranges(batch):
    m = batch["mask"]
    assert set(torch.unique(m).tolist()).issubset({0.0, 1.0})
    ecg_col, ppg_col = K.MODALITIES.index("ecg"), K.MODALITIES.index("ppg")
    assert torch.all(m[:, ecg_col] == 1.0)  # core waveforms never dropped
    assert torch.all(m[:, ppg_col] == 1.0)
    assert torch.all(batch["sqi"] >= 0.0) and torch.all(batch["sqi"] <= 1.0)
    assert set(torch.unique(batch["activity"]).tolist()).issubset({0, 1, 2})


def test_patient_disjoint_splits(loaders):
    def pids(loader):
        out = set()
        for b in loader:
            out.update(b["patient_id"].tolist())
        return out

    tr, va, te = pids(loaders["train"]), pids(loaders["val"]), pids(loaders["test"])
    assert tr and va and te
    assert tr.isdisjoint(va)
    assert tr.isdisjoint(te)
    assert va.isdisjoint(te)


def test_prevalence_near_target(config):
    loaders = make_loaders(config, n_patients=90, windows_per_patient=(24, 44), seed=3)
    ys = np.concatenate([b["y"].numpy() for b in loaders["train"]])
    assert 0.15 < ys.mean() < 0.29  # target prevalence 0.219, tolerance for a finite cohort


def test_hrv_standardised_after_make_loaders(loaders):
    hj = K.MODALITIES.index("hrv")
    rows = []
    for b in loaders["train"]:
        present = b["mask"][:, hj] > 0.5
        rows.append(b["hrv"][present].numpy())
    hrv = np.concatenate(rows, axis=0)
    per_feature_std = hrv.std(axis=0)
    # train-set z-scored HRV: per-feature std ~ 1 (not on a raw physiological scale)
    assert 0.5 < float(per_feature_std.mean()) < 2.0


def test_raw_cohort_hrv_is_unscaled(config):
    """Regression guard: without make_loaders the HRV is on a raw physiological
    scale (the reason feature standardisation is required)."""
    ds = SyntheticCohort(config, n_patients=12, windows_per_patient=(10, 16), seed=1)
    hrv = np.stack([ds[i]["hrv"].numpy() for i in range(len(ds))], axis=0)
    assert hrv.std() > 5.0  # raw MeanNN/LF/HF etc. dominate the scale


def test_modality_dropout_fraction(config):
    loaders = make_loaders(config, n_patients=60, windows_per_patient=(20, 36), seed=7)
    any_dropped = []
    for b in loaders["train"]:
        any_dropped.append((b["mask"] < 0.5).any(dim=1).float())
    frac = torch.cat(any_dropped).mean().item()
    assert 0.05 < frac < 0.35  # ~18% windows drop exactly one non-core modality
