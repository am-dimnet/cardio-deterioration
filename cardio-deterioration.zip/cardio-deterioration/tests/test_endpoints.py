"""Endpoint definition must match Table 1 (item IDs) and the prediction-interval
labelling rule (Eq. 2-3)."""
from __future__ import annotations

from am_dimnet.data.endpoints import (
    ENDPOINT_COMPONENTS,
    EndpointEvent,
    first_qualifying_endpoint,
    label_window,
)

# The exact 16 MIMIC-IV item IDs in Table 1 of the manuscript.
EXPECTED_ITEMIDS = {
    221906, 221289, 221662, 221653, 222315,  # vasoactive escalation
    221794, 225152, 228340,                   # acute heart failure
    224168, 225448, 225468,                   # malignant arrhythmia
    225752, 225459, 225802,                   # urgent CV intervention
    225466, 224385,                           # cardiac arrest / CPR (225468 shared above)
}


def _all_itemids(obj, acc):
    if isinstance(obj, dict):
        for v in obj.values():
            _all_itemids(v, acc)
    elif isinstance(obj, (list, tuple, set)):
        for v in obj:
            _all_itemids(v, acc)
    elif isinstance(obj, int):
        acc.add(obj)


def test_components_present():
    assert set(ENDPOINT_COMPONENTS.keys()) == {
        "cardiac_arrest_cpr", "death", "vasoactive_escalation",
        "acute_hf", "malignant_arrhythmia", "urgent_cv_intervention",
    }


def test_all_table1_itemids_present():
    found = set()
    _all_itemids(ENDPOINT_COMPONENTS, found)
    assert EXPECTED_ITEMIDS.issubset(found), EXPECTED_ITEMIDS - found


def test_label_window_inside_interval():
    # window ends at t=10h; interval = [10+1.5, 10+1.5+24] = [11.5, 35.5]
    ev_inside = [EndpointEvent(component="vasoactive_escalation", time_h=20.0, itemid=221906)]
    assert label_window(None, 10.0, gap_h=1.5, horizon_h=24.0, events=ev_inside) == 1


def test_label_window_outside_interval():
    # before the gap (in the blanking window) -> not labelled positive
    ev_gap = [EndpointEvent(component="malignant_arrhythmia", time_h=10.5, itemid=224168)]
    assert label_window(None, 10.0, gap_h=1.5, horizon_h=24.0, events=ev_gap) == 0
    # after the horizon -> not labelled positive
    ev_late = [EndpointEvent(component="death", time_h=40.0, itemid=None)]
    assert label_window(None, 10.0, gap_h=1.5, horizon_h=24.0, events=ev_late) == 0


def test_first_qualifying_endpoint_returns_earliest():
    events = [
        EndpointEvent(component="acute_hf", time_h=30.0, itemid=221794),
        EndpointEvent(component="vasoactive_escalation", time_h=15.0, itemid=221906),
    ]
    res = first_qualifying_endpoint(10.0, gap_h=1.5, horizon_h=24.0, events=events)
    assert res is not None
    component, time_h = res
    assert component == "vasoactive_escalation"
    assert abs(time_h - 15.0) < 1e-9
