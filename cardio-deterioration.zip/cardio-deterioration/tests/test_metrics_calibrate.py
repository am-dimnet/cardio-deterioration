"""Metric correctness on constructed inputs (deterministic, not model-dependent):
event-frequency ECE (Eq. 35), AUROC, operating point, patient aggregation, and
temperature calibration."""
from __future__ import annotations

import numpy as np

from am_dimnet import metrics as M
from am_dimnet.calibrate import TemperatureScaler, select_operating_threshold


def test_ece_perfect_vs_miscalibrated():
    rng = np.random.default_rng(0)
    y = (rng.random(2000) < 0.3).astype(float)
    base = y.mean()
    # Constant prediction equal to the empirical event rate -> ECE ~ 0.
    ece_good = M.expected_calibration_error(np.full_like(y, base), y, n_bins=15)
    assert ece_good < 0.05
    # Constant, badly-miscalibrated prediction -> ECE ~ |0.9 - base|.
    ece_bad = M.expected_calibration_error(np.full_like(y, 0.9), y, n_bins=15)
    assert abs(ece_bad - abs(0.9 - base)) < 0.05
    assert ece_bad > ece_good


def test_auroc_perfect_ranker():
    y = np.array([0, 0, 0, 1, 1, 1], dtype=float)
    prob = np.array([0.1, 0.2, 0.3, 0.7, 0.8, 0.9])
    assert abs(M.auroc(prob, y) - 1.0) < 1e-9
    assert 0.0 <= M.auprc(prob, y) <= 1.0
    assert 0.0 <= M.brier(prob, y) <= 1.0


def test_operating_point_ranges_and_separation():
    y = np.array([0, 0, 0, 0, 1, 1, 1, 1], dtype=float)
    prob = np.array([0.1, 0.15, 0.2, 0.25, 0.75, 0.8, 0.85, 0.9])
    stats = M.operating_point_stats(prob, y, threshold=0.5)
    for key in ["sens", "spec", "ppv", "npv", "fpr"]:
        assert 0.0 <= stats[key] <= 1.0
    assert stats["sens"] == 1.0 and stats["spec"] == 1.0


def test_patient_top_decile_shape():
    prob = np.array([0.2, 0.9, 0.1, 0.8, 0.5, 0.4])
    pid = np.array([0, 0, 1, 1, 2, 2])
    Y, out_pid = M.patient_top_decile(prob, pid)
    assert len(Y) == 3 and len(out_pid) == 3
    assert set(out_pid.tolist()) == {0, 1, 2}


def test_temperature_scaler_and_threshold():
    rng = np.random.default_rng(1)
    logits = rng.normal(0, 2, size=500)
    y = (1 / (1 + np.exp(-logits)) > rng.random(500)).astype(float)
    ts = TemperatureScaler().fit(logits, y)
    probs = ts.transform(logits)
    assert probs.shape == logits.shape
    assert np.all(probs > 0) and np.all(probs < 1)
    thr = select_operating_threshold(probs, y, target="youden")
    assert 0.0 <= float(thr) <= 1.0


def test_bootstrap_ci_structure():
    rng = np.random.default_rng(2)
    prob = rng.random(300)
    y = (prob > 0.5).astype(float)
    pid = rng.integers(0, 40, size=300)
    ci = M.bootstrap_ci(M.auroc, prob, y, pid, n=50, seed=0)
    assert "lower" in ci and "upper" in ci
    assert ci["lower"] <= ci["upper"]
