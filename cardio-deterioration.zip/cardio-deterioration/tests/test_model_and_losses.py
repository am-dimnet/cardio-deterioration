"""AMDiMNet forward-pass output contract, loss magnitudes (regression guard for
the HRV-scaling bug), single-batch overfitting, and gate masking."""
from __future__ import annotations

import torch

from am_dimnet import constants as K
from am_dimnet.models.am_dimnet import AMDiMNet
from am_dimnet.models.losses import AMDiMNetLoss


def test_forward_output_contract(config, model, batch):
    B = batch["y"].shape[0]
    out = model(batch)
    assert out["logit"].shape == (B,)
    assert out["prob"].shape == (B,)
    assert torch.all(out["prob"] >= 0) and torch.all(out["prob"] <= 1)
    assert out["fused"].shape == (B, config.model.embed_dim)
    for f in K.FACTORS:
        assert out["z"][f].shape == (B, config.model.latent_dim)
    assert out["recon_hrv"].shape == (B, 10)
    assert out["recon_morph"].shape == (B, config.data.morph_dim)
    assert out["act_logits"].shape == (B, K.N_ACTIVITY_CLASSES)
    assert out["adv_auto_logits"].shape == (B, K.N_ACTIVITY_CLASSES)
    assert out["adv_morph_logits"].shape == (B, K.N_ACTIVITY_CLASSES)
    assert torch.isfinite(out["logit"]).all()


def test_loss_parts_finite_and_well_scaled(config, model, batch):
    out = model(batch)
    total, parts = AMDiMNetLoss(config)(out, batch)
    for name in ["L_risk", "L_hrv", "L_morph", "L_act", "L_adv", "L_orth", "L_cal"]:
        assert name in parts
        v = float(parts[name])
        assert v == v and v < 1e3  # finite
    # Regression guard: after HRV standardisation no single term explodes and the
    # weighted total stays O(1)-O(10) rather than the ~40000 seen with raw HRV.
    assert float(parts["L_hrv"]) < 50.0
    assert float(total) < 50.0


def test_single_batch_overfit_reduces_risk(config, batch):
    torch.manual_seed(0)
    model = AMDiMNet(config)
    model.train()
    lossfn = AMDiMNetLoss(config)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
    risks = []
    for _ in range(25):
        opt.zero_grad()
        out = model(batch)
        total, parts = lossfn(out, batch)
        total.backward()
        opt.step()
        risks.append(float(parts["L_risk"]))
    assert sum(risks[-5:]) / 5 < sum(risks[:5]) / 5  # primary objective decreases


def test_gate_zeroes_masked_modality(config, model, batch):
    b = {k: (v.clone() if torch.is_tensor(v) else v) for k, v in batch.items()}
    pcg_col = K.MODALITIES.index("pcg")
    b["mask"][:, pcg_col] = 0.0
    b["sqi"][:, pcg_col] = 0.0
    b["pcg"] = torch.zeros_like(b["pcg"])
    out = model(b)
    alpha_pcg = out["alpha"]["pcg"]
    assert float(alpha_pcg.abs().max()) < 1e-4  # masked modality gets zero gate weight
