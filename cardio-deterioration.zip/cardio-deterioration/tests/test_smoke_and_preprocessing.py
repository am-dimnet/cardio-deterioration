"""End-to-end smoke test (reused as a pytest case) and preprocessing utilities,
including the training-set feature standardiser that keeps L_hrv well-scaled."""
from __future__ import annotations

import numpy as np

from am_dimnet.data.preprocessing import FeatureStandardizer, zscore
from am_dimnet.smoke_test import run_smoke_test


def test_end_to_end_smoke():
    # Builds a synthetic cohort, runs forward + a few optimiser steps + calibration
    # + the full metric suite, asserting internally. Raises on any failure.
    run_smoke_test(verbose=False)


def test_zscore():
    x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    z = zscore(x)
    assert abs(float(z.mean())) < 1e-6
    assert abs(float(z.std()) - 1.0) < 1e-6


def test_feature_standardizer_fit_transform_roundtrip(tmp_path):
    rng = np.random.default_rng(0)
    records = [
        {
            "hrv": np.array([800.0, 50.0, 40.0, 10.0, 500.0, 300.0, 1.6, 25.0, 55.0, 1.2])
            + rng.normal(0, 20, size=10),
            "clinical": rng.normal(0, 1, size=8),
            "proxy": rng.random(4),
        }
        for _ in range(64)
    ]
    fs = FeatureStandardizer(keys=("hrv", "clinical", "proxy")).fit(records)
    t = fs.transform_record(records[0])
    assert t["hrv"].shape == (10,)
    # A large full training matrix standardises to ~unit variance per feature.
    mat = np.stack([fs.transform_vector("hrv", r["hrv"]) for r in records], axis=0)
    assert 0.7 < float(mat.std(axis=0).mean()) < 1.4

    path = str(tmp_path / "scaler.npz")
    fs.save(path)
    fs2 = FeatureStandardizer.load(path)
    assert np.allclose(fs2.mean_["hrv"], fs.mean_["hrv"])
    assert np.allclose(fs2.std_["hrv"], fs.std_["hrv"])
